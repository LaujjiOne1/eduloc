import { View } from "react-native";

type StepProgressProps = {
  /** 1-indexed current step. */
  step: number;
  total: number;
};

/**
 * Segmented progress dots shared by the search wizard screens. Completed and
 * current steps are primary-colored; the current step renders as a wide bar.
 */
export function StepProgress({ step, total }: StepProgressProps) {
  return (
    <View className="flex-row gap-[5px] px-5 pb-[14px]">
      {Array.from({ length: total }, (_, i) => i + 1).map((index) => {
        const filled = index <= step;
        return (
          <View
            key={index}
            className={["h-[7px] rounded-full", filled ? "bg-primary" : "bg-line"].join(" ")}
            style={{ width: index === step ? 22 : 7 }}
          />
        );
      })}
    </View>
  );
}
