import { type Href, useRouter } from "expo-router";
import { useState } from "react";
import { Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { GraduationCapIcon, ListIcon, MapIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { AuthHeader } from "@/components/ui/auth-header";
import { TUTOR_AVATAR_TONE_CLASSES } from "@/components/ui/tutor-card";
import { useTutorSearch } from "@/hooks/use-tutor-search";
import { useSearchWizardStore } from "@/store/search-wizard.store";

// Route already exists as of this task (src/app/results/index.tsx) — cast to
// Href defensively since expo-router's typed-routes union is only refreshed
// when the dev server runs.
const LIST_ROUTE = "/results" as Href;

function tutorRoute(id: string): Href {
  // Route already exists as of this task (src/app/results/tutor/[id].tsx).
  return `/results/tutor/${id}` as Href;
}

// Relative (top%, left%) positions used to scatter pins across the static
// map placeholder below. There is no map provider wired up yet (react-native-
// maps / expo-maps are not installed — see task summary); this mirrors the
// reference design's static layout rather than a real geographic map.
const PIN_POSITIONS = [
  { top: "22%", left: "20%" },
  { top: "58%", left: "32%" },
  { top: "38%", left: "62%" },
  { top: "66%", left: "70%" },
  { top: "30%", left: "78%" },
] as const;

export function ResultsMapScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const criteria = useSearchWizardStore((s) => s.criteria);
  const { state } = useTutorSearch(criteria);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const tutors = state.status === "success" ? state.tutors : [];
  const selected = tutors.find((t) => t.id === selectedId) ?? tutors[0] ?? null;

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />

      <View className="px-5 pb-[14px]">
        <View className="flex-row gap-1 rounded-full bg-paper-alt p-1">
          <PressableScale onPress={() => router.push(LIST_ROUTE)} accessibilityLabel="Afficher la liste" style={{ flex: 1 }}>
            <View className="flex-row items-center justify-center gap-[6px] rounded-full py-[9px]">
              <ListIcon size={15} color="#585B78" />
              <Text className="text-[13.5px] font-semibold text-ink-soft">Liste</Text>
            </View>
          </PressableScale>
          <View
            className="flex-1 flex-row items-center justify-center gap-[6px] rounded-full bg-surface py-[9px]"
            style={{
              shadowColor: "#14162B",
              shadowOpacity: 0.06,
              shadowRadius: 2,
              shadowOffset: { width: 0, height: 1 },
              elevation: 1,
            }}
          >
            <MapIcon size={15} color="#14162B" />
            <Text className="text-[13.5px] font-bold text-ink">Carte</Text>
          </View>
        </View>
      </View>

      <View className="flex-1 overflow-hidden bg-paper-alt">
        {state.status === "loading" ? (
          <View className="flex-1 items-center justify-center">
            <Text className="text-[13.5px] text-ink-soft">Chargement de la carte...</Text>
          </View>
        ) : tutors.length === 0 ? (
          <View className="flex-1 items-center justify-center px-8">
            <Text className="text-center text-[14px] text-ink-soft">
              {state.status === "error" ? state.message : "Aucun tuteur à afficher sur la carte."}
            </Text>
          </View>
        ) : (
          tutors.map((tutor, index) => {
            const position = PIN_POSITIONS[index % PIN_POSITIONS.length];
            const isSelected = tutor.id === selected?.id;
            return (
              <View key={tutor.id} style={{ position: "absolute", top: position.top, left: position.left }}>
                <PressableScale
                  onPress={() => setSelectedId(tutor.id)}
                  accessibilityLabel={`${tutor.firstName} ${tutor.lastName} sur la carte`}
                >
                  <View
                    className={[
                      "h-[34px] w-[34px] items-center justify-center rounded-tl-full rounded-tr-full rounded-br-full",
                      isSelected ? "bg-primary" : "border-2 border-primary bg-surface",
                    ].join(" ")}
                    style={{
                      transform: [{ rotate: "-45deg" }],
                      shadowColor: "#14162B",
                      shadowOpacity: 0.18,
                      shadowRadius: 6,
                      shadowOffset: { width: 0, height: 3 },
                      elevation: 3,
                    }}
                  >
                    <View style={{ transform: [{ rotate: "45deg" }] }}>
                      <GraduationCapIcon size={14} color={isSelected ? "#fff" : "#332E86"} />
                    </View>
                  </View>
                </PressableScale>
              </View>
            );
          })
        )}

        {selected ? (
          <FadeIn delay={0} style={{ position: "absolute", left: 20, right: 20, bottom: 18 }}>
            <PressableScale
              onPress={() => router.push(tutorRoute(selected.id))}
              accessibilityLabel={`${selected.firstName} ${selected.lastName}`}
            >
              <View
                className="flex-row items-center gap-3 rounded-lg border border-line bg-surface p-4"
                style={{
                  shadowColor: "#14162B",
                  shadowOpacity: 0.14,
                  shadowRadius: 16,
                  shadowOffset: { width: 0, height: 8 },
                  elevation: 6,
                }}
              >
                <View
                  className={[
                    "h-[52px] w-[52px] items-center justify-center rounded-md",
                    TUTOR_AVATAR_TONE_CLASSES[selected.avatarTone].bg,
                  ].join(" ")}
                >
                  <Text className={["text-[18px] font-bold", TUTOR_AVATAR_TONE_CLASSES[selected.avatarTone].text].join(" ")}>
                    {selected.firstName[0]}
                  </Text>
                </View>
                <View className="flex-1">
                  <Text className="text-[15px] font-bold text-ink" numberOfLines={1}>
                    {selected.firstName} {selected.lastName}
                  </Text>
                  <Text className="text-[12.5px] text-ink-soft" numberOfLines={1}>
                    {selected.subjects[0]}
                    {" • "}
                    {selected.location.distanceKm != null
                      ? `${selected.location.label}, ${selected.location.distanceKm} km`
                      : selected.location.label}
                  </Text>
                </View>
              </View>
            </PressableScale>
          </FadeIn>
        ) : null}
      </View>
    </View>
  );
}
