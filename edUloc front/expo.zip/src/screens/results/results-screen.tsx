import { type Href, useRouter } from "expo-router";
import { ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { ListIcon, MapIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { AuthHeader } from "@/components/ui/auth-header";
import { TutorCard } from "@/components/ui/tutor-card";
import { type TutorsState, useTutorSearch } from "@/hooks/use-tutor-search";
import { useSearchWizardStore } from "@/store/search-wizard.store";
import type { Tutor } from "@/types/tutor";

// Route already exists as of this task (src/app/results/map.tsx) — cast to
// Href defensively since expo-router's typed-routes union is only refreshed
// when the dev server runs.
const MAP_ROUTE = "/results/map" as Href;

function tutorRoute(id: string): Href {
  // Route already exists as of this task (src/app/results/tutor/[id].tsx).
  return `/results/tutor/${id}` as Href;
}

export function ResultsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const criteria = useSearchWizardStore((s) => s.criteria);
  const { state, retry } = useTutorSearch(criteria);

  const locationLabel =
    criteria.location.query || (criteria.location.format === "online" ? "En ligne" : "Localisation non précisée");
  const breadcrumb = [criteria.subject?.label, criteria.level?.label, locationLabel].filter(Boolean).join(" • ");

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />

      <View className="px-5 pb-[14px]">
        <FadeIn delay={30}>
          <Text className="mb-3 text-[13px] text-ink-soft">
            {breadcrumb}
            {state.status === "success" ? (
              <Text className="font-bold text-ink">
                {" "}
                — {state.tutors.length} résultat{state.tutors.length > 1 ? "s" : ""}
              </Text>
            ) : null}
          </Text>
        </FadeIn>

        <FadeIn delay={70}>
          <View className="flex-row gap-1 rounded-full bg-paper-alt p-1">
            <View
              className="flex-1 flex-row items-center justify-center gap-[6px] rounded-full bg-surface py-[9px]"
              style={{
                shadowColor: "#14162B",
                shadowOpacity: 0.06,
                shadowRadius: 2,
                shadowOffset: { width: 0, height: 1 },
                elevation: 1,
              }}
            >
              <ListIcon size={15} color="#14162B" />
              <Text className="text-[13.5px] font-bold text-ink">Liste</Text>
            </View>
            <PressableScale onPress={() => router.push(MAP_ROUTE)} accessibilityLabel="Afficher la carte" style={{ flex: 1 }}>
              <View className="flex-row items-center justify-center gap-[6px] rounded-full py-[9px]">
                <MapIcon size={15} color="#585B78" />
                <Text className="text-[13.5px] font-semibold text-ink-soft">Carte</Text>
              </View>
            </PressableScale>
          </View>
        </FadeIn>
      </View>

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: Math.max(insets.bottom, 20) }}
        showsVerticalScrollIndicator={false}
      >
        <TutorList state={state} onRetry={retry} onSelect={(tutor) => router.push(tutorRoute(tutor.id))} />
      </ScrollView>
    </View>
  );
}

type TutorListProps = {
  state: TutorsState;
  onRetry: () => void;
  onSelect: (tutor: Tutor) => void;
};

function TutorList({ state, onRetry, onSelect }: TutorListProps) {
  if (state.status === "loading") {
    return (
      <View className="gap-3">
        {[0, 1, 2].map((i) => (
          <View key={i} className="h-[112px] rounded-lg bg-line-soft" />
        ))}
      </View>
    );
  }

  if (state.status === "error") {
    return (
      <View className="flex-row items-center gap-3">
        <Text className="flex-1 text-[13.5px] text-error">{state.message}</Text>
        <PressableScale onPress={onRetry} accessibilityLabel="Réessayer de charger les tuteurs">
          <Text className="text-[13.5px] font-semibold text-primary">Réessayer</Text>
        </PressableScale>
      </View>
    );
  }

  if (state.status === "empty") {
    return (
      <View className="items-center py-10">
        <Text className="text-center text-[14px] text-ink-soft">
          Aucun tuteur ne correspond à votre recherche pour le moment.
        </Text>
      </View>
    );
  }

  return (
    <View>
      {state.tutors.map((tutor, index) => (
        <FadeIn key={tutor.id} delay={90 + index * 50}>
          <TutorCard tutor={tutor} onPress={() => onSelect(tutor)} />
        </FadeIn>
      ))}
    </View>
  );
}
