import { type Href, useLocalSearchParams, useRouter } from "expo-router";
import { useEffect, useState } from "react";
import { ActivityIndicator, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { FormError } from "@/components/ui/form-error";
import { type SelectOption, SelectField } from "@/components/ui/select-field";
import { useAvailabilityActions } from "@/hooks/use-availability-actions";
import { useAvailabilityDetail } from "@/hooks/use-availability-detail";
import { useLocationFormats } from "@/hooks/use-location-formats";
import { useTutorProfile } from "@/hooks/use-tutor-profile";
import type { LocationFormatId } from "@/types/search";
import { upcomingDateOptions } from "@/utils/calendar";

const CALENDAR_ROUTE = "/tutor-dashboard/calendar" as Href;

const TIME_OPTIONS: SelectOption[] = Array.from({ length: 33 }, (_, i) => {
  const totalMinutes = 6 * 60 + i * 30; // 06:00 → 22:00, 30-minute steps
  const hh = String(Math.floor(totalMinutes / 60)).padStart(2, "0");
  const mm = String(totalMinutes % 60).padStart(2, "0");
  const label = `${hh}:${mm}`;
  return { id: label, label };
});

const DATE_OPTIONS: SelectOption[] = upcomingDateOptions(30);

export function AvailabilityEditScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id?: string }>();
  const isEditMode = !!id;

  const { state: detailState } = useAvailabilityDetail(id);
  const { state: profileState } = useTutorProfile();
  const { state: formatsState } = useLocationFormats();
  const { state: actionState, save, remove } = useAvailabilityActions();

  const [dateOption, setDateOption] = useState<SelectOption | null>(null);
  const [startOption, setStartOption] = useState<SelectOption | null>(null);
  const [endOption, setEndOption] = useState<SelectOption | null>(null);
  const [format, setFormat] = useState<LocationFormatId | null>(null);
  const [locationOption, setLocationOption] = useState<SelectOption | null>(null);
  const [blockNotice, setBlockNotice] = useState<string | null>(null);

  // Seed the form once the existing entry loads (edit mode only).
  useEffect(() => {
    if (detailState.status !== "success") return;
    const entry = detailState.entry;
    setDateOption({ id: entry.date, label: entry.dateLabel });
    setStartOption({ id: entry.startTime, label: entry.startTime });
    setEndOption({ id: entry.endTime, label: entry.endTime });
    setFormat(entry.format);
    if (entry.locationLabel) setLocationOption({ id: entry.locationLabel, label: entry.locationLabel });
  }, [detailState]);

  const locations = profileState.status === "success" ? profileState.profile.locations : [];
  const needsLocation = format !== "online";

  const canSubmit =
    !!dateOption &&
    !!startOption &&
    !!endOption &&
    startOption.id < endOption.id &&
    !!format &&
    (!needsLocation || !!locationOption);

  const isSaving = actionState.status === "saving";
  const isDeleting = actionState.status === "deleting";

  const handleSave = async () => {
    if (!canSubmit || !dateOption || !startOption || !endOption || !format) return;
    const entry = await save(id ?? null, {
      date: dateOption.id,
      dateLabel: dateOption.label,
      startTime: startOption.id,
      endTime: endOption.id,
      format,
      locationLabel: needsLocation ? (locationOption?.label ?? null) : null,
    });
    if (entry) router.replace(CALENDAR_ROUTE);
  };

  const handleDelete = async () => {
    if (!isEditMode || !id) return;
    const ok = await remove(id);
    if (ok) router.replace(CALENDAR_ROUTE);
  };

  // The Lieu field needs the tutor's own locations — wait for that load too,
  // rather than briefly showing "no locations".
  const isLoadingDetail = (isEditMode && detailState.status === "loading") || profileState.status === "loading";
  const detailError = isEditMode && detailState.status === "error" ? detailState.message : null;

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />

      {isLoadingDetail ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator color="#332E86" />
        </View>
      ) : detailError ? (
        <View className="flex-1 items-center justify-center px-8">
          <Text className="text-center text-[14px] text-error">{detailError}</Text>
        </View>
      ) : (
        <ScrollView className="flex-1" contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }} showsVerticalScrollIndicator={false}>
          <Text className="mb-[18px] text-[24px] font-bold text-ink">Disponibilité</Text>

          {actionState.status === "error" ? <FormError message={actionState.message} /> : null}

          {isEditMode ? (
            <View className="mb-4 rounded-lg border border-line bg-surface p-4">
              <Text className="mb-[14px] text-[15px] font-bold text-ink">{dateOption?.label}</Text>
              <View className="flex-row items-center justify-between">
                <View className="items-center">
                  <Text className="mb-1 text-[11px] text-ink-soft">Début</Text>
                  <Text className="text-[22px] font-bold text-ink">{startOption?.id ?? "—"}</Text>
                </View>
                <View className="mx-[14px] h-[2px] flex-1 bg-line" />
                <View className="items-center">
                  <Text className="mb-1 text-[11px] text-ink-soft">Fin</Text>
                  <Text className="text-[22px] font-bold text-ink">{endOption?.id ?? "—"}</Text>
                </View>
              </View>
            </View>
          ) : (
            <SelectField label="Date" value={dateOption} options={DATE_OPTIONS} onSelect={setDateOption} />
          )}

          <SelectField label="Début" value={startOption} options={TIME_OPTIONS} onSelect={setStartOption} />
          <SelectField
            label="Fin"
            value={endOption}
            options={TIME_OPTIONS}
            onSelect={setEndOption}
            error={startOption && endOption && startOption.id >= endOption.id ? "L'heure de fin doit être après le début." : undefined}
          />
          <SelectField
            label="Format"
            value={format ? formatOptionFor(format, formatsState.status === "success" ? formatsState.formats : []) : null}
            options={formatsState.status === "success" ? formatsState.formats : []}
            onSelect={(option) => setFormat(option.id as LocationFormatId)}
          />
          {needsLocation ? (
            <SelectField
              label="Lieu"
              value={locationOption}
              options={locations}
              placeholder={locations.length ? "Sélectionner" : "Aucun lieu enregistré"}
              disabled={locations.length === 0}
              onSelect={setLocationOption}
            />
          ) : null}
        </ScrollView>
      )}

      <View className="border-t border-line-soft bg-surface px-5 pt-4" style={{ paddingBottom: Math.max(insets.bottom, 22) }}>
        <View className="gap-[10px]">
          <Button
            label="Enregistrer"
            disabled={!canSubmit || isSaving || isDeleting}
            loading={isSaving}
            loadingLabel="Enregistrement..."
            onPress={handleSave}
          />
          {isEditMode ? (
            <View className="flex-row gap-[10px]">
              <Button
                label="Bloquer la période"
                variant="ghost"
                fullWidth
                disabled={isSaving || isDeleting}
                onPress={() => setBlockNotice("Le blocage de période arrive bientôt.")}
              />
              <Button
                label="Supprimer"
                variant="ghost"
                fullWidth
                disabled={isSaving || isDeleting}
                loading={isDeleting}
                loadingLabel="Suppression..."
                onPress={handleDelete}
              />
            </View>
          ) : null}
          {blockNotice ? <Text className="text-center text-[12.5px] text-ink-faint">{blockNotice}</Text> : null}
        </View>
      </View>
    </View>
  );
}

function formatOptionFor(id: LocationFormatId, options: SelectOption[]): SelectOption | null {
  return options.find((o) => o.id === id) ?? null;
}
