import { type Href, useRouter } from "expo-router";
import { ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { PlusIcon } from "@/components/icons";
import { PressableScale } from "@/components/motion/pressable-scale";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { TutorBottomNav } from "@/components/ui/tutor-bottom-nav";
import { useTutorAvailability } from "@/hooks/use-tutor-availability";
import { useTutorBookings } from "@/hooks/use-tutor-bookings";
import type { Booking } from "@/types/booking";
import type { TutorAvailabilitySlot } from "@/types/availability";
import { formatMonthLabel, yearMonthFromIsoDate } from "@/utils/calendar";

const NEW_AVAILABILITY_ROUTE = "/tutor-dashboard/calendar/availability/new" as Href;
function editAvailabilityRoute(id: string): Href {
  return `/tutor-dashboard/calendar/availability/${id}` as Href;
}

type DayItem =
  | { kind: "booking"; startTime: string; booking: Booking }
  | { kind: "availability"; startTime: string; entry: TutorAvailabilitySlot };

type Day = { date: string; dateLabel: string; items: DayItem[] };

function groupByDay(bookings: Booking[], availability: TutorAvailabilitySlot[]): Day[] {
  const days = new Map<string, Day>();

  for (const booking of bookings) {
    if (booking.status !== "confirmed") continue;
    const day = days.get(booking.slot.date) ?? { date: booking.slot.date, dateLabel: booking.slot.dateLabel, items: [] };
    day.items.push({ kind: "booking", startTime: booking.slot.startTime, booking });
    days.set(booking.slot.date, day);
  }
  for (const entry of availability) {
    const day = days.get(entry.date) ?? { date: entry.date, dateLabel: entry.dateLabel, items: [] };
    day.items.push({ kind: "availability", startTime: entry.startTime, entry });
    days.set(entry.date, day);
  }

  return [...days.values()]
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((day) => ({ ...day, items: day.items.sort((a, b) => a.startTime.localeCompare(b.startTime)) }));
}

export function CalendarScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { state: bookingsState, retry: retryBookings } = useTutorBookings();
  const { state: availabilityState, retry: retryAvailability } = useTutorAvailability();

  const isLoading = bookingsState.status === "loading" || availabilityState.status === "loading";
  const error = bookingsState.status === "error" ? bookingsState.message : availabilityState.status === "error" ? availabilityState.message : null;

  const days =
    bookingsState.status === "success" && availabilityState.status === "success"
      ? groupByDay(bookingsState.bookings, availabilityState.availability)
      : [];

  let monthLabel: string | null = null;
  if (days[0]) {
    const { year, month } = yearMonthFromIsoDate(days[0].date);
    monthLabel = formatMonthLabel(year, month);
  }

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />
      <View className="px-5 pb-3">
        <Text className="text-[16px] font-bold text-ink">{monthLabel ?? formatMonthLabel(new Date().getFullYear(), new Date().getMonth())}</Text>
      </View>

      <ScrollView className="flex-1" contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }} showsVerticalScrollIndicator={false}>
        {isLoading ? (
          <View className="gap-3">
            {[0, 1].map((i) => (
              <View key={i} className="h-[96px] rounded-lg bg-line-soft" />
            ))}
          </View>
        ) : error ? (
          <View className="flex-row items-center gap-3">
            <Text className="flex-1 text-[13.5px] text-error">{error}</Text>
            <PressableScale
              onPress={() => {
                retryBookings();
                retryAvailability();
              }}
              accessibilityLabel="Réessayer"
            >
              <Text className="text-[13.5px] font-semibold text-primary">Réessayer</Text>
            </PressableScale>
          </View>
        ) : days.length === 0 ? (
          <View className="items-center py-10">
            <Text className="text-center text-[14px] text-ink-soft">Aucune disponibilité ni rendez-vous pour le moment.</Text>
          </View>
        ) : (
          days.map((day) => <DayCard key={day.date} day={day} onEditAvailability={(id) => router.push(editAvailabilityRoute(id))} />)
        )}
      </ScrollView>

      <View className="border-t border-line-soft bg-surface px-5 pt-4" style={{ paddingBottom: 16 }}>
        <Button
          label="Ajouter disponibilité"
          icon={<PlusIcon size={17} color="#fff" />}
          onPress={() => router.push(NEW_AVAILABILITY_ROUTE)}
        />
      </View>

      <TutorBottomNav active="calendar" />
    </View>
  );
}

function DayCard({ day, onEditAvailability }: { day: Day; onEditAvailability: (id: string) => void }) {
  return (
    <View className="mb-3 rounded-lg border border-line bg-surface p-4">
      <Text className="mb-[6px] text-[15px] font-bold text-ink">{day.dateLabel}</Text>
      {day.items.map((item, index) => (
        <ItemRow key={index} item={item} onEditAvailability={onEditAvailability} />
      ))}
    </View>
  );
}

function ItemRow({ item, onEditAvailability }: { item: DayItem; onEditAvailability: (id: string) => void }) {
  if (item.kind === "booking") {
    return (
      <View className="flex-row items-center gap-[10px] py-2">
        <Text className="w-[52px] text-[13px] font-bold text-ink-soft">{item.startTime}</Text>
        <Text className="flex-1 text-[13.5px] font-semibold text-ink" numberOfLines={1}>
          {item.booking.offer.subjectLabel} — {item.booking.beneficiary.firstName}
        </Text>
        <StatusBadge status="confirmed" />
      </View>
    );
  }

  return (
    <PressableScale onPress={() => onEditAvailability(item.entry.id)} accessibilityLabel={`Modifier la disponibilité de ${item.startTime}`}>
      <View className="flex-row items-center gap-[10px] py-2">
        <Text className="w-[52px] text-[13px] font-bold text-ink-soft">{item.startTime}</Text>
        <Text className="flex-1 text-[13.5px] font-semibold text-ink">Disponible</Text>
      </View>
    </PressableScale>
  );
}
