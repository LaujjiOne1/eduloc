import { type Href, useRouter } from "expo-router";
import { ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { BellIcon, ChevronRightIcon, TeachIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { TutorBottomNav } from "@/components/ui/tutor-bottom-nav";
import { useTutorBookings } from "@/hooks/use-tutor-bookings";
import { useTutorProfile } from "@/hooks/use-tutor-profile";
import type { Booking } from "@/types/booking";

const MODE_SWITCH_ROUTE = "/mode-switch" as Href;
const NOTIFICATIONS_ROUTE = "/notifications" as Href;
const APPOINTMENTS_ROUTE = "/tutor-dashboard/appointments" as Href;

function requestRoute(id: string): Href {
  return `/tutor-dashboard/requests/${id}` as Href;
}

export function DashboardScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { state: profileState } = useTutorProfile();
  const { state: bookingsState } = useTutorBookings();

  const firstName = profileState.status === "success" ? profileState.profile.firstName : "";

  const pending = bookingsState.status === "success" ? bookingsState.bookings.filter((b) => b.status === "pending") : [];
  const confirmed =
    bookingsState.status === "success" ? bookingsState.bookings.filter((b) => b.status === "confirmed") : [];
  const nextAppointment = confirmed[0] ?? null;

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <View className="flex-row items-center justify-between px-5 pb-[14px] pt-5">
        <Text className="text-[21px] font-bold text-ink">
          edU<Text className="text-primary">loc</Text>
        </Text>
        <View className="flex-row items-center gap-[10px]">
          <PressableScale onPress={() => router.push(MODE_SWITCH_ROUTE)} accessibilityLabel="Changer de mode : Tuteur">
            <View className="flex-row items-center gap-[6px] rounded-full bg-primary-tint py-[7px] pl-[10px] pr-3">
              <TeachIcon size={15} color="#332E86" />
              <Text className="text-[13px] font-bold text-primary">Tuteur</Text>
              <View style={{ transform: [{ rotate: "90deg" }] }}>
                <ChevronRightIcon size={13} color="#332E86" />
              </View>
            </View>
          </PressableScale>
          <PressableScale onPress={() => router.push(NOTIFICATIONS_ROUTE)} accessibilityLabel="Notifications">
            <View className="h-[38px] w-[38px] items-center justify-center rounded-full border border-line">
              <BellIcon size={18} color="#585B78" />
            </View>
          </PressableScale>
        </View>
      </View>

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }}
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={30}>
          <Text className="mb-[2px] text-[24px] font-bold text-ink">Bonjour{firstName ? `, ${firstName}` : ""}</Text>
          <Text className="mb-5 text-[14px] text-ink-soft">Votre activité</Text>
        </FadeIn>

        <FadeIn delay={70}>
          <View className="mb-6 flex-row gap-3">
            <StatCard value={bookingsState.status === "success" ? pending.length : null} label="demandes" />
            <StatCard value={bookingsState.status === "success" ? confirmed.length : null} label="RDV" />
          </View>
        </FadeIn>

        <FadeIn delay={100}>
          <View className="mb-3 flex-row items-center justify-between">
            <Text className="text-[12.5px] font-semibold uppercase tracking-[0.03em] text-ink-soft">
              Demandes en attente
            </Text>
            <PressableScale onPress={() => router.push("/tutor-dashboard/requests" as Href)} accessibilityLabel="Tout voir les demandes">
              <Text className="text-[12.5px] font-bold text-primary">Tout voir</Text>
            </PressableScale>
          </View>

          {bookingsState.status === "loading" ? (
            <View className="mb-6 h-[130px] rounded-lg bg-line-soft" />
          ) : bookingsState.status === "error" ? (
            <Text className="mb-6 text-[13.5px] text-error">{bookingsState.message}</Text>
          ) : pending.length === 0 ? (
            <View className="mb-6 items-center rounded-lg border border-line bg-surface py-6">
              <Text className="text-[13.5px] text-ink-soft">Aucune demande en attente pour le moment.</Text>
            </View>
          ) : (
            <PendingRequestCard booking={pending[0]} onPress={() => router.push(requestRoute(pending[0].id))} />
          )}
        </FadeIn>

        <FadeIn delay={140}>
          <Text className="mb-3 text-[12.5px] font-semibold uppercase tracking-[0.03em] text-ink-soft">
            Prochain rendez-vous
          </Text>
          {bookingsState.status === "loading" ? (
            <View className="h-[76px] rounded-lg bg-line-soft" />
          ) : nextAppointment ? (
            <PressableScale onPress={() => router.push(APPOINTMENTS_ROUTE)} accessibilityLabel="Voir mes rendez-vous">
              <View className="rounded-lg border border-line bg-surface p-4">
                <Text className="text-[15px] font-bold text-ink">{nextAppointment.offer.title}</Text>
                <Text className="mt-1 text-[13px] text-ink-soft">
                  {nextAppointment.slot.dateLabel} • {nextAppointment.slot.startTime}
                </Text>
              </View>
            </PressableScale>
          ) : (
            <View className="items-center rounded-lg border border-line bg-surface py-6">
              <Text className="text-[13.5px] text-ink-soft">Aucun rendez-vous à venir pour le moment.</Text>
            </View>
          )}
        </FadeIn>
      </ScrollView>
      
      <TutorBottomNav active="home" />

    </View>
  );
}

function StatCard({ value, label }: { value: number | null; label: string }) {
  return (
    <View className="flex-1 items-center rounded-lg border border-line bg-surface px-2 py-4">
      {value === null ? (
        <View className="mb-1 h-[26px] w-8 rounded bg-line-soft" />
      ) : (
        <Text className="text-[26px] font-bold text-primary">{value}</Text>
      )}
      <Text className="mt-[2px] text-[12px] text-ink-soft">{label}</Text>
    </View>
  );
}

function PendingRequestCard({ booking, onPress }: { booking: Booking; onPress: () => void }) {
  return (
    <View className="mb-6 rounded-lg border border-line bg-surface p-4">
      <View className="mb-1 flex-row items-start justify-between">
        <View>
          <Text className="text-[15px] font-bold text-ink">{booking.beneficiary.firstName}</Text>
          <Text className="mt-[2px] text-[13px] text-ink-soft">{booking.offer.title.split(" ")[0]}</Text>
        </View>
        <View className="flex-row items-center gap-[6px] self-start rounded-full bg-warning-tint px-[11px] py-[5px]">
          <View className="h-[7px] w-[7px] rounded-full bg-warning" />
          <Text className="text-[12px] font-semibold text-warning">EN ATTENTE</Text>
        </View>
      </View>
      <Text className="mb-[14px] text-[12.5px] text-ink-soft">
        {booking.slot.dateLabel} • {booking.slot.startTime}
      </Text>
      {/* Both actions open the full request detail (53) before anything is
          confirmed/refused, matching the mock's own hrefs and giving the
          tutor full context before an impactful decision. */}
      <View className="flex-row gap-[10px]">
        <PressableScale onPress={onPress} accessibilityLabel={`Voir la demande de ${booking.beneficiary.firstName}`} style={{ flex: 1 }}>
          <View className="items-center justify-center rounded-sm border border-line px-4 py-[9px]">
            <Text className="text-[13px] font-semibold text-ink">Refuser</Text>
          </View>
        </PressableScale>
        <PressableScale onPress={onPress} accessibilityLabel={`Voir la demande de ${booking.beneficiary.firstName}`} style={{ flex: 1 }}>
          <View className="items-center justify-center rounded-sm bg-primary px-4 py-[9px]">
            <Text className="text-[13px] font-semibold text-white">Accepter</Text>
          </View>
        </PressableScale>
      </View>
    </View>
  );
}
