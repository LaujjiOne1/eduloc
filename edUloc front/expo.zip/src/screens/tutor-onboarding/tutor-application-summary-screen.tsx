import { type Href, useRouter } from "expo-router";
import { useEffect } from "react";
import { ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { CheckIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { FormError } from "@/components/ui/form-error";
import { useSubmitTutorApplication } from "@/hooks/use-submit-tutor-application";
import { useTutorApplicationStore } from "@/store/tutor-application.store";
import type { TutorApplicationSubmission } from "@/types/tutor-application";

const TUTOR_IDENTITY_ROUTE = "/tutor-identity" as Href;
const TUTOR_APPLICATION_PENDING_ROUTE = "/tutor-application-pending" as Href;

export function TutorApplicationSummaryScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const identity = useTutorApplicationStore((s) => s.identity);
  const background = useTutorApplicationStore((s) => s.background);
  const skills = useTutorApplicationStore((s) => s.skills);
  const subjectLevels = useTutorApplicationStore((s) => s.subjectLevels);
  const bio = useTutorApplicationStore((s) => s.bio);
  const offer = useTutorApplicationStore((s) => s.offer);
  const formats = useTutorApplicationStore((s) => s.formats);
  const locations = useTutorApplicationStore((s) => s.locations);
  const availability = useTutorApplicationStore((s) => s.availability);
  const documents = useTutorApplicationStore((s) => s.documents);
  const setApplication = useTutorApplicationStore((s) => s.setApplication);
  const { state, submit } = useSubmitTutorApplication();

  // Guard: reaching the recap without having started the wizard means there's
  // nothing to review — bounce back to the start (AGENTS.md §13).
  const hasContext = identity.firstName.trim().length > 0;
  useEffect(() => {
    if (!hasContext) router.replace(TUTOR_IDENTITY_ROUTE);
  }, [hasContext, router]);

  if (!hasContext) return null;

  const rows = [
    { label: "Informations personnelles", done: !!identity.firstName && !!identity.lastName },
    { label: "Parcours", done: !!background.degree },
    { label: "Compétences", done: skills.length > 0 },
    { label: "Matières", done: subjectLevels.some((sl) => sl.levels.length > 0) },
    { label: "Offres", done: !!offer.title && !!offer.skill && !!offer.duration },
    { label: "Lieux", done: locations.length > 0 },
    { label: "Disponibilités", done: availability.length > 0 },
    { label: "Documents", done: documents.some((d) => d.provided) },
  ];

  const isSubmitting = state.status === "loading";

  const handleSubmit = async () => {
    if (isSubmitting) return;
    const submission: TutorApplicationSubmission = {
      identity,
      background,
      skills,
      subjectLevels,
      bio,
      offer,
      formats,
      locations,
      availability,
      documents,
    };
    const application = await submit(submission);
    if (application) {
      setApplication(application);
      router.push(TUTOR_APPLICATION_PENDING_ROUTE);
    }
  };

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }}
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={40}>
          <Text className="mb-4 text-[24px] font-bold text-ink">Votre dossier</Text>
        </FadeIn>

        <FadeIn delay={90}>
          {state.status === "error" ? <FormError message={state.message} /> : null}

          <View className="rounded-lg border border-line bg-surface px-4">
            {rows.map((row) => (
              <View key={row.label} className="flex-row items-center gap-[10px] py-[10px]">
                <View
                  className={[
                    "h-[17px] w-[17px] items-center justify-center rounded-full",
                    row.done ? "" : "border-2 border-line",
                  ].join(" ")}
                >
                  {row.done ? <CheckIcon size={17} color="#0E9C82" /> : null}
                </View>
                <Text className="flex-1 text-[14.5px] font-semibold text-ink">{row.label}</Text>
              </View>
            ))}
          </View>
        </FadeIn>

        <FadeIn delay={130}>
          <PressableScale onPress={() => router.push(TUTOR_IDENTITY_ROUTE)} accessibilityLabel="Modifier votre dossier">
            <Text className="mt-4 text-center text-[14px] font-bold text-primary">Modifier</Text>
          </PressableScale>
        </FadeIn>
      </ScrollView>

      <View
        className="border-t border-line-soft bg-surface px-5 pt-4"
        style={{ paddingBottom: Math.max(insets.bottom, 22) }}
      >
        <Button
          label="Soumettre mon dossier"
          loading={isSubmitting}
          loadingLabel="Envoi..."
          onPress={handleSubmit}
        />
      </View>
    </View>
  );
}
