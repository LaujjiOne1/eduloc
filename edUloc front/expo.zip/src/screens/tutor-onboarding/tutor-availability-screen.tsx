import { type Href, useRouter } from "expo-router";
import { ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { ClockIcon, LocationIcon, PlusIcon, VideoIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { StepProgress } from "@/components/ui/step-progress";
import { useTutorApplicationStore } from "@/store/tutor-application.store";
import type { TutorAvailabilityEntry } from "@/types/tutor-application";

const TUTOR_DOCUMENTS_ROUTE = "/tutor-documents" as Href;
const TOTAL_STEPS = 9;

export function TutorAvailabilityScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const availability = useTutorApplicationStore((s) => s.availability);

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />
      <StepProgress step={9} total={TOTAL_STEPS} />

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }}
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={40}>
          <Text className="mb-1 text-[24px] font-bold text-ink">Quand êtes-vous disponible&nbsp;?</Text>
          <Text className="mb-5 text-[13.5px] text-ink-soft">
            Le tuteur devient producteur de créneaux
          </Text>
        </FadeIn>

        <FadeIn delay={90}>
          {availability.length === 0 ? (
            <Text className="mb-4 text-[13.5px] text-ink-faint">
              Aucune disponibilité ajoutée pour le moment.
            </Text>
          ) : (
            <View className="mb-2 gap-[10px]">
              {availability.map((entry) => (
                <AvailabilityCard key={entry.id} entry={entry} />
              ))}
            </View>
          )}

          {/* "Ajouter" opens 57_TutorAvailabilityEdit, a screen not provided
              in this batch — out of scope for this task, shown inert. */}
          <View className="mt-1 flex-row items-center gap-2 opacity-50">
            <PlusIcon size={16} color="#332E86" />
            <Text className="text-[14px] font-bold text-primary">Ajouter</Text>
          </View>
        </FadeIn>
      </ScrollView>

      <View
        className="border-t border-line-soft bg-surface px-5 pt-4"
        style={{ paddingBottom: Math.max(insets.bottom, 22) }}
      >
        <Button label="Continuer" onPress={() => router.push(TUTOR_DOCUMENTS_ROUTE)} />
      </View>
    </View>
  );
}

function AvailabilityCard({ entry }: { entry: TutorAvailabilityEntry }) {
  const isOnline = entry.format === "online";

  return (
    <View className="rounded-lg border border-line bg-surface p-4">
      <Text className="mb-2 text-[13px] font-bold uppercase tracking-[0.04em] text-ink-soft">
        {entry.dateLabel}
      </Text>
      <View className="mb-[6px] flex-row items-center gap-2">
        <ClockIcon size={15} color="#332E86" />
        <Text className="text-[15px] font-bold text-ink">{entry.timeRangeLabel}</Text>
      </View>
      <View className="flex-row items-center gap-2">
        {isOnline ? (
          <VideoIcon size={14} color="#585B78" />
        ) : (
          <LocationIcon size={14} color="#585B78" />
        )}
        <Text className="text-[13px] text-ink-soft">{isOnline ? "En ligne" : entry.locationLabel}</Text>
      </View>
    </View>
  );
}
