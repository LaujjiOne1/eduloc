import { type Href, useRouter } from "expo-router";
import { KeyboardAvoidingView, Platform, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { FadeIn } from "@/components/motion/fade-in";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { SelectField } from "@/components/ui/select-field";
import { StepProgress } from "@/components/ui/step-progress";
import { TextField } from "@/components/ui/text-field";
import { useTutorApplicationStore } from "@/store/tutor-application.store";
import type { EducationDegree } from "@/types/tutor-application";

const TUTOR_SKILLS_ROUTE = "/tutor-skills" as Href;
const TOTAL_STEPS = 9;

// The spec doesn't define a degree catalog — a small fixed set covering the
// common cases, flagged rather than invented as business rule (AGENTS.md §11).
const DEGREE_OPTIONS: EducationDegree[] = [
  { id: "bac", label: "Baccalauréat" },
  { id: "licence", label: "Licence" },
  { id: "master", label: "Master" },
  { id: "doctorat", label: "Doctorat" },
  { id: "other", label: "Autre" },
];

export function TutorBackgroundScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const background = useTutorApplicationStore((s) => s.background);
  const setBackground = useTutorApplicationStore((s) => s.setBackground);

  const canContinue =
    !!background.degree && background.field.trim().length > 0 && background.institution.trim().length > 0;

  return (
    <KeyboardAvoidingView
      className="flex-1 bg-paper"
      style={{ paddingTop: insets.top }}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <AuthHeader onBack={() => router.back()} />
      <StepProgress step={2} total={TOTAL_STEPS} />

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={40}>
          <Text className="mb-1 text-[24px] font-bold text-ink">Quel est votre parcours&nbsp;?</Text>
          <Text className="mb-5 text-[13.5px] text-ink-soft">Votre formation et votre expérience</Text>
        </FadeIn>

        <FadeIn delay={90}>
          <SelectField
            label="Niveau d'études"
            value={background.degree}
            options={DEGREE_OPTIONS}
            onSelect={(option) => {
              const degree = DEGREE_OPTIONS.find((d) => d.id === option.id) ?? null;
              setBackground({ degree });
            }}
          />
          <TextField
            label="Domaine"
            value={background.field}
            onChangeText={(field) => setBackground({ field })}
            placeholder="Informatique"
          />
          <TextField
            label="Établissement"
            value={background.institution}
            onChangeText={(institution) => setBackground({ institution })}
            placeholder="Université d'Antananarivo"
          />
          <TextField
            label="Expérience"
            value={background.experience}
            onChangeText={(experience) => setBackground({ experience })}
            placeholder="4 ans d'enseignement particulier"
          />
        </FadeIn>
      </ScrollView>

      <View
        className="border-t border-line-soft bg-surface px-5 pt-4"
        style={{ paddingBottom: Math.max(insets.bottom, 22) }}
      >
        <Button
          label="Continuer"
          disabled={!canContinue}
          onPress={() => router.push(TUTOR_SKILLS_ROUTE)}
        />
      </View>
    </KeyboardAvoidingView>
  );
}
