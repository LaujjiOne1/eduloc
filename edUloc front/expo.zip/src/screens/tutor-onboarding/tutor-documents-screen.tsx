import { type Href, useRouter } from "expo-router";
import { ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { AttachIcon, CheckIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { StepProgress } from "@/components/ui/step-progress";
import { useTutorApplicationStore } from "@/store/tutor-application.store";
import type { TutorDocumentEntry } from "@/types/tutor-application";

const TUTOR_APPLICATION_SUMMARY_ROUTE = "/tutor-application-summary" as Href;
// Beyond the 9 tracked steps — StepProgress renders every dot filled with
// none "active", matching 48_TutorDocuments' progress bar exactly.
const DOCUMENTS_STEP = 10;
const TOTAL_STEPS = 9;

export function TutorDocumentsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const documents = useTutorApplicationStore((s) => s.documents);
  const toggleDocument = useTutorApplicationStore((s) => s.toggleDocument);

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />
      <StepProgress step={DOCUMENTS_STEP} total={TOTAL_STEPS} />

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }}
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={40}>
          <Text className="mb-1 text-[24px] font-bold text-ink">Documents</Text>
          <Text className="mb-5 text-[13.5px] text-ink-soft">
            Accessibles uniquement à vous et à l&apos;équipe EduLoc
          </Text>
        </FadeIn>

        <FadeIn delay={90}>
          <View className="gap-[10px]">
            {documents.map((document) => (
              <DocumentRow key={document.kind} document={document} onPress={() => toggleDocument(document.kind)} />
            ))}
          </View>
          <Text className="mt-2 text-[12px] text-ink-faint">Formats acceptés : PDF, image</Text>
        </FadeIn>
      </ScrollView>

      <View
        className="border-t border-line-soft bg-surface px-5 pt-4"
        style={{ paddingBottom: Math.max(insets.bottom, 22) }}
      >
        <Button label="Continuer" onPress={() => router.push(TUTOR_APPLICATION_SUMMARY_ROUTE)} />
      </View>
    </View>
  );
}

type DocumentRowProps = {
  document: TutorDocumentEntry;
  onPress: () => void;
};

// Real file selection needs expo-document-picker (not installed) plus a
// backend upload endpoint — out of scope for this task. Tapping toggles a
// local "provided" flag so the rest of the flow (and the Summary recap)
// stays honest about what's actually been attached.
function DocumentRow({ document, onPress }: DocumentRowProps) {
  return (
    <PressableScale onPress={onPress} accessibilityLabel={`${document.label}: ${document.provided ? "ajouté" : "ajouter"}`}>
      <View
        className="flex-row items-center justify-between rounded-lg border border-dashed p-4"
        style={{ borderColor: document.provided ? "#0E9C82" : "#E7E3D7" }}
      >
        <Text className="text-[14.5px] font-semibold text-ink">{document.label}</Text>
        <View className="flex-row items-center gap-2">
          {document.provided ? (
            <>
              <CheckIcon size={14} color="#0E9C82" />
              <Text className="text-[13px] font-bold text-accent">Ajouté</Text>
            </>
          ) : (
            <>
              <AttachIcon size={15} color="#332E86" />
              <Text className="text-[13px] font-bold text-primary">Ajouter</Text>
            </>
          )}
        </View>
      </View>
    </PressableScale>
  );
}
