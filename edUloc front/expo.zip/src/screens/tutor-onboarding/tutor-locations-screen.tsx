import { type Href, useRouter } from "expo-router";
import { ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { EditIcon, LocationIcon, PlusIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { StepProgress } from "@/components/ui/step-progress";
import { useTutorApplicationStore } from "@/store/tutor-application.store";
import type { TutorLocationEntry } from "@/types/tutor-application";

const TUTOR_AVAILABILITY_ROUTE = "/tutor-availability" as Href;
const TOTAL_STEPS = 9;

export function TutorLocationsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const locations = useTutorApplicationStore((s) => s.locations);

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />
      <StepProgress step={8} total={TOTAL_STEPS} />

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }}
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={40}>
          <Text className="mb-1 text-[24px] font-bold text-ink">Vos lieux</Text>
          <Text className="mb-5 text-[13.5px] text-ink-soft">
            Ces lieux servent à la recherche géographique
          </Text>
        </FadeIn>

        <FadeIn delay={90}>
          {locations.length === 0 ? (
            <Text className="mb-4 text-[13.5px] text-ink-faint">Aucun lieu ajouté pour le moment.</Text>
          ) : (
            <View className="mb-2 gap-[10px]">
              {locations.map((location) => (
                <LocationCard key={location.id} location={location} />
              ))}
            </View>
          )}

          {/* "Ajouter un lieu" needs its own screen/spec — out of scope for
              this task, shown inert. */}
          <View className="mt-1 flex-row items-center gap-2 opacity-50">
            <PlusIcon size={16} color="#332E86" />
            <Text className="text-[14px] font-bold text-primary">Ajouter un lieu</Text>
          </View>
        </FadeIn>
      </ScrollView>

      <View
        className="border-t border-line-soft bg-surface px-5 pt-4"
        style={{ paddingBottom: Math.max(insets.bottom, 22) }}
      >
        <Button label="Continuer" onPress={() => router.push(TUTOR_AVAILABILITY_ROUTE)} />
      </View>
    </View>
  );
}

function LocationCard({ location }: { location: TutorLocationEntry }) {
  return (
    <View className="flex-row items-center gap-3 rounded-lg border border-line bg-surface p-4">
      <View className="h-[38px] w-[38px] items-center justify-center rounded-md bg-primary-tint">
        <LocationIcon size={18} color="#332E86" />
      </View>
      <View className="flex-1">
        <Text className="text-[14.5px] font-bold text-ink">{location.label}</Text>
        <Text className="mt-[2px] text-[12.5px] text-ink-soft">Rayon : {location.radiusKm} km</Text>
      </View>
      <EditIcon size={16} color="#9799AF" />
    </View>
  );
}
