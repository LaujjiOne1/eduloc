import { type Href, useRouter } from "expo-router";
import { useEffect } from "react";
import { KeyboardAvoidingView, Platform, ScrollView, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { FadeIn } from "@/components/motion/fade-in";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { SelectField } from "@/components/ui/select-field";
import { StepProgress } from "@/components/ui/step-progress";
import { TextField } from "@/components/ui/text-field";
import { useTutorApplicationStore } from "@/store/tutor-application.store";
import type { OfferDuration } from "@/types/tutor-application";

const TUTOR_FORMAT_ROUTE = "/tutor-format" as Href;
const TUTOR_SKILLS_ROUTE = "/tutor-skills" as Href;
const TOTAL_STEPS = 9;

// The spec doesn't define a duration catalog — a small fixed set matching the
// durations already used across the mocked Offer/Tutor data, flagged rather
// than invented as business rule (AGENTS.md §11).
const DURATION_OPTIONS: OfferDuration[] = [
  { id: "1h", label: "1 heure" },
  { id: "1h30", label: "1 heure 30" },
  { id: "2h", label: "2 heures" },
  { id: "3h", label: "3 heures" },
];

export function TutorOfferScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const skills = useTutorApplicationStore((s) => s.skills);
  const subjectLevels = useTutorApplicationStore((s) => s.subjectLevels);
  const offer = useTutorApplicationStore((s) => s.offer);
  const setOffer = useTutorApplicationStore((s) => s.setOffer);

  // Guard: an offer needs a skill to attach to — a direct/stale visit bounces
  // back to TutorSkills (AGENTS.md §13).
  useEffect(() => {
    if (skills.length === 0) router.replace(TUTOR_SKILLS_ROUTE);
  }, [skills.length, router]);

  if (skills.length === 0) return null;

  const availableLevels = subjectLevels.find((sl) => sl.skill.id === offer.skill?.id)?.levels ?? [];

  const canContinue =
    !!offer.skill &&
    !!offer.level &&
    offer.title.trim().length > 0 &&
    offer.description.trim().length > 0 &&
    !!offer.duration;

  return (
    <KeyboardAvoidingView
      className="flex-1 bg-paper"
      style={{ paddingTop: insets.top }}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <AuthHeader onBack={() => router.back()} />
      <StepProgress step={6} total={TOTAL_STEPS} />

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={40}>
          <Text className="mb-1 text-[24px] font-bold text-ink">Que proposez-vous&nbsp;?</Text>
          <Text className="mb-5 text-[13.5px] text-ink-soft">Créez votre première offre de tutorat</Text>
        </FadeIn>

        <FadeIn delay={90}>
          <SelectField
            label="Matière"
            value={offer.skill}
            options={skills}
            onSelect={(option) => {
              const skill = skills.find((s) => s.id === option.id) ?? null;
              // Changing the subject invalidates the previously chosen level
              // (each subject has its own set of taught levels, from TutorSubjects).
              setOffer({ skill, level: null });
            }}
          />
          <SelectField
            label="Niveau"
            value={offer.level}
            options={availableLevels}
            placeholder={offer.skill ? "Sélectionner" : "Choisissez d'abord une matière"}
            disabled={!offer.skill}
            onSelect={(option) => {
              const level = availableLevels.find((l) => l.id === option.id) ?? null;
              setOffer({ level });
            }}
          />
          <TextField
            label="Titre"
            value={offer.title}
            onChangeText={(title) => setOffer({ title })}
            placeholder="Python pour débutants"
          />
          <View className="mb-[14px]">
            <Text className="mb-[6px] ml-0.5 text-[12.5px] font-semibold uppercase tracking-[0.03em] text-ink-soft">
              Description
            </Text>
            <TextInput
              value={offer.description}
              onChangeText={(description) => setOffer({ description })}
              placeholder="Une introduction concrète à Python…"
              placeholderTextColor="#9799AF"
              multiline
              textAlignVertical="top"
              className="h-[90px] rounded-sm border border-line bg-surface px-[14px] py-[13px] text-[15px] text-ink"
              accessibilityLabel="Description de l'offre"
            />
          </View>
          <SelectField
            label="Durée"
            value={offer.duration}
            options={DURATION_OPTIONS}
            onSelect={(option) => {
              const duration = DURATION_OPTIONS.find((d) => d.id === option.id) ?? null;
              setOffer({ duration });
            }}
          />
        </FadeIn>
      </ScrollView>

      <View
        className="border-t border-line-soft bg-surface px-5 pt-4"
        style={{ paddingBottom: Math.max(insets.bottom, 22) }}
      >
        <Button label="Continuer" disabled={!canContinue} onPress={() => router.push(TUTOR_FORMAT_ROUTE)} />
      </View>
    </KeyboardAvoidingView>
  );
}
