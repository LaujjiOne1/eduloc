import { type Href, useRouter } from "expo-router";
import { ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { PlusIcon } from "@/components/icons";
import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { CheckboxCard } from "@/components/ui/selectable-card";
import { StepProgress } from "@/components/ui/step-progress";
import { type TutorSkillCatalogState, useTutorSkillCatalog } from "@/hooks/use-tutor-skill-catalog";
import { useTutorApplicationStore } from "@/store/tutor-application.store";
import type { TutorSkill } from "@/types/tutor-application";

const TUTOR_SUBJECTS_ROUTE = "/tutor-subjects" as Href;
const TOTAL_STEPS = 9;

export function TutorSkillsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { state, retry } = useTutorSkillCatalog();
  const skills = useTutorApplicationStore((s) => s.skills);
  const toggleSkill = useTutorApplicationStore((s) => s.toggleSkill);

  const canContinue = skills.length > 0;

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />
      <StepProgress step={3} total={TOTAL_STEPS} />

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }}
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={40}>
          <Text className="mb-1 text-[24px] font-bold text-ink">Qu&apos;enseignez-vous&nbsp;?</Text>
          <Text className="mb-5 text-[13.5px] text-ink-soft">Sélectionnez toutes vos compétences</Text>
        </FadeIn>

        <SkillList
          state={state}
          onRetry={retry}
          selectedIds={new Set(skills.map((s) => s.id))}
          onToggle={toggleSkill}
        />

        <FadeIn delay={220}>
          {/* "Ajouter une compétence" (custom, free-text skill) needs its own
              screen/spec — out of scope for this task, shown inert. */}
          <View className="mt-[6px] flex-row items-center gap-2 opacity-50">
            <PlusIcon size={16} color="#332E86" />
            <Text className="text-[14px] font-bold text-primary">Ajouter une compétence</Text>
          </View>
        </FadeIn>
      </ScrollView>

      <View
        className="border-t border-line-soft bg-surface px-5 pt-4"
        style={{ paddingBottom: Math.max(insets.bottom, 22) }}
      >
        <Button
          label="Continuer"
          disabled={!canContinue}
          onPress={() => router.push(TUTOR_SUBJECTS_ROUTE)}
        />
      </View>
    </View>
  );
}

type SkillListProps = {
  state: TutorSkillCatalogState;
  onRetry: () => void;
  selectedIds: Set<string>;
  onToggle: (skill: TutorSkill) => void;
};

function SkillList({ state, onRetry, selectedIds, onToggle }: SkillListProps) {
  if (state.status === "loading") {
    return (
      <View className="gap-[10px]">
        {[0, 1, 2, 3, 4].map((i) => (
          <View key={i} className="h-[54px] rounded-lg bg-line-soft" />
        ))}
      </View>
    );
  }

  if (state.status === "error") {
    return (
      <View className="flex-row items-center gap-3">
        <Text className="flex-1 text-[13.5px] text-error">{state.message}</Text>
        <PressableScale onPress={onRetry} accessibilityLabel="Réessayer de charger les compétences">
          <Text className="text-[13.5px] font-semibold text-primary">Réessayer</Text>
        </PressableScale>
      </View>
    );
  }

  if (state.status === "empty") {
    return <Text className="text-[13.5px] text-ink-faint">Aucune compétence disponible pour le moment.</Text>;
  }

  return (
    <View className="gap-[10px]">
      {state.skills.map((skill, index) => (
        <FadeIn key={skill.id} delay={90 + index * 40}>
          <CheckboxCard
            label={skill.label}
            selected={selectedIds.has(skill.id)}
            onPress={() => onToggle(skill)}
          />
        </FadeIn>
      ))}
    </View>
  );
}
