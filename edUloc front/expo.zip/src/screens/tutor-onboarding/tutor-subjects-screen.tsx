import { type Href, useRouter } from "expo-router";
import { useEffect } from "react";
import { ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { FadeIn } from "@/components/motion/fade-in";
import { PressableScale } from "@/components/motion/pressable-scale";
import { AuthHeader } from "@/components/ui/auth-header";
import { Button } from "@/components/ui/button";
import { Chip } from "@/components/ui/chip";
import { StepProgress } from "@/components/ui/step-progress";
import { useLevels } from "@/hooks/use-levels";
import { useTutorApplicationStore } from "@/store/tutor-application.store";
import type { EducationLevel } from "@/types/search";

const TUTOR_BIO_ROUTE = "/tutor-bio" as Href;
const TUTOR_SKILLS_ROUTE = "/tutor-skills" as Href;
const TOTAL_STEPS = 9;

export function TutorSubjectsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { state: levelsState, retry } = useLevels();
  const skills = useTutorApplicationStore((s) => s.skills);
  const subjectLevels = useTutorApplicationStore((s) => s.subjectLevels);
  const toggleSubjectLevel = useTutorApplicationStore((s) => s.toggleSubjectLevel);

  // Guard: this step only makes sense once at least one skill was picked on
  // TutorSkills — a direct/stale visit bounces back there (AGENTS.md §13).
  useEffect(() => {
    if (skills.length === 0) router.replace(TUTOR_SKILLS_ROUTE);
  }, [skills.length, router]);

  if (skills.length === 0) return null;

  const canContinue = skills.every(
    (skill) => (subjectLevels.find((sl) => sl.skill.id === skill.id)?.levels.length ?? 0) > 0,
  );

  return (
    <View className="flex-1 bg-paper" style={{ paddingTop: insets.top }}>
      <AuthHeader onBack={() => router.back()} />
      <StepProgress step={4} total={TOTAL_STEPS} />

      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }}
        showsVerticalScrollIndicator={false}
      >
        <FadeIn delay={40}>
          <Text className="mb-1 text-[24px] font-bold text-ink">Matières et niveaux</Text>
          <Text className="mb-5 text-[13.5px] text-ink-soft">
            Pour chaque compétence, précisez les niveaux
          </Text>
        </FadeIn>

        {levelsState.status === "loading" ? (
          <View className="gap-3">
            {skills.map((skill) => (
              <View key={skill.id} className="h-[92px] rounded-lg bg-line-soft" />
            ))}
          </View>
        ) : levelsState.status === "error" ? (
          <View className="flex-row items-center gap-3">
            <Text className="flex-1 text-[13.5px] text-error">{levelsState.message}</Text>
            <PressableScale onPress={retry} accessibilityLabel="Réessayer de charger les niveaux">
              <Text className="text-[13.5px] font-semibold text-primary">Réessayer</Text>
            </PressableScale>
          </View>
        ) : levelsState.status === "empty" ? (
          <Text className="text-[13.5px] text-ink-faint">Aucun niveau disponible pour le moment.</Text>
        ) : (
          <View className="gap-3">
            {skills.map((skill, index) => {
              const chosenLevels = subjectLevels.find((sl) => sl.skill.id === skill.id)?.levels ?? [];
              return (
                <FadeIn key={skill.id} delay={90 + index * 40}>
                  <SubjectCard
                    label={skill.label}
                    levels={levelsState.levels}
                    chosenLevels={chosenLevels}
                    onToggleLevel={(level) => toggleSubjectLevel(skill, level)}
                  />
                </FadeIn>
              );
            })}
          </View>
        )}
      </ScrollView>

      <View
        className="border-t border-line-soft bg-surface px-5 pt-4"
        style={{ paddingBottom: Math.max(insets.bottom, 22) }}
      >
        <Button label="Continuer" disabled={!canContinue} onPress={() => router.push(TUTOR_BIO_ROUTE)} />
      </View>
    </View>
  );
}

type SubjectCardProps = {
  label: string;
  levels: EducationLevel[];
  chosenLevels: EducationLevel[];
  onToggleLevel: (level: EducationLevel) => void;
};

function SubjectCard({ label, levels, chosenLevels, onToggleLevel }: SubjectCardProps) {
  const chosenIds = new Set(chosenLevels.map((l) => l.id));

  return (
    <View className="rounded-lg border border-line bg-surface p-4">
      <Text className="mb-[10px] text-[15px] font-bold text-ink">{label}</Text>
      <View className="flex-row flex-wrap gap-2">
        {levels.map((level) => (
          <Chip
            key={level.id}
            label={level.label}
            active={chosenIds.has(level.id)}
            onPress={() => onToggleLevel(level)}
          />
        ))}
      </View>
    </View>
  );
}
