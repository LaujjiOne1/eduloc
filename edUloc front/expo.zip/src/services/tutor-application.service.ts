import type {
  TutorApplication,
  TutorApplicationSubmission,
  TutorSkill,
} from "@/types/tutor-application";

export class TutorApplicationServiceError extends Error {
  code: "validation_error" | "unauthorized";

  constructor(code: "validation_error" | "unauthorized", message: string) {
    super(message);
    this.code = code;
  }
}

/**
 * Backend contract (not yet implemented server-side):
 *
 *   GET /tutor-applications/skills
 *   Auth:      none (public reference data)
 *   Response:  TutorSkill[]
 *   Errors:    500
 *
 *   POST /tutor-applications
 *   Auth:      required (Bearer token) — applying to become a tutor upgrades
 *              an existing EduLoc account, it doesn't create a new one.
 *   Body:      TutorApplicationSubmission
 *   Response:  TutorApplication (status: "pending" — an EduLoc reviewer must
 *              approve it before the tutor is publicly searchable, per
 *              50_TutorApplicationPending's "vous n'apparaissez pas dans les
 *              résultats de recherche" note)
 *   Errors:    401 unauthorized, 422 validation_error, 500
 *
 * Until these endpoints exist, this returns mocked data so the tutor
 * onboarding screens can be built against the final shape. Swap the mock
 * bodies for real HTTP calls here only — screens/hooks must not change.
 */
const MOCK_LATENCY_MS = 350;
const MOCK_SUBMIT_LATENCY_MS = 700;

const MOCK_SKILLS: TutorSkill[] = [
  { id: "python", label: "Python" },
  { id: "algorithmique", label: "Algorithmique" },
  { id: "javascript", label: "JavaScript" },
  { id: "sql", label: "SQL" },
  { id: "finance", label: "Finance" },
];

export const TutorApplicationService = {
  async getSkillCatalog(): Promise<TutorSkill[]> {
    return new Promise((resolve) => {
      setTimeout(() => resolve(MOCK_SKILLS), MOCK_LATENCY_MS);
    });
  },

  async submitApplication(_submission: TutorApplicationSubmission): Promise<TutorApplication> {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          id: `tutor-application-${Date.now()}`,
          status: "pending",
          submittedAt: new Date().toISOString(),
        });
      }, MOCK_SUBMIT_LATENCY_MS);
    });
  },
};
