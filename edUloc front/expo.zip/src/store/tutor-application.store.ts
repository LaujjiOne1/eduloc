import { create } from "zustand";

import type { EducationLevel, LocationFormatId } from "@/types/search";
import type {
  TutorApplication,
  TutorAvailabilityEntry,
  TutorBackgroundFields,
  TutorDocumentEntry,
  TutorDocumentKind,
  TutorIdentityFields,
  TutorLocationEntry,
  TutorOfferDraft,
  TutorSkill,
  TutorSubjectLevels,
} from "@/types/tutor-application";

const INITIAL_IDENTITY: TutorIdentityFields = {
  firstName: "",
  lastName: "",
  birthDate: "",
  phone: "",
  email: "",
};

const INITIAL_BACKGROUND: TutorBackgroundFields = {
  degree: null,
  field: "",
  institution: "",
  experience: "",
};

const INITIAL_OFFER: TutorOfferDraft = {
  skill: null,
  level: null,
  title: "",
  description: "",
  duration: null,
};

// Fixed document categories the mock always shows (48_TutorDocuments) — not
// fetched from a catalog since they're structural, not backend reference data.
const INITIAL_DOCUMENTS: TutorDocumentEntry[] = [
  { kind: "proof_of_identity", label: "Pièce justificative", provided: false },
  { kind: "diploma", label: "Diplôme", provided: false },
  { kind: "other", label: "Autre document", provided: false },
];

interface TutorApplicationStore {
  identity: TutorIdentityFields;
  background: TutorBackgroundFields;
  skills: TutorSkill[];
  subjectLevels: TutorSubjectLevels[];
  bio: string;
  offer: TutorOfferDraft;
  formats: LocationFormatId[];
  locations: TutorLocationEntry[];
  availability: TutorAvailabilityEntry[];
  documents: TutorDocumentEntry[];
  /** Set once submission succeeds — guards TutorApplicationPending against a stale/direct visit. */
  application: TutorApplication | null;

  setIdentity: (fields: Partial<TutorIdentityFields>) => void;
  setBackground: (fields: Partial<TutorBackgroundFields>) => void;
  toggleSkill: (skill: TutorSkill) => void;
  toggleSubjectLevel: (skill: TutorSkill, level: EducationLevel) => void;
  setBio: (bio: string) => void;
  setOffer: (fields: Partial<TutorOfferDraft>) => void;
  toggleFormat: (format: LocationFormatId) => void;
  toggleDocument: (kind: TutorDocumentKind) => void;
  setApplication: (application: TutorApplication) => void;
  reset: () => void;
}

/**
 * Holds the whole "devenir tuteur" wizard (38_TutorIntro → 50_TutorApplicationPending)
 * so nothing is lost while the applicant moves back and forth between the 13
 * steps (AGENTS.md §13: navigation must never drop already-entered data).
 * Reset once the application has actually been submitted (TutorApplicationPending's
 * "Retour à l'accueil"), mirroring useBookingWizardStore.
 */
export const useTutorApplicationStore = create<TutorApplicationStore>((set) => ({
  identity: INITIAL_IDENTITY,
  background: INITIAL_BACKGROUND,
  skills: [],
  subjectLevels: [],
  bio: "",
  offer: INITIAL_OFFER,
  formats: [],
  locations: [],
  availability: [],
  documents: INITIAL_DOCUMENTS,
  application: null,

  setIdentity: (fields) => set((s) => ({ identity: { ...s.identity, ...fields } })),

  setBackground: (fields) => set((s) => ({ background: { ...s.background, ...fields } })),

  toggleSkill: (skill) =>
    set((s) => {
      const exists = s.skills.some((sk) => sk.id === skill.id);
      return {
        skills: exists ? s.skills.filter((sk) => sk.id !== skill.id) : [...s.skills, skill],
        // Drop the skill's chosen teaching levels along with it, and clear it
        // from the offer draft if it was the one selected there.
        subjectLevels: exists ? s.subjectLevels.filter((sl) => sl.skill.id !== skill.id) : s.subjectLevels,
      };
    }),

  toggleSubjectLevel: (skill, level) =>
    set((s) => {
      const index = s.subjectLevels.findIndex((sl) => sl.skill.id === skill.id);
      if (index === -1) {
        return { subjectLevels: [...s.subjectLevels, { skill, levels: [level] }] };
      }
      const entry = s.subjectLevels[index];
      const hasLevel = entry.levels.some((l) => l.id === level.id);
      const levels = hasLevel ? entry.levels.filter((l) => l.id !== level.id) : [...entry.levels, level];
      const next = [...s.subjectLevels];
      next[index] = { ...entry, levels };
      return { subjectLevels: next };
    }),

  setBio: (bio) => set({ bio }),

  setOffer: (fields) => set((s) => ({ offer: { ...s.offer, ...fields } })),

  toggleFormat: (format) =>
    set((s) => ({
      formats: s.formats.includes(format) ? s.formats.filter((f) => f !== format) : [...s.formats, format],
    })),

  toggleDocument: (kind) =>
    set((s) => ({
      documents: s.documents.map((d) => (d.kind === kind ? { ...d, provided: !d.provided } : d)),
    })),

  setApplication: (application) => set({ application }),

  reset: () =>
    set({
      identity: INITIAL_IDENTITY,
      background: INITIAL_BACKGROUND,
      skills: [],
      subjectLevels: [],
      bio: "",
      offer: INITIAL_OFFER,
      formats: [],
      locations: [],
      availability: [],
      documents: INITIAL_DOCUMENTS,
      application: null,
    }),
}));
