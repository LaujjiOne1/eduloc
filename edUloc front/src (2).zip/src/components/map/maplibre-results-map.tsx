import { Text, View } from "react-native";

import type { Tutor } from "@/types/tutor";

export type MapLibreResultsMapProps = {
  tutors: Tutor[];
  selectedTutorId: string | null;
  onSelectTutor: (tutor: Tutor) => void;
  searchLocationQuery?: string;
};

export function MapLibreResultsMap(_props: MapLibreResultsMapProps) {
  return (
    <View className="flex-1 items-center justify-center bg-paper-alt px-8">
      <Text className="text-center text-[13.5px] text-ink-soft">
        La carte est disponible dans l&apos;application mobile.
      </Text>
    </View>
  );
}
