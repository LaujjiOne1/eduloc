import * as React from "react";
import { Pressable, Text, View } from "react-native";
import { Gesture, GestureDetector } from "react-native-gesture-handler";
import Animated, {
  Extrapolation,
  interpolate,
  runOnJS,
  type SharedValue,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";

import { cn } from "@/lib/utils";

export interface DateWheelPickerProps {
  value?: Date;
  onChange: (date: Date) => void;
  minYear?: number;
  maxYear?: number;
  size?: "sm" | "md" | "lg";
  disabled?: boolean;
  locale?: string;
  onDecadeSelect?: (year: number) => void;
  className?: string;
}

const VISIBLE_ITEMS = 5;
const SPRING_CONFIG = { damping: 32, stiffness: 320 };

function getMonthNames(locale = "fr-FR"): string[] {
  const formatter = new Intl.DateTimeFormat(locale, { month: "long" });
  return Array.from({ length: 12 }, (_, i) => {
    const raw = formatter.format(new Date(2000, i, 1));
    return raw.charAt(0).toUpperCase() + raw.slice(1);
  });
}

const sizeConfig = {
  sm: {
    itemHeight: 32,
    fontSize: "text-sm",
  },
  md: {
    itemHeight: 40,
    fontSize: "text-base",
  },
  lg: {
    itemHeight: 48,
    fontSize: "text-lg",
  },
};

interface WheelItemProps {
  item: string | number;
  index: number;
  y: SharedValue<number>;
  itemHeight: number;
  visibleItems: number;
  centerOffset: number;
  isSelected: boolean;
  fontSizeClassName: string;
}

function WheelItem({
  item,
  index,
  y,
  itemHeight,
  visibleItems,
  centerOffset,
  isSelected,
  fontSizeClassName,
}: WheelItemProps) {
  const animatedStyle = useAnimatedStyle(() => {
    const itemY = index * itemHeight + y.value + centerOffset;
    const range = itemHeight * visibleItems;

    const rotateX = interpolate(itemY, [0, centerOffset, range], [45, 0, -45], Extrapolation.CLAMP);
    const scale = interpolate(itemY, [0, centerOffset, range], [0.85, 1.05, 0.85], Extrapolation.CLAMP);
    const opacity = interpolate(
      itemY,
      [0, centerOffset * 0.5, centerOffset, centerOffset * 1.5, range],
      [0.25, 0.55, 1, 0.55, 0.25],
      Extrapolation.CLAMP
    );

    return {
      height: itemHeight,
      opacity,
      transform: [{ perspective: 1000 }, { rotateX: `${rotateX}deg` }, { scale }],
    };
  });

  return (
    <Animated.View className="items-center justify-center" style={animatedStyle}>
      <Text
        numberOfLines={1}
        className={cn(
          fontSizeClassName,
          "px-1",
          isSelected ? "font-bold text-primary" : "font-medium text-[#606482]"
        )}
      >
        {item}
      </Text>
    </Animated.View>
  );
}

interface WheelColumnProps {
  items: (string | number)[];
  value: number;
  onChange: (index: number) => void;
  itemHeight: number;
  visibleItems: number;
  disabled?: boolean;
  className?: string;
  fontSizeClassName: string;
  ariaLabel: string;
}

function WheelColumn({
  items,
  value,
  onChange,
  itemHeight,
  visibleItems,
  disabled,
  className,
  fontSizeClassName,
  ariaLabel,
}: WheelColumnProps) {
  const y = useSharedValue(-value * itemHeight);
  const startY = useSharedValue(0);
  const centerOffset = Math.floor(visibleItems / 2) * itemHeight;
  const maxIndex = items.length - 1;

  React.useEffect(() => {
    y.value = withSpring(-value * itemHeight, SPRING_CONFIG);
  }, [value, itemHeight, y]);

  const panGesture = Gesture.Pan()
    .enabled(!disabled)
    .onStart(() => {
      startY.value = y.value;
    })
    .onUpdate((e) => {
      const min = -maxIndex * itemHeight;
      let next = startY.value + e.translationY;
      if (next > 0) next *= 0.15;
      else if (next < min) next = min + (next - min) * 0.15;
      y.value = next;
    })
    .onEnd((e) => {
      const dragDistance = Math.abs(e.translationY);

      if (dragDistance < 4) {
        const tapped = Math.round((e.y - centerOffset - y.value) / itemHeight);
        const idx = Math.min(maxIndex, Math.max(0, tapped));
        y.value = withSpring(-idx * itemHeight, SPRING_CONFIG);
        runOnJS(onChange)(idx);
        return;
      }

      const projectedY = y.value + e.velocityY * 0.2;
      let newIndex = Math.round(-projectedY / itemHeight);
      newIndex = Math.min(maxIndex, Math.max(0, newIndex));
      y.value = withSpring(-newIndex * itemHeight, SPRING_CONFIG);
      runOnJS(onChange)(newIndex);
    });

  return (
    <GestureDetector gesture={panGesture}>
      <View
        className={cn("relative overflow-hidden", disabled && "opacity-50", className)}
        style={{ height: itemHeight * visibleItems }}
        accessibilityRole="adjustable"
        accessibilityLabel={ariaLabel}
        accessibilityValue={{ text: String(items[value]) }}
        accessibilityState={{ disabled: !!disabled }}
      >
        {/* Center Highlight Bar (EduLoc border & tint) */}
        <View
          pointerEvents="none"
          className="absolute inset-x-0 border-y border-[#332E86]/25 bg-[#332E86]/5 rounded-sm"
          style={{ top: centerOffset, height: itemHeight }}
        />

        {items.map((item, index) => (
          <WheelItem
            key={`${item}-${index}`}
            item={item}
            index={index}
            y={y}
            itemHeight={itemHeight}
            visibleItems={visibleItems}
            centerOffset={centerOffset}
            isSelected={index === value}
            fontSizeClassName={fontSizeClassName}
          />
        ))}
      </View>
    </GestureDetector>
  );
}

function getDaysInMonth(year: number, month: number): number {
  return new Date(year, month + 1, 0).getDate();
}

export function DateWheelPicker({
  value,
  onChange,
  minYear = 1920,
  maxYear = new Date().getFullYear() - 15,
  size = "md",
  disabled = false,
  locale = "fr-FR",
  className,
}: DateWheelPickerProps) {
  const config = sizeConfig[size];

  const months = React.useMemo(() => getMonthNames(locale), [locale]);

  // Years descending: e.g. 2011, 2010, ... 1997 ... 1920
  const years = React.useMemo(() => {
    const arr: number[] = [];
    for (let y = maxYear; y >= minYear; y--) {
      arr.push(y);
    }
    return arr;
  }, [minYear, maxYear]);

  const [dateState, setDateState] = React.useState(() => {
    const currentDate = value || new Date(1997, 4, 12);
    return {
      day: currentDate.getDate(),
      month: currentDate.getMonth(),
      year: currentDate.getFullYear(),
    };
  });

  const isInternalChange = React.useRef(false);

  const days = React.useMemo(() => {
    const daysCount = getDaysInMonth(dateState.year, dateState.month);
    return Array.from({ length: daysCount }, (_, i) => i + 1);
  }, [dateState.month, dateState.year]);

  const handleDayChange = React.useCallback((dayIndex: number) => {
    isInternalChange.current = true;
    setDateState((prev) => ({ ...prev, day: dayIndex + 1 }));
  }, []);

  const handleMonthChange = React.useCallback((monthIndex: number) => {
    isInternalChange.current = true;
    setDateState((prev) => {
      const daysInNewMonth = getDaysInMonth(prev.year, monthIndex);
      const adjustedDay = Math.min(prev.day, daysInNewMonth);
      return { ...prev, month: monthIndex, day: adjustedDay };
    });
  }, []);

  const handleYearChange = React.useCallback(
    (yearIndex: number) => {
      isInternalChange.current = true;
      setDateState((prev) => {
        const newYear = years[yearIndex];
        const daysInNewMonth = getDaysInMonth(newYear, prev.month);
        const adjustedDay = Math.min(prev.day, daysInNewMonth);
        return { ...prev, year: newYear, day: adjustedDay };
      });
    },
    [years]
  );

  React.useEffect(() => {
    if (isInternalChange.current) {
      const newDate = new Date(dateState.year, dateState.month, dateState.day);
      onChange(newDate);
      isInternalChange.current = false;
    }
  }, [dateState, onChange]);

  React.useEffect(() => {
    if (value && !isInternalChange.current) {
      const valueDay = value.getDate();
      const valueMonth = value.getMonth();
      const valueYear = value.getFullYear();

      if (
        valueDay !== dateState.day ||
        valueMonth !== dateState.month ||
        valueYear !== dateState.year
      ) {
        setDateState({
          day: valueDay,
          month: valueMonth,
          year: valueYear,
        });
      }
    }
  }, [value, dateState.day, dateState.month, dateState.year]);

  const yearIndex = years.indexOf(dateState.year);

  // Jump to a specific decade or year
  const jumpToYear = React.useCallback(
    (targetYear: number) => {
      const idx = years.indexOf(targetYear);
      if (idx >= 0) {
        handleYearChange(idx);
      }
    },
    [years, handleYearChange]
  );

  return (
    <View
      className={cn("items-center justify-center w-full", disabled && "opacity-50", className)}
      accessibilityRole="none"
      accessibilityLabel="Date wheel picker"
    >
      {/* Quick decade jump bar */}
      <View className="flex-row items-center justify-center gap-1.5 mb-2 w-full flex-wrap">
        <Text className="text-[11px] font-bold uppercase tracking-wider text-[#9799AF] mr-1">
          Décennie :
        </Text>
        {[2000, 1990, 1980, 1970, 1960].map((dec) => {
          const isCurrentDecade = Math.floor(dateState.year / 10) * 10 === dec;
          return (
            <Pressable
              key={dec}
              disabled={disabled}
              onPress={() => jumpToYear(dec + 5)}
              className={cn(
                "px-2 py-0.5 rounded-full border",
                isCurrentDecade
                  ? "bg-primary border-primary"
                  : "bg-[#F7F6F2] border-[#E7E3D7]"
              )}
            >
              <Text
                className={cn(
                  "text-[11.5px] font-bold",
                  isCurrentDecade ? "text-white" : "text-[#606482]"
                )}
              >
                {dec}s
              </Text>
            </Pressable>
          );
        })}
      </View>

      {/* 3D Wheel Pickers in Row: Jour (Day), Mois (Month), Année (Year) */}
      <View className="flex-row items-center justify-center w-full gap-3 rounded-xl border border-[#E7E3D7] bg-white px-2 py-1 shadow-inner">
        {/* Day Column */}
        <View className="items-center">
          <Text className="text-[10.5px] font-bold uppercase tracking-wider text-[#9799AF] mb-0.5">
            Jour
          </Text>
          <WheelColumn
            items={days}
            value={dateState.day - 1}
            onChange={handleDayChange}
            itemHeight={config.itemHeight}
            visibleItems={VISIBLE_ITEMS}
            disabled={disabled}
            className="w-14"
            fontSizeClassName={config.fontSize}
            ariaLabel="Sélectionner le jour"
          />
        </View>

        <View className="h-28 w-[1px] bg-[#E7E3D7]" />

        {/* Month Column */}
        <View className="items-center">
          <Text className="text-[10.5px] font-bold uppercase tracking-wider text-[#9799AF] mb-0.5">
            Mois
          </Text>
          <WheelColumn
            items={months}
            value={dateState.month}
            onChange={handleMonthChange}
            itemHeight={config.itemHeight}
            visibleItems={VISIBLE_ITEMS}
            disabled={disabled}
            className="w-32"
            fontSizeClassName={config.fontSize}
            ariaLabel="Sélectionner le mois"
          />
        </View>

        <View className="h-28 w-[1px] bg-[#E7E3D7]" />

        {/* Year Column */}
        <View className="items-center">
          <Text className="text-[10.5px] font-bold uppercase tracking-wider text-[#9799AF] mb-0.5">
            Année
          </Text>
          <WheelColumn
            items={years}
            value={yearIndex >= 0 ? yearIndex : 0}
            onChange={handleYearChange}
            itemHeight={config.itemHeight}
            visibleItems={VISIBLE_ITEMS}
            disabled={disabled}
            className="w-20"
            fontSizeClassName={config.fontSize}
            ariaLabel="Sélectionner l'année"
          />
        </View>
      </View>
    </View>
  );
}
