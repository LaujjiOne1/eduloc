import * as React from "react";
import { Text, View } from "react-native";
import { Gesture, GestureDetector } from "react-native-gesture-handler";
import Animated, {
  Extrapolation,
  interpolate,
  runOnJS,
  type SharedValue,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";

import { cn } from "@/lib/utils";

export type TimeWheelPickerProps = {
  startTime: string; // e.g. "09:00"
  endTime: string; // e.g. "10:00"
  onChangeStart: (time: string) => void;
  onChangeEnd: (time: string) => void;
  disabled?: boolean;
};

const ITEM_HEIGHT = 38;
const VISIBLE_ITEMS = 3;
const SPRING_CONFIG = { damping: 30, stiffness: 350 };

const HOURS: string[] = Array.from({ length: 24 }, (_, i) => String(i).padStart(2, "0"));
const MINUTES: string[] = ["00", "15", "30", "45"];

interface WheelItemProps {
  item: string;
  index: number;
  y: SharedValue<number>;
  itemHeight: number;
  visibleItems: number;
  centerOffset: number;
  isSelected: boolean;
}

function WheelItem({
  item,
  index,
  y,
  itemHeight,
  visibleItems,
  centerOffset,
  isSelected,
}: WheelItemProps) {
  const animatedStyle = useAnimatedStyle(() => {
    const itemY = index * itemHeight + y.value + centerOffset;
    const range = itemHeight * visibleItems;

    const rotateX = interpolate(itemY, [0, centerOffset, range], [35, 0, -35], Extrapolation.CLAMP);
    const scale = interpolate(itemY, [0, centerOffset, range], [0.85, 1.08, 0.85], Extrapolation.CLAMP);
    const opacity = interpolate(
      itemY,
      [0, centerOffset * 0.5, centerOffset, centerOffset * 1.5, range],
      [0.3, 0.6, 1, 0.6, 0.3],
      Extrapolation.CLAMP
    );

    return {
      height: itemHeight,
      opacity,
      transform: [{ perspective: 800 }, { rotateX: `${rotateX}deg` }, { scale }],
    };
  });

  return (
    <Animated.View className="items-center justify-center" style={animatedStyle}>
      <Text
        className={cn(
          "text-center font-bold tabular-nums px-1",
          isSelected ? "text-[21px] text-primary" : "text-[16px] text-ink-soft"
        )}
      >
        {item}
      </Text>
    </Animated.View>
  );
}

interface SingleWheelProps {
  items: string[];
  value: number;
  onChange: (index: number) => void;
  disabled?: boolean;
  ariaLabel: string;
  width?: string;
}

function SingleWheel({
  items,
  value,
  onChange,
  disabled,
  ariaLabel,
  width = "w-14",
}: SingleWheelProps) {
  const y = useSharedValue(-value * ITEM_HEIGHT);
  const startY = useSharedValue(0);
  const centerOffset = Math.floor(VISIBLE_ITEMS / 2) * ITEM_HEIGHT;
  const maxIndex = items.length - 1;

  React.useEffect(() => {
    y.value = withSpring(-value * ITEM_HEIGHT, SPRING_CONFIG);
  }, [value, y]);

  const panGesture = Gesture.Pan()
    .enabled(!disabled)
    .onStart(() => {
      startY.value = y.value;
    })
    .onUpdate((e) => {
      const min = -maxIndex * ITEM_HEIGHT;
      let next = startY.value + e.translationY;
      if (next > 0) next *= 0.15;
      else if (next < min) next = min + (next - min) * 0.15;
      y.value = next;
    })
    .onEnd((e) => {
      const dragDistance = Math.abs(e.translationY);

      if (dragDistance < 4) {
        const tapped = Math.round((e.y - centerOffset - y.value) / ITEM_HEIGHT);
        const idx = Math.min(maxIndex, Math.max(0, tapped));
        y.value = withSpring(-idx * ITEM_HEIGHT, SPRING_CONFIG);
        runOnJS(onChange)(idx);
        return;
      }

      const projectedY = y.value + e.velocityY * 0.15;
      let newIndex = Math.round(-projectedY / ITEM_HEIGHT);
      newIndex = Math.min(maxIndex, Math.max(0, newIndex));
      y.value = withSpring(-newIndex * ITEM_HEIGHT, SPRING_CONFIG);
      runOnJS(onChange)(newIndex);
    });

  return (
    <GestureDetector gesture={panGesture}>
      <View
        className={cn(
          "relative overflow-hidden bg-surface/50 rounded-lg",
          width,
          disabled && "opacity-50"
        )}
        style={{ height: ITEM_HEIGHT * VISIBLE_ITEMS }}
        accessibilityRole="adjustable"
        accessibilityLabel={ariaLabel}
        accessibilityValue={{ text: items[value] }}
        accessibilityState={{ disabled: !!disabled }}
      >
        {/* Center highlight band */}
        <View
          pointerEvents="none"
          className="absolute left-0 right-0 rounded-md border-y border-primary/20 bg-primary/8"
          style={{ top: centerOffset, height: ITEM_HEIGHT }}
        />

        {items.map((item, index) => (
          <WheelItem
            key={`${item}-${index}`}
            item={item}
            index={index}
            y={y}
            itemHeight={ITEM_HEIGHT}
            visibleItems={VISIBLE_ITEMS}
            centerOffset={centerOffset}
            isSelected={index === value}
          />
        ))}
      </View>
    </GestureDetector>
  );
}

export function TimeWheelPicker({
  startTime,
  endTime,
  onChangeStart,
  onChangeEnd,
  disabled = false,
}: TimeWheelPickerProps) {
  // Parse start hours and minutes
  const [startH, startM] = (startTime || "09:00").split(":");
  const startHourIndex = Math.max(0, HOURS.indexOf(startH));
  const startMinIndex = Math.max(
    0,
    MINUTES.findIndex((m) => Number(m) >= Number(startM))
  );

  // Parse end hours and minutes
  const [endH, endM] = (endTime || "10:00").split(":");
  const endHourIndex = Math.max(0, HOURS.indexOf(endH));
  const endMinIndex = Math.max(
    0,
    MINUTES.findIndex((m) => Number(m) >= Number(endM))
  );

  const handleStartHourChange = (idx: number) => {
    const newH = HOURS[idx];
    const currM = MINUTES[startMinIndex >= 0 ? startMinIndex : 0];
    onChangeStart(`${newH}:${currM}`);
  };

  const handleStartMinChange = (idx: number) => {
    const currH = HOURS[startHourIndex >= 0 ? startHourIndex : 9];
    const newM = MINUTES[idx];
    onChangeStart(`${currH}:${newM}`);
  };

  const handleEndHourChange = (idx: number) => {
    const newH = HOURS[idx];
    const currM = MINUTES[endMinIndex >= 0 ? endMinIndex : 0];
    onChangeEnd(`${newH}:${currM}`);
  };

  const handleEndMinChange = (idx: number) => {
    const currH = HOURS[endHourIndex >= 0 ? endHourIndex : 10];
    const newM = MINUTES[idx];
    onChangeEnd(`${currH}:${newM}`);
  };

  return (
    <View className="flex-row items-center justify-between gap-3 rounded-2xl border border-line bg-surface/70 p-4 shadow-2xs">
      {/* Start Time Section */}
      <View className="flex-1 items-center">
        <Text className="text-[12px] font-bold text-ink-soft uppercase tracking-wider mb-2">
          Début
        </Text>
        <View className="flex-row items-center gap-1.5 bg-paper rounded-xl p-1.5 border border-line">
          <SingleWheel
            items={HOURS}
            value={startHourIndex >= 0 ? startHourIndex : 9}
            onChange={handleStartHourChange}
            disabled={disabled}
            ariaLabel="Heure de début"
          />
          <Text className="text-[18px] font-bold text-primary">:</Text>
          <SingleWheel
            items={MINUTES}
            value={startMinIndex >= 0 ? startMinIndex : 0}
            onChange={handleStartMinChange}
            disabled={disabled}
            ariaLabel="Minute de début"
          />
        </View>
      </View>

      {/* Middle Arrow Divider */}
      <View className="items-center justify-center pt-5">
        <View className="h-7 w-7 rounded-full bg-primary-tint items-center justify-center">
          <Text className="text-[14px] font-bold text-primary leading-none">{"→"}</Text>
        </View>
      </View>

      {/* End Time Section */}
      <View className="flex-1 items-center">
        <Text className="text-[12px] font-bold text-ink-soft uppercase tracking-wider mb-2">
          Fin
        </Text>
        <View className="flex-row items-center gap-1.5 bg-paper rounded-xl p-1.5 border border-line">
          <SingleWheel
            items={HOURS}
            value={endHourIndex >= 0 ? endHourIndex : 10}
            onChange={handleEndHourChange}
            disabled={disabled}
            ariaLabel="Heure de fin"
          />
          <Text className="text-[18px] font-bold text-primary">:</Text>
          <SingleWheel
            items={MINUTES}
            value={endMinIndex >= 0 ? endMinIndex : 0}
            onChange={handleEndMinChange}
            disabled={disabled}
            ariaLabel="Minute de fin"
          />
        </View>
      </View>
    </View>
  );
}
