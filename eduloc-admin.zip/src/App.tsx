import React, { useState, useEffect, useCallback } from 'react';
import { AuthProvider, useAuth } from './lib/context/AuthContext';
import { LoginPage } from './components/auth/LoginPage';
import { AdminLayout } from './components/layout/AdminLayout';
import { NavSection } from './components/layout/Sidebar';
import { DashboardView } from './components/dashboard/DashboardView';
import { UsersView } from './components/users/UsersView';
import { UserDetailModal } from './components/users/UserDetailModal';
import { TutorsView } from './components/tutors/TutorsView';
import { TutorValidationSection } from './components/tutors/TutorValidationSection';
import { TutorDetailModal } from './components/tutors/TutorDetailModal';
import { ApprenticesView } from './components/apprentices/ApprenticesView';
import { ApprenticeDetailModal } from './components/apprentices/ApprenticeDetailModal';
import { OffersView } from './components/offers/OffersView';
import { OfferDetailModal } from './components/offers/OfferDetailModal';
import { BookingsView } from './components/bookings/BookingsView';
import { BookingDetailModal } from './components/bookings/BookingDetailModal';
import { ApiEndpointsDocModal } from './components/docs/ApiEndpointsDocModal';
import { ConfirmModal } from './components/ui/ConfirmModal';
import { ToastMessage } from './components/ui/Toast';

import { usersApi } from './lib/api/users';
import { tutorsApi } from './lib/api/tutors';
import { offersApi } from './lib/api/offers';
import { bookingsApi } from './lib/api/bookings';
import { dashboardApi } from './lib/api/dashboard';
import {
  User,
  TutorProfile,
  Offer,
  Booking,
  DashboardStats,
  UserStatus,
  UserRole,
  BookingStatus,
} from './types';

const AdminAppContent: React.FC = () => {
  const { isAuthenticated, isLoading: isAuthLoading } = useAuth();

  // Navigation State
  const [currentSection, setCurrentSection] = useState<NavSection>('dashboard');

  // Core Data State
  const [users, setUsers] = useState<User[]>([]);
  const [tutors, setTutors] = useState<TutorProfile[]>([]);
  const [offers, setOffers] = useState<Offer[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);

  const [isLoadingData, setIsLoadingData] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [dataError, setDataError] = useState<string | null>(null);

  // Selected Item Modals
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [selectedTutor, setSelectedTutor] = useState<TutorProfile | null>(null);
  const [selectedApprentice, setSelectedApprentice] = useState<User | null>(null);
  const [selectedOffer, setSelectedOffer] = useState<Offer | null>(null);
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [isApiDocsOpen, setIsApiDocsOpen] = useState<boolean>(false);

  // Confirmation Modals State
  const [confirmApproveTutor, setConfirmApproveTutor] = useState<TutorProfile | null>(null);
  const [confirmRejectTutor, setConfirmRejectTutor] = useState<TutorProfile | null>(null);
  const [rejectionReason, setRejectionReason] = useState<string>('');

  // Toast notifications
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = useCallback((toast: Omit<ToastMessage, 'id'>) => {
    const id = 'toast_' + Date.now() + Math.random().toString(36).substring(2, 5);
    setToasts((prev) => [...prev, { ...toast, id }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  }, []);

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Load all EduLoc data
  const loadData = useCallback(async () => {
    try {
      setDataError(null);
      const [fetchedUsers, fetchedTutors, fetchedOffers, fetchedBookings, fetchedStats] =
        await Promise.all([
          usersApi.getAll(),
          tutorsApi.getAll(),
          offersApi.getAll(),
          bookingsApi.getAll(),
          dashboardApi.getStats(),
        ]);

      setUsers(fetchedUsers);
      setTutors(fetchedTutors);
      setOffers(fetchedOffers);
      setBookings(fetchedBookings);
      setStats(fetchedStats);
    } catch (err: any) {
      console.error('Erreur de chargement des données:', err);
      setDataError(err.message || 'Impossible de synchroniser les données avec le serveur API.');
    } finally {
      setIsLoadingData(false);
      setIsRefreshing(false);
    }
  }, []);

  useEffect(() => {
    if (isAuthenticated) {
      loadData();
    }
  }, [isAuthenticated, loadData]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await loadData();
    addToast({
      type: 'info',
      title: 'Données synchronisées',
      message: 'Les compteurs et listes ont été mis à jour.',
    });
  };

  /* -------------------------------------------------------------
   * ACTION HANDLERS
   * ------------------------------------------------------------- */
  const handleApproveTutorConfirm = async () => {
    if (!confirmApproveTutor) return;
    try {
      const updated = await tutorsApi.approve(confirmApproveTutor.id);
      addToast({
        type: 'success',
        title: 'Tuteur approuvé avec succès',
        message: `Le profil de ${confirmApproveTutor.user.name} est maintenant actif et visible par les apprentis.`,
      });
      setConfirmApproveTutor(null);
      if (selectedTutor?.id === confirmApproveTutor.id) {
        setSelectedTutor(updated);
      }
      await loadData();
    } catch (err: any) {
      addToast({
        type: 'error',
        title: 'Erreur lors de l’approbation',
        message: err.message,
      });
    }
  };

  const handleRejectTutorConfirm = async () => {
    if (!confirmRejectTutor || !rejectionReason.trim()) return;
    try {
      const updated = await tutorsApi.reject(confirmRejectTutor.id, rejectionReason.trim());
      addToast({
        type: 'warning',
        title: 'Dossier tuteur refusé',
        message: `Le motif a été enregistré et notifié à ${confirmRejectTutor.user.name}.`,
      });
      setConfirmRejectTutor(null);
      setRejectionReason('');
      if (selectedTutor?.id === confirmRejectTutor.id) {
        setSelectedTutor(updated);
      }
      await loadData();
    } catch (err: any) {
      addToast({
        type: 'error',
        title: 'Erreur lors du refus',
        message: err.message,
      });
    }
  };

  const handleResendVerificationEmail = async (userId: string) => {
    try {
      const res = await usersApi.resendVerificationEmail(userId);
      addToast({
        type: 'success',
        title: 'Email expédié',
        message: res.message,
      });
    } catch (err: any) {
      addToast({
        type: 'error',
        title: 'Échec de l’envoi',
        message: err.message,
      });
    }
  };

  const handleUpdateUserStatus = async (userId: string, status: UserStatus) => {
    try {
      await usersApi.updateStatus(userId, status);
      addToast({
        type: 'info',
        title: 'Statut utilisateur modifié',
        message: `Le compte est désormais ${status === 'ACTIVE' ? 'actif' : 'suspendu'}.`,
      });
      await loadData();
    } catch (err: any) {
      addToast({
        type: 'error',
        title: 'Erreur',
        message: err.message,
      });
    }
  };

  const handleUpdateUserRole = async (userId: string, role: UserRole) => {
    try {
      await usersApi.updateRole(userId, role);
      addToast({
        type: 'success',
        title: 'Rôle modifié',
        message: `Le rôle a été changé en ${role}.`,
      });
      await loadData();
    } catch (err: any) {
      addToast({
        type: 'error',
        title: 'Erreur',
        message: err.message,
      });
    }
  };

  const handleToggleOfferStatus = async (offerId: string, isActive: boolean) => {
    try {
      const updated = await offersApi.toggleStatus(offerId, isActive);
      addToast({
        type: 'info',
        title: isActive ? 'Offre activée' : 'Offre désactivée',
        message: `L’offre "${updated.title}" est maintenant ${isActive ? 'visible' : 'masquée'}.`,
      });
      if (selectedOffer?.id === offerId) {
        setSelectedOffer(updated);
      }
      await loadData();
    } catch (err: any) {
      addToast({
        type: 'error',
        title: 'Erreur',
        message: err.message,
      });
    }
  };

  const handleUpdateBookingStatus = async (bookingId: string, status: BookingStatus) => {
    try {
      const updated = await bookingsApi.updateStatus(bookingId, status);
      addToast({
        type: 'info',
        title: 'Statut de réservation mis à jour',
        message: `La séance est maintenant au statut : ${status}.`,
      });
      if (selectedBooking?.id === bookingId) {
        setSelectedBooking(updated);
      }
      await loadData();
    } catch (err: any) {
      addToast({
        type: 'error',
        title: 'Erreur',
        message: err.message,
      });
    }
  };

  // Loading Screen for auth
  if (isAuthLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white">
        <div className="w-10 h-10 border-3 border-emerald-500 border-t-transparent rounded-full animate-spin mb-4" />
        <p className="text-sm font-semibold text-slate-400">Initialisation du Back-Office EduLoc...</p>
      </div>
    );
  }

  // Not authenticated -> Show Login
  if (!isAuthenticated) {
    return <LoginPage />;
  }

  const apprentices = users.filter((u) => u.role === 'APPRENTICE');
  const pendingTutors = tutors.filter((t) => t.validationStatus === 'PENDING');
  const pendingBookingsCount = bookings.filter((b) => b.status === 'PENDING').length;

  return (
    <AdminLayout
      currentSection={currentSection}
      onSelectSection={(sec) => {
        if (sec === 'api-docs') {
          setIsApiDocsOpen(true);
        } else {
          setCurrentSection(sec);
        }
      }}
      pendingTutorsCount={pendingTutors.length}
      pendingBookingsCount={pendingBookingsCount}
      onRefreshData={handleRefresh}
      isRefreshing={isRefreshing}
      onOpenApiDocs={() => setIsApiDocsOpen(true)}
      toasts={toasts}
      onDismissToast={dismissToast}
    >
      {isLoadingData ? (
        <div className="p-16 text-center">
          <div className="w-8 h-8 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-sm font-semibold text-slate-700">Chargement des données EduLoc...</p>
        </div>
      ) : dataError ? (
        <div className="p-8 rounded-2xl bg-rose-50 border border-rose-200 text-center text-rose-900">
          <h3 className="font-bold text-base">Erreur de chargement</h3>
          <p className="text-xs mt-1">{dataError}</p>
          <button
            onClick={loadData}
            className="mt-4 px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-semibold"
          >
            Réessayer
          </button>
        </div>
      ) : (
        <>
          {/* Main Router Switch */}
          {currentSection === 'dashboard' && (
            <DashboardView
              stats={stats}
              pendingTutors={pendingTutors}
              bookings={bookings}
              users={users}
              onNavigate={setCurrentSection}
              onApproveTutor={(t) => setConfirmApproveTutor(t)}
              onRejectTutor={(t) => setConfirmRejectTutor(t)}
              onSelectTutor={(t) => setSelectedTutor(t)}
              onSelectBooking={(b) => setSelectedBooking(b)}
            />
          )}

          {currentSection === 'tutor-validation' && (
            <TutorValidationSection
              tutors={tutors}
              onApprove={(t) => setConfirmApproveTutor(t)}
              onReject={(t) => setConfirmRejectTutor(t)}
              onSelectTutor={(t) => setSelectedTutor(t)}
              onResendVerificationEmail={handleResendVerificationEmail}
            />
          )}

          {currentSection === 'users' && (
            <UsersView
              users={users}
              onSelectUser={(u) => setSelectedUser(u)}
              onUpdateStatus={handleUpdateUserStatus}
            />
          )}

          {currentSection === 'tutors' && (
            <TutorsView
              tutors={tutors}
              onSelectTutor={(t) => setSelectedTutor(t)}
              onApproveTutor={(t) => setConfirmApproveTutor(t)}
              onRejectTutor={(t) => setConfirmRejectTutor(t)}
            />
          )}

          {currentSection === 'apprentices' && (
            <ApprenticesView
              apprentices={apprentices}
              onSelectApprentice={(a) => setSelectedApprentice(a)}
            />
          )}

          {currentSection === 'offers' && (
            <OffersView
              offers={offers}
              onSelectOffer={(o) => setSelectedOffer(o)}
              onToggleStatus={handleToggleOfferStatus}
            />
          )}

          {currentSection === 'bookings' && (
            <BookingsView
              bookings={bookings}
              onSelectBooking={(b) => setSelectedBooking(b)}
              onUpdateStatus={handleUpdateBookingStatus}
            />
          )}
        </>
      )}

      {/* Modals */}
      {selectedUser && (
        <UserDetailModal
          user={selectedUser}
          onClose={() => setSelectedUser(null)}
          onUpdateStatus={handleUpdateUserStatus}
          onUpdateRole={handleUpdateUserRole}
          onResendVerificationEmail={handleResendVerificationEmail}
        />
      )}

      {selectedTutor && (
        <TutorDetailModal
          tutor={selectedTutor}
          offers={offers}
          bookings={bookings}
          onClose={() => setSelectedTutor(null)}
          onApprove={(t) => setConfirmApproveTutor(t)}
          onReject={(t) => setConfirmRejectTutor(t)}
          onResendVerificationEmail={handleResendVerificationEmail}
        />
      )}

      {selectedApprentice && (
        <ApprenticeDetailModal
          apprentice={selectedApprentice}
          bookings={bookings}
          onClose={() => setSelectedApprentice(null)}
          onSelectBooking={(b) => setSelectedBooking(b)}
        />
      )}

      {selectedOffer && (
        <OfferDetailModal
          offer={selectedOffer}
          onClose={() => setSelectedOffer(null)}
          onToggleStatus={handleToggleOfferStatus}
        />
      )}

      {selectedBooking && (
        <BookingDetailModal
          booking={selectedBooking}
          onClose={() => setSelectedBooking(null)}
          onUpdateStatus={handleUpdateBookingStatus}
        />
      )}

      <ApiEndpointsDocModal
        isOpen={isApiDocsOpen}
        onClose={() => setIsApiDocsOpen(false)}
      />

      {/* Confirmation Modal - Approve Tutor */}
      <ConfirmModal
        isOpen={Boolean(confirmApproveTutor)}
        title="Approuver la candidature tuteur"
        description={`Confirmez-vous la validation du dossier de ${confirmApproveTutor?.user.name} ? Son profil et ses offres deviendront immédiatement actifs sur la plateforme EduLoc.`}
        confirmLabel="✓ Oui, Approuver"
        variant="success"
        onConfirm={handleApproveTutorConfirm}
        onCancel={() => setConfirmApproveTutor(null)}
      />

      {/* Confirmation Modal - Reject Tutor */}
      <ConfirmModal
        isOpen={Boolean(confirmRejectTutor)}
        title="Refuser ou suspendre la candidature tuteur"
        description={`Veuillez indiquer la raison précise du refus pour ${confirmRejectTutor?.user.name}. Ce motif sera consigné et communiqué à l'enseignant.`}
        confirmLabel="✕ Confirmer le refus"
        variant="danger"
        inputReason={true}
        inputReasonPlaceholder="Ex : Diplôme non conforme, justificatifs d’identité illisibles, tarif horaire hors grille..."
        reasonValue={rejectionReason}
        onReasonChange={setRejectionReason}
        onConfirm={handleRejectTutorConfirm}
        onCancel={() => {
          setConfirmRejectTutor(null);
          setRejectionReason('');
        }}
      />
    </AdminLayout>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <AdminAppContent />
    </AuthProvider>
  );
}
