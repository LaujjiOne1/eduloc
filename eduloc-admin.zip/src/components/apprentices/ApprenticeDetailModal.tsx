import React from 'react';
import { User, Booking } from '../../types';
import { X, Mail, Phone, MapPin, BookOpen, Calendar } from 'lucide-react';
import { UserStatusBadge, BookingStatusBadge } from '../ui/StatusBadge';

interface ApprenticeDetailModalProps {
  apprentice: User | null;
  bookings: Booking[];
  onClose: () => void;
  onSelectBooking?: (booking: Booking) => void;
}

export const ApprenticeDetailModal: React.FC<ApprenticeDetailModalProps> = ({
  apprentice,
  bookings,
  onClose,
  onSelectBooking,
}) => {
  if (!apprentice) return null;

  const apprenticeBookings = bookings.filter((b) => b.apprenticeId === apprentice.id);
  const totalSpent = apprenticeBookings
    .filter((b) => b.status === 'COMPLETED' || b.status === 'ACCEPTED')
    .reduce((sum, b) => sum + (b.price || 0), 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900/90 backdrop-blur-2xl w-full max-w-2xl rounded-2xl shadow-2xl border border-white/15 overflow-hidden flex flex-col max-h-[90vh] text-slate-100">
        {/* Modal Header */}
        <div className="p-6 bg-white/5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-blue-500 to-indigo-500 flex items-center justify-center font-bold text-lg text-white shadow-lg shrink-0">
              {apprentice.name
                .split(' ')
                .map((n) => n[0])
                .slice(0, 2)
                .join('')}
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-lg font-bold text-white leading-tight">{apprentice.name}</h3>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-300 border border-blue-400/30">
                  Apprenti
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {apprentice.studyLevel || 'Étudiant'} • Inscrit le{' '}
                {new Date(apprentice.createdAt).toLocaleDateString('fr-FR')}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-300">
          {/* Quick Metrics */}
          <div className="grid grid-cols-3 gap-3">
            <div className="p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Séances réservées</span>
              <span className="text-base font-bold text-white mt-0.5 block">{apprenticeBookings.length}</span>
            </div>

            <div className="p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Total engagé</span>
              <span className="text-base font-bold text-green-400 mt-0.5 block">
                {totalSpent.toLocaleString('fr-FR')} Ar
              </span>
            </div>

            <div className="p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Statut</span>
              <div className="mt-1">
                <UserStatusBadge status={apprentice.status} />
              </div>
            </div>
          </div>

          {/* Contact Details */}
          <div className="p-4 rounded-xl bg-white/5 border border-white/10 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="flex items-center space-x-2">
              <Mail className="w-4 h-4 text-slate-400 shrink-0" />
              <span className="font-mono text-slate-200">{apprentice.email}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Phone className="w-4 h-4 text-slate-400 shrink-0" />
              <span className="text-slate-200">{apprentice.phone || 'Non renseigné'}</span>
            </div>
            <div className="flex items-center space-x-2">
              <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
              <span className="text-slate-200">{apprentice.locationLabel || 'Antananarivo'}</span>
            </div>
            <div className="flex items-center space-x-2">
              <BookOpen className="w-4 h-4 text-slate-400 shrink-0" />
              <span className="text-slate-200">Niveau : {apprentice.studyLevel || 'Non précisé'}</span>
            </div>
          </div>

          {/* Booking History */}
          <div>
            <h4 className="font-bold text-white uppercase tracking-wider text-xs mb-3 flex items-center space-x-1.5">
              <Calendar className="w-4 h-4 text-blue-400" />
              <span>Historique des réservations ({apprenticeBookings.length})</span>
            </h4>

            {apprenticeBookings.length === 0 ? (
              <p className="text-xs text-slate-500 italic p-4 bg-white/5 rounded-xl border border-white/10 text-center">
                Cet apprenti n’a encore effectué aucune réservation.
              </p>
            ) : (
              <div className="space-y-2">
                {apprenticeBookings.map((b) => (
                  <div
                    key={b.id}
                    onClick={() => onSelectBooking?.(b)}
                    className="p-3 bg-white/5 rounded-xl border border-white/10 hover:bg-white/10 transition-all flex items-center justify-between cursor-pointer"
                  >
                    <div>
                      <h5 className="font-bold text-white">{b.subject}</h5>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Tuteur : <span className="text-slate-200">{b.tutor?.name || 'Tuteur'}</span> • {b.date} ({b.startTime} - {b.endTime})
                      </p>
                    </div>

                    <div className="flex items-center space-x-3">
                      <span className="font-bold text-green-400">{b.price.toLocaleString('fr-FR')} Ar</span>
                      <BookingStatusBadge status={b.status} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-white/5 border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white rounded-xl transition-colors"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
