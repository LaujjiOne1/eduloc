import React, { useState } from 'react';
import { User } from '../../types';
import { SearchInput } from '../ui/SearchInput';
import { Pagination } from '../ui/Pagination';
import { UserStatusBadge } from '../ui/StatusBadge';
import { ExternalLink } from 'lucide-react';

interface ApprenticesViewProps {
  apprentices: User[];
  onSelectApprentice: (apprentice: User) => void;
}

export const ApprenticesView: React.FC<ApprenticesViewProps> = ({
  apprentices,
  onSelectApprentice,
}) => {
  const [search, setSearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 8;

  const filtered = apprentices.filter((a) => {
    if (!search) return true;
    const s = search.toLowerCase();
    return (
      a.name.toLowerCase().includes(s) ||
      a.email.toLowerCase().includes(s) ||
      (a.phone && a.phone.includes(s)) ||
      (a.studyLevel && a.studyLevel.toLowerCase().includes(s)) ||
      (a.locationLabel && a.locationLabel.toLowerCase().includes(s))
    );
  });

  const paginated = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Search Bar */}
      <div className="bg-white/5 backdrop-blur-md p-4 rounded-2xl border border-white/10 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="w-full sm:w-80">
          <SearchInput
            value={search}
            onChange={(val) => {
              setSearch(val);
              setCurrentPage(1);
            }}
            placeholder="Rechercher par nom, niveau, email..."
          />
        </div>
        <div className="text-xs text-slate-400 font-semibold">
          Total : <span className="text-white">{filtered.length}</span> apprenti{filtered.length > 1 ? 's' : ''}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-white/5 text-[11px] uppercase font-bold text-slate-400 border-b border-white/10">
              <tr>
                <th className="px-5 py-4">Apprenti</th>
                <th className="px-4 py-4">Niveau d’études</th>
                <th className="px-4 py-4">Contact</th>
                <th className="px-4 py-4">Localisation</th>
                <th className="px-4 py-4">Statut</th>
                <th className="px-4 py-4">Inscription</th>
                <th className="px-5 py-4 text-right">Actions</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-white/5">
              {paginated.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-5 py-12 text-center text-slate-400">
                    Aucun apprenti trouvé.
                  </td>
                </tr>
              ) : (
                paginated.map((apprentice) => (
                  <tr
                    key={apprentice.id}
                    className="hover:bg-white/5 transition-colors group cursor-pointer"
                    onClick={() => onSelectApprentice(apprentice)}
                  >
                    <td className="px-5 py-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-500/30 flex items-center justify-center font-bold text-blue-300 shrink-0">
                          {apprentice.name
                            .split(' ')
                            .map((n) => n[0])
                            .slice(0, 2)
                            .join('')}
                        </div>
                        <div className="min-w-0">
                          <h4 className="font-bold text-white group-hover:text-blue-300 transition-colors truncate">
                            {apprentice.name}
                          </h4>
                          <p className="text-[11px] text-slate-400 font-mono truncate">{apprentice.email}</p>
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-4 font-medium text-slate-200">
                      {apprentice.studyLevel || 'Général'}
                    </td>

                    <td className="px-4 py-4 text-slate-300">
                      {apprentice.phone || '-'}
                    </td>

                    <td className="px-4 py-4 text-slate-300">
                      {apprentice.locationLabel || 'Antananarivo'}
                    </td>

                    <td className="px-4 py-4">
                      <UserStatusBadge status={apprentice.status} />
                    </td>

                    <td className="px-4 py-4 text-slate-400">
                      {new Date(apprentice.createdAt).toLocaleDateString('fr-FR')}
                    </td>

                    <td className="px-5 py-4 text-right">
                      <button
                        onClick={() => onSelectApprentice(apprentice)}
                        className="p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                        title="Consulter le profil et réservations"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <Pagination
          currentPage={currentPage}
          totalItems={filtered.length}
          pageSize={pageSize}
          onPageChange={setCurrentPage}
        />
      </div>
    </div>
  );
};
