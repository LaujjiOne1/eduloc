import React from 'react';
import { Booking, BookingStatus } from '../../types';
import {
  X,
  MapPin,
  AlertTriangle,
} from 'lucide-react';
import { BookingStatusBadge } from '../ui/StatusBadge';

interface BookingDetailModalProps {
  booking: Booking | null;
  onClose: () => void;
  onUpdateStatus: (bookingId: string, status: BookingStatus) => void;
}

export const BookingDetailModal: React.FC<BookingDetailModalProps> = ({
  booking,
  onClose,
  onUpdateStatus,
}) => {
  if (!booking) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900/90 backdrop-blur-2xl w-full max-w-2xl rounded-2xl shadow-2xl border border-white/15 overflow-hidden flex flex-col text-slate-100">
        {/* Header */}
        <div className="p-6 bg-white/5 border-b border-white/10 flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-300 border border-blue-400/30">
                Réservation #{booking.id.slice(-6)}
              </span>
              <BookingStatusBadge status={booking.status} />
            </div>
            <h3 className="text-lg font-bold text-white mt-1.5 leading-tight">
              Cours de {booking.subject}
            </h3>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5 text-xs text-slate-300">
          {/* Conflict Alert Box if present */}
          {booking.hasConflict && (
            <div className="p-4 rounded-xl bg-rose-500/20 border border-rose-500/30 text-rose-200 flex items-start space-x-3">
              <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <h4 className="font-bold text-sm text-white">Conflit de disponibilité détecté</h4>
                <p className="text-xs mt-0.5 leading-relaxed">
                  {booking.conflictReason ||
                    'Ce créneau chevauche une autre séance confirmée pour le même tuteur.'}
                </p>
              </div>
            </div>
          )}

          {/* Time & Price grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Date</span>
              <span className="text-sm font-bold text-white mt-0.5 block">{booking.date}</span>
            </div>

            <div className="p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Horaire & Durée</span>
              <span className="text-sm font-bold text-white mt-0.5 block">
                {booking.startTime} - {booking.endTime} ({booking.duration} min)
              </span>
            </div>

            <div className="p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Tarif total</span>
              <span className="text-sm font-bold text-green-400 mt-0.5 block">
                {booking.price.toLocaleString('fr-FR')} Ar
              </span>
            </div>

            <div className="p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Mode</span>
              <span className="text-sm font-bold text-white mt-0.5 block">
                {booking.teachingMode === 'ONLINE' ? 'En ligne' : 'Présentiel'}
              </span>
            </div>
          </div>

          {/* Participants Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Apprentice Card */}
            <div className="p-4 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                Apprenti (Élève)
              </span>
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-500/30 flex items-center justify-center font-bold text-xs text-blue-300 shrink-0">
                  {(booking.apprentice?.name || 'A')
                    .split(' ')
                    .map((n) => n[0])
                    .slice(0, 2)
                    .join('')}
                </div>
                <div>
                  <p className="font-bold text-white">{booking.apprentice?.name || 'Apprenti'}</p>
                  <p className="text-[11px] text-slate-400 font-mono">{booking.apprentice?.email}</p>
                  <p className="text-[11px] text-slate-300">{booking.apprentice?.phone || 'Tel non fourni'}</p>
                </div>
              </div>
            </div>

            {/* Tutor Card */}
            <div className="p-4 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                Tuteur (Enseignant)
              </span>
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center font-bold text-xs text-indigo-300 shrink-0">
                  {(booking.tutor?.name || 'T')
                    .split(' ')
                    .map((n) => n[0])
                    .slice(0, 2)
                    .join('')}
                </div>
                <div>
                  <p className="font-bold text-white">{booking.tutor?.name || 'Tuteur'}</p>
                  <p className="text-[11px] text-slate-400 font-mono">{booking.tutor?.email}</p>
                  <p className="text-[11px] text-slate-300">{booking.tutor?.phone || 'Tel non fourni'}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Location & Meeting Notes */}
          <div className="p-4 bg-white/5 rounded-xl border border-white/10 space-y-2">
            <div className="flex items-center space-x-2">
              <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
              <span className="font-semibold text-slate-300">Lieu / Modalité :</span>
              <span className="text-white">{booking.locationLabel || 'Non spécifié'}</span>
            </div>

            {booking.meetingNotes && (
              <div className="pt-2 border-t border-white/10">
                <span className="font-semibold text-slate-300 block mb-1">Notes de préparation :</span>
                <p className="text-slate-300 italic bg-white/5 p-3 rounded-xl border border-white/10">
                  "{booking.meetingNotes}"
                </p>
              </div>
            )}
          </div>

          {/* Quick status change buttons */}
          <div className="pt-2 border-t border-white/10">
            <span className="font-bold text-slate-300 uppercase tracking-wider text-[10px] block mb-2">
              Changer le statut administratif :
            </span>
            <div className="flex flex-wrap items-center gap-2">
              {(['ACCEPTED', 'IN_PROGRESS', 'COMPLETED', 'REJECTED', 'CANCELLED'] as BookingStatus[]).map(
                (st) => (
                  <button
                    key={st}
                    disabled={booking.status === st}
                    onClick={() => onUpdateStatus(booking.id, st)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                      booking.status === st
                        ? 'bg-indigo-500 text-white cursor-default shadow-xs'
                        : 'bg-white/10 text-slate-300 hover:bg-white/20'
                    }`}
                  >
                    {st === 'ACCEPTED'
                      ? 'Accepter'
                      : st === 'IN_PROGRESS'
                      ? 'En cours'
                      : st === 'COMPLETED'
                      ? 'Marquer terminé'
                      : st === 'REJECTED'
                      ? 'Refuser'
                      : 'Annuler'}
                  </button>
                )
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-white/5 border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white rounded-xl transition-colors"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
