import React, { useState } from 'react';
import { Booking, BookingStatus } from '../../types';
import { SearchInput } from '../ui/SearchInput';
import { Pagination } from '../ui/Pagination';
import { BookingStatusBadge } from '../ui/StatusBadge';
import {
  Clock,
  MapPin,
  Video,
  AlertTriangle,
  ExternalLink,
} from 'lucide-react';

interface BookingsViewProps {
  bookings: Booking[];
  onSelectBooking: (booking: Booking) => void;
  onUpdateStatus: (bookingId: string, status: BookingStatus) => void;
}

export const BookingsView: React.FC<BookingsViewProps> = ({
  bookings,
  onSelectBooking,
  onUpdateStatus,
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<BookingStatus | 'ALL' | 'CONFLICTS'>('ALL');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 8;

  const conflictsCount = bookings.filter((b) => b.hasConflict).length;

  const filtered = bookings.filter((b) => {
    if (statusFilter === 'CONFLICTS') {
      if (!b.hasConflict) return false;
    } else if (statusFilter !== 'ALL') {
      if (b.status !== statusFilter) return false;
    }

    if (!search) return true;
    const s = search.toLowerCase();
    return (
      b.subject.toLowerCase().includes(s) ||
      (b.apprentice && b.apprentice.name.toLowerCase().includes(s)) ||
      (b.tutor && b.tutor.name.toLowerCase().includes(s)) ||
      (b.locationLabel && b.locationLabel.toLowerCase().includes(s)) ||
      b.date.includes(s)
    );
  });

  const paginated = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Search & Filters */}
      <div className="bg-white/5 backdrop-blur-md p-4 rounded-2xl border border-white/10 shadow-xs flex flex-col xl:flex-row items-center justify-between gap-4">
        <div className="w-full xl:w-80">
          <SearchInput
            value={search}
            onChange={(val) => {
              setSearch(val);
              setCurrentPage(1);
            }}
            placeholder="Rechercher par matière, tuteur, élève..."
          />
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 w-full xl:w-auto">
          {(
            [
              { id: 'ALL', label: 'Tous', isConflict: false },
              { id: 'PENDING', label: 'En attente', isConflict: false },
              { id: 'ACCEPTED', label: 'Acceptés', isConflict: false },
              { id: 'IN_PROGRESS', label: 'En cours', isConflict: false },
              { id: 'COMPLETED', label: 'Terminés', isConflict: false },
              { id: 'CANCELLED', label: 'Annulés', isConflict: false },
              { id: 'REJECTED', label: 'Refusés', isConflict: false },
              {
                id: 'CONFLICTS',
                label: `Conflits (${conflictsCount})`,
                isConflict: true,
              },
            ] as const
          ).map((tab) => {
            const isActive = statusFilter === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setStatusFilter(tab.id as any);
                  setCurrentPage(1);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  isActive
                    ? tab.isConflict
                      ? 'bg-rose-500/30 text-rose-200 border border-rose-500/40 shadow-xs'
                      : 'bg-white/15 text-white border border-white/20 shadow-xs'
                    : tab.isConflict && conflictsCount > 0
                    ? 'bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 border border-rose-500/30 animate-pulse'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Bookings Table */}
      <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-white/5 text-[11px] uppercase font-bold text-slate-400 border-b border-white/10">
              <tr>
                <th className="px-5 py-4">Matière & Séance</th>
                <th className="px-4 py-4">Apprenti (Élève)</th>
                <th className="px-4 py-4">Tuteur</th>
                <th className="px-4 py-4">Date & Heure</th>
                <th className="px-4 py-4">Tarif</th>
                <th className="px-4 py-4">Modalité</th>
                <th className="px-4 py-4">Statut</th>
                <th className="px-5 py-4 text-right">Actions</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-white/5">
              {paginated.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-5 py-12 text-center text-slate-400">
                    Aucune réservation trouvée.
                  </td>
                </tr>
              ) : (
                paginated.map((b) => (
                  <tr
                    key={b.id}
                    className={`hover:bg-white/5 transition-colors group cursor-pointer ${
                      b.hasConflict ? 'bg-rose-500/10' : ''
                    }`}
                    onClick={() => onSelectBooking(b)}
                  >
                    <td className="px-5 py-4">
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-white group-hover:text-indigo-300 transition-colors">
                          {b.subject}
                        </span>
                        {b.hasConflict && (
                          <span
                            className="p-1 text-rose-300 bg-rose-500/20 rounded-md shrink-0 border border-rose-500/30"
                            title="Conflit d'horaire détecté"
                          >
                            <AlertTriangle className="w-3.5 h-3.5" />
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400 font-mono">ID: {b.id.slice(-6)}</p>
                    </td>

                    <td className="px-4 py-4">
                      <div className="font-semibold text-white">{b.apprentice?.name || 'Apprenti'}</div>
                      <div className="text-[11px] text-slate-400 font-mono truncate max-w-[120px]">
                        {b.apprentice?.email}
                      </div>
                    </td>

                    <td className="px-4 py-4">
                      <div className="font-semibold text-white">{b.tutor?.name || 'Tuteur'}</div>
                      <div className="text-[11px] text-slate-400 font-mono truncate max-w-[120px]">
                        {b.tutor?.email}
                      </div>
                    </td>

                    <td className="px-4 py-4">
                      <div className="font-semibold text-slate-200">{b.date}</div>
                      <div className="text-[11px] text-slate-400 flex items-center space-x-1">
                        <Clock className="w-3 h-3 text-slate-400" />
                        <span>{b.startTime} - {b.endTime} ({b.duration} min)</span>
                      </div>
                    </td>

                    <td className="px-4 py-4 font-bold text-green-400">
                      {b.price.toLocaleString('fr-FR')} Ar
                    </td>

                    <td className="px-4 py-4">
                      <div className="flex items-center space-x-1.5 text-slate-300">
                        {b.teachingMode === 'ONLINE' ? (
                          <>
                            <Video className="w-3.5 h-3.5 text-blue-400" />
                            <span>En ligne</span>
                          </>
                        ) : (
                          <>
                            <MapPin className="w-3.5 h-3.5 text-green-400" />
                            <span className="truncate max-w-[100px]">{b.locationLabel || 'Présentiel'}</span>
                          </>
                        )}
                      </div>
                    </td>

                    <td className="px-4 py-4">
                      <BookingStatusBadge status={b.status} />
                    </td>

                    <td className="px-5 py-4 text-right">
                      <div
                        className="flex items-center justify-end space-x-1"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <button
                          onClick={() => onSelectBooking(b)}
                          className="p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                          title="Détails"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </button>
                        {b.status === 'PENDING' && (
                          <>
                            <button
                              onClick={() => onUpdateStatus(b.id, 'ACCEPTED')}
                              className="px-2.5 py-1 text-[11px] font-semibold text-green-300 bg-green-500/20 hover:bg-green-500 hover:text-white rounded-lg border border-green-500/30 transition-all"
                            >
                              Accepter
                            </button>
                            <button
                              onClick={() => onUpdateStatus(b.id, 'REJECTED')}
                              className="px-2.5 py-1 text-[11px] font-semibold text-rose-300 bg-rose-500/20 hover:bg-rose-500 hover:text-white rounded-lg border border-rose-500/30 transition-all"
                            >
                              Refuser
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <Pagination
          currentPage={currentPage}
          totalItems={filtered.length}
          pageSize={pageSize}
          onPageChange={setCurrentPage}
        />
      </div>
    </div>
  );
};
