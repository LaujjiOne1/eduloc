import React from 'react';
import { User, TutorProfile, Booking } from '../../types';
import { UserPlus, UserCheck, CalendarCheck, Clock } from 'lucide-react';

interface ActivityFeedProps {
  users: User[];
  pendingTutors: TutorProfile[];
  bookings: Booking[];
}

export const ActivityFeed: React.FC<ActivityFeedProps> = ({ users, pendingTutors, bookings }) => {
  const activities = [
    ...pendingTutors.map((t) => ({
      id: `act-tut-${t.id}`,
      type: 'tutor_pending',
      title: 'Nouveau dossier tuteur soumis',
      description: `${t.user.name} a déposé sa candidature (${t.subjects.join(', ')} - ${t.rate ? t.rate.toLocaleString('fr-FR') : '15 000'} Ar/h)`,
      time: 'Il y a 2h',
      icon: UserCheck,
      color: 'bg-amber-500/20 text-amber-300 border border-amber-500/30',
    })),
    ...bookings.slice(0, 2).map((b) => ({
      id: `act-bkg-${b.id}`,
      type: 'booking',
      title: `Réservation : ${b.subject}`,
      description: `${b.apprentice?.name || 'Apprenti'} a réservé avec ${b.tutor?.name || 'Tuteur'} (${b.price ? b.price.toLocaleString('fr-FR') : 0} Ar)`,
      time: 'Aujourd’hui',
      icon: CalendarCheck,
      color: 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30',
    })),
    ...users.slice(0, 2).map((u) => ({
      id: `act-usr-${u.id}`,
      type: 'user',
      title: 'Nouvelle inscription',
      description: `${u.name} a rejoint EduLoc (${u.role === 'TUTOR' ? 'Tuteur' : 'Apprenti'})`,
      time: 'Récemment',
      icon: UserPlus,
      color: 'bg-green-500/20 text-green-300 border border-green-500/30',
    })),
  ];

  return (
    <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold text-white text-sm sm:text-base flex items-center space-x-2">
          <Clock className="w-4 h-4 text-indigo-400" />
          <span>Activité récente sur la plateforme</span>
        </h3>
      </div>

      <div className="space-y-3">
        {activities.slice(0, 5).map((act) => {
          const Icon = act.icon;
          return (
            <div
              key={act.id}
              className="flex items-start space-x-3 text-xs p-3 rounded-xl bg-white/5 border border-white/5 hover:bg-white/10 transition-all"
            >
              <div className={`p-2 rounded-xl shrink-0 ${act.color}`}>
                <Icon className="w-3.5 h-3.5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-white truncate">{act.title}</h4>
                  <span className="text-[10px] text-slate-400">{act.time}</span>
                </div>
                <p className="text-slate-400 mt-0.5 leading-relaxed truncate">{act.description}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
