import React from 'react';
import {
  Users,
  GraduationCap,
  UserCheck,
  BookOpen,
  Calendar,
  CalendarCheck,
  Clock,
  Banknote,
  AlertTriangle,
} from 'lucide-react';
import { StatCard } from './StatCard';
import { QuickValidationWidget } from './QuickValidationWidget';
import { UpcomingBookingsWidget } from './UpcomingBookingsWidget';
import { ActivityFeed } from './ActivityFeed';
import { DashboardStats, TutorProfile, Booking, User } from '../../types';
import { NavSection } from '../layout/Sidebar';

interface DashboardViewProps {
  stats: DashboardStats | null;
  pendingTutors: TutorProfile[];
  bookings: Booking[];
  users: User[];
  onNavigate: (section: NavSection) => void;
  onApproveTutor: (tutor: TutorProfile) => void;
  onRejectTutor: (tutor: TutorProfile) => void;
  onSelectTutor: (tutor: TutorProfile) => void;
  onSelectBooking: (booking: Booking) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  stats,
  pendingTutors,
  bookings,
  users,
  onNavigate,
  onApproveTutor,
  onRejectTutor,
  onSelectTutor,
  onSelectBooking,
}) => {
  const conflictsCount = bookings.filter((b) => b.hasConflict).length;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Alert banner if pending tutors exist or conflict detected */}
      {(pendingTutors.length > 0 || conflictsCount > 0) && (
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-4 rounded-2xl bg-amber-500/10 backdrop-blur-md border border-amber-500/30 text-amber-200">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">
                Actions requises de l’administrateur
              </h4>
              <p className="text-xs text-slate-300 mt-0.5">
                {pendingTutors.length > 0 && (
                  <span>
                    <strong className="text-amber-300">{pendingTutors.length} dossier(s) tuteur</strong> en attente d’approbation.{' '}
                  </span>
                )}
                {conflictsCount > 0 && (
                  <span>
                    <strong className="text-rose-300">{conflictsCount} conflit(s) d’horaires</strong> détecté(s).
                  </span>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 self-end sm:self-center">
            {pendingTutors.length > 0 && (
              <button
                onClick={() => onNavigate('tutor-validation')}
                className="px-3.5 py-1.5 text-xs font-bold text-white bg-amber-500/80 hover:bg-amber-500 rounded-xl transition-all shadow-md shadow-amber-950/20"
              >
                Traiter les dossiers
              </button>
            )}
            {conflictsCount > 0 && (
              <button
                onClick={() => onNavigate('bookings')}
                className="px-3.5 py-1.5 text-xs font-bold text-rose-300 bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/30 rounded-xl transition-all"
              >
                Voir les conflits
              </button>
            )}
          </div>
        </div>
      )}

      {/* Grid of Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Total Apprentis */}
        <StatCard
          id="stat-apprentices"
          title="Apprentis"
          value={stats?.totalApprentices ?? 0}
          subtitle="Étudiants inscrits"
          icon={Users}
          color="blue"
          trend={{ value: '+12% cette semaine', isPositive: true }}
          onClick={() => onNavigate('apprentices')}
        />

        {/* Total Tuteurs */}
        <StatCard
          id="stat-tutors"
          title="Tuteurs"
          value={stats?.totalTutors ?? 0}
          subtitle={`${pendingTutors.length} en cours de vérification`}
          icon={GraduationCap}
          color="emerald"
          onClick={() => onNavigate('tutors')}
        />

        {/* Total Offres */}
        <StatCard
          id="stat-offers"
          title="Offres"
          value={stats?.totalOffers ?? 0}
          subtitle="Offres actives"
          icon={BookOpen}
          color="purple"
          onClick={() => onNavigate('offers')}
        />

        {/* RDV Aujourd'hui */}
        <StatCard
          id="stat-today-bookings"
          title="RDV Aujourd'hui"
          value={stats?.todayBookingsCount ?? 0}
          subtitle="Séances du jour"
          icon={CalendarCheck}
          color="emerald"
          onClick={() => onNavigate('bookings')}
        />
      </div>

      {/* Second Row of Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Tuteurs à valider */}
        <StatCard
          id="stat-pending-tutors"
          title="Tuteurs à valider"
          value={stats?.pendingTutorsCount ?? pendingTutors.length}
          subtitle="Candidatures reçues"
          icon={UserCheck}
          color="amber"
          badge={stats?.pendingTutorsCount ? 'Action requise' : undefined}
          onClick={() => onNavigate('tutor-validation')}
        />

        {/* RDV à venir */}
        <StatCard
          id="stat-upcoming-bookings"
          title="RDV à venir"
          value={stats?.upcomingBookingsCount ?? 0}
          subtitle="Confirmés & en attente"
          icon={Calendar}
          color="blue"
          onClick={() => onNavigate('bookings')}
        />

        {/* Demandes en attente */}
        <StatCard
          id="stat-pending-bookings"
          title="Demandes RDV"
          value={stats?.pendingBookingsCount ?? 0}
          subtitle="En attente tuteur"
          icon={Clock}
          color="amber"
          onClick={() => onNavigate('bookings')}
        />

        {/* Chiffre d'affaires estimé */}
        <StatCard
          id="stat-revenue"
          title="Volume financier"
          value={`${(stats?.totalRevenueEstimate ?? 0).toLocaleString('fr-FR')} Ar`}
          subtitle="Séances validées"
          icon={Banknote}
          color="slate"
        />
      </div>

      {/* Two Column Widgets: Validation & Bookings */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <div className="lg:col-span-3">
          <QuickValidationWidget
            pendingTutors={pendingTutors}
            onViewAll={() => onNavigate('tutor-validation')}
            onApprove={onApproveTutor}
            onReject={onRejectTutor}
            onSelectTutor={onSelectTutor}
          />
        </div>

        <div className="lg:col-span-2">
          <UpcomingBookingsWidget
            bookings={bookings}
            onViewAll={() => onNavigate('bookings')}
            onSelectBooking={onSelectBooking}
          />
        </div>
      </div>

      {/* Activity Feed */}
      <ActivityFeed users={users} pendingTutors={pendingTutors} bookings={bookings} />
    </div>
  );
};
