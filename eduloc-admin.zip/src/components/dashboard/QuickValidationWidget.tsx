import React from 'react';
import { TutorProfile } from '../../types';
import { Sparkles, MapPin } from 'lucide-react';

interface QuickValidationWidgetProps {
  pendingTutors: TutorProfile[];
  onViewAll: () => void;
  onApprove: (tutor: TutorProfile) => void;
  onReject: (tutor: TutorProfile) => void;
  onSelectTutor: (tutor: TutorProfile) => void;
}

export const QuickValidationWidget: React.FC<QuickValidationWidgetProps> = ({
  pendingTutors,
  onViewAll,
  onApprove,
  onReject,
  onSelectTutor,
}) => {
  return (
    <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl flex flex-col min-h-0 overflow-hidden">
      <div className="p-6 border-b border-white/10 flex justify-between items-center">
        <h2 className="font-bold text-white flex items-center">
          <span className="w-2 h-4 bg-indigo-500 rounded-full mr-2"></span>
          Tuteurs à valider
          {pendingTutors.length > 0 && (
            <span className="ml-2 px-2 py-0.5 text-[10px] font-bold rounded-full bg-rose-500 text-white">
              {pendingTutors.length}
            </span>
          )}
        </h2>
        <button
          onClick={onViewAll}
          className="text-xs text-indigo-400 hover:text-indigo-300 hover:underline transition-colors"
        >
          Voir tout
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-4 max-h-[380px]">
        {pendingTutors.length === 0 ? (
          <div className="p-8 text-center bg-white/5 border border-white/5 rounded-xl">
            <div className="w-12 h-12 mx-auto rounded-full bg-green-500/20 text-green-400 flex items-center justify-center mb-3">
              <Sparkles className="w-6 h-6" />
            </div>
            <p className="text-sm font-semibold text-white">Aucun dossier en attente</p>
            <p className="text-xs text-slate-400 mt-1">
              Tous les dossiers tuteurs soumis ont été traités.
            </p>
          </div>
        ) : (
          pendingTutors.map((tutor) => (
            <div
              key={tutor.id}
              className="bg-white/5 border border-white/5 p-4 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 hover:bg-white/10 hover:border-white/10 transition-all"
            >
              <div
                onClick={() => onSelectTutor(tutor)}
                className="flex items-center space-x-4 cursor-pointer flex-1 min-w-0"
              >
                <div className="w-12 h-12 rounded-lg bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center font-bold text-indigo-300 shrink-0">
                  {tutor.user.name
                    .split(' ')
                    .map((n) => n[0])
                    .slice(0, 2)
                    .join('')}
                </div>
                <div className="min-w-0">
                  <h3 className="font-semibold text-white leading-none hover:text-indigo-300 truncate">
                    {tutor.user.name}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 truncate">
                    {tutor.subjects.join(', ')} • {tutor.rate ? tutor.rate.toLocaleString('fr-FR') : '15 000'} Ar/h
                  </p>
                  {tutor.bio && (
                    <p className="text-[10px] text-slate-500 mt-1 italic truncate max-w-sm">
                      "{tutor.bio}"
                    </p>
                  )}
                </div>
              </div>

              <div className="flex space-x-2 self-end sm:self-center shrink-0">
                <button
                  onClick={() => onSelectTutor(tutor)}
                  className="px-3 py-1.5 bg-white/10 text-white text-xs font-bold rounded-lg hover:bg-white/20 transition-all"
                >
                  DÉTAILS
                </button>
                <button
                  onClick={() => onApprove(tutor)}
                  className="px-3 py-1.5 bg-green-500/20 text-green-400 text-xs font-bold rounded-lg border border-green-500/30 hover:bg-green-500 hover:text-white transition-all"
                >
                  APPROUVER
                </button>
                <button
                  onClick={() => onReject(tutor)}
                  className="px-3 py-1.5 bg-rose-500/20 text-rose-400 text-xs font-bold rounded-lg border border-rose-500/30 hover:bg-rose-500 hover:text-white transition-all"
                >
                  REFUSER
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
