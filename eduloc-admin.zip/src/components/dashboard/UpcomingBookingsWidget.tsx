import React from 'react';
import { Booking } from '../../types';
import { Clock, AlertTriangle, ArrowRight, Video, MapPin } from 'lucide-react';
import { BookingStatusBadge } from '../ui/StatusBadge';

interface UpcomingBookingsWidgetProps {
  bookings: Booking[];
  onViewAll: () => void;
  onSelectBooking: (booking: Booking) => void;
}

export const UpcomingBookingsWidget: React.FC<UpcomingBookingsWidgetProps> = ({
  bookings,
  onViewAll,
  onSelectBooking,
}) => {
  const conflicts = bookings.filter((b) => b.hasConflict);

  return (
    <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl flex flex-col min-h-0 overflow-hidden">
      <div className="p-6 border-b border-white/10 flex justify-between items-center">
        <h2 className="font-bold text-white flex items-center">
          <span className="w-2 h-4 bg-purple-500 rounded-full mr-2"></span>
          Rendez-vous à venir
        </h2>
        <button
          onClick={onViewAll}
          className="text-xs text-indigo-400 hover:text-indigo-300 hover:underline transition-colors"
        >
          Planning complet
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-4 max-h-[340px]">
        {bookings.length === 0 ? (
          <div className="p-6 text-center text-slate-400 text-xs bg-white/5 rounded-xl border border-white/5">
            Aucun rendez-vous prévu pour le moment.
          </div>
        ) : (
          bookings.slice(0, 5).map((b, idx) => {
            const isPurple = idx % 2 === 1;
            return (
              <div
                key={b.id}
                onClick={() => onSelectBooking(b)}
                className="flex items-start space-x-3 cursor-pointer p-2 rounded-xl hover:bg-white/5 transition-all group"
              >
                <div className="text-center shrink-0 w-12 pt-0.5">
                  <p className={`text-xs font-bold ${isPurple ? 'text-purple-400' : 'text-indigo-400'}`}>
                    {b.startTime}
                  </p>
                  <p className="text-[10px] text-slate-500">
                    {b.date ? b.date.slice(-5) : "Aujourd'hui"}
                  </p>
                </div>

                <div
                  className={`flex-1 border-l-2 ${
                    isPurple ? 'border-purple-500/40' : 'border-indigo-500/40'
                  } pl-4 min-w-0`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-semibold text-white group-hover:text-indigo-300 transition-colors truncate">
                      {b.subject}
                    </p>
                    <BookingStatusBadge status={b.status} />
                  </div>

                  <p className="text-[11px] text-slate-400 mt-0.5 truncate">
                    Tuteur: <span className="text-slate-300">{b.tutor?.name || 'Tuteur'}</span> • Apprenti:{' '}
                    <span className="text-slate-300">{b.apprentice?.name || 'Apprenti'}</span>
                  </p>

                  <div className="flex items-center space-x-2 mt-1 text-[10px] text-slate-400">
                    <span className="font-semibold text-green-400">
                      {b.price ? b.price.toLocaleString('fr-FR') : 0} Ar
                    </span>
                    <span>•</span>
                    <span>{b.teachingMode === 'ONLINE' ? 'En ligne' : 'Présentiel'}</span>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Conflict Alert Box in footer */}
      {conflicts.length > 0 && (
        <div className="p-6 pt-0 mt-auto">
          <div className="bg-indigo-500/10 rounded-xl p-3 border border-indigo-500/20 flex items-start space-x-2.5">
            <AlertTriangle className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-[10px] uppercase tracking-wider text-indigo-300 font-bold">
                Alerte Conflit ({conflicts.length})
              </p>
              <p className="text-[11px] text-indigo-200 mt-0.5">
                {conflicts[0].conflictReason ||
                  'Réservations détectées sur le même créneau pour un tuteur.'}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
