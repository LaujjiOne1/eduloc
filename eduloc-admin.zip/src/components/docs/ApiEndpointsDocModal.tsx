import React, { useState } from 'react';
import { backendRequirementsDoc } from '../../lib/api/mockData';
import { X, Code2, Database, CheckCircle2, AlertCircle, Copy, Check } from 'lucide-react';

interface ApiEndpointsDocModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApiEndpointsDocModal: React.FC<ApiEndpointsDocModalProps> = ({ isOpen, onClose }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900/90 backdrop-blur-2xl w-full max-w-4xl rounded-2xl shadow-2xl border border-white/15 overflow-hidden flex flex-col max-h-[90vh] text-slate-100">
        {/* Header */}
        <div className="p-6 bg-white/5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              <Database className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-lg font-bold text-white">Contrat d’intégration API NestJS & Prisma</h3>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-white/10 text-slate-300 border border-white/10">
                  EduLoc Admin Spec
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Spécifications détaillées des endpoints existants et des évolutions requises côté backend
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs text-slate-300">
          {/* Summary status cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-green-500/10 border border-green-500/20">
              <div className="flex items-center space-x-2 font-bold text-green-300">
                <CheckCircle2 className="w-4 h-4 text-green-400" />
                <span>DÉJÀ SUPPORTÉ PAR L'API</span>
              </div>
              <p className="text-xs text-slate-300 mt-1">
                Authentification JWT, Gestion des comptes Users (CRUD), Offres (Offer), Réservations (Booking), Statistiques.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20">
              <div className="flex items-center space-x-2 font-bold text-amber-300">
                <AlertCircle className="w-4 h-4 text-amber-400" />
                <span>FRONTEND DISPONIBLE — BACKEND À AJOUTER</span>
              </div>
              <p className="text-xs text-slate-300 mt-1">
                Endpoints de modération tuteurs (Approve/Reject avec motif) et renvoi d’email de vérification.
              </p>
            </div>
          </div>

          {/* List of endpoints specs */}
          <div className="space-y-4">
            <h4 className="font-bold text-white text-sm flex items-center space-x-2">
              <Code2 className="w-4 h-4 text-indigo-400" />
              <span>Répertoire des endpoints et spécifications</span>
            </h4>

            {backendRequirementsDoc.map((item, index) => {
              const isSupported = item.status === 'SUPPORTED_BY_API';
              return (
                <div
                  key={index}
                  className="p-4 rounded-xl border border-white/10 bg-white/5 space-y-2.5"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center space-x-2">
                      <span
                        className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold text-white ${
                          item.method === 'GET'
                            ? 'bg-blue-600'
                            : item.method === 'POST'
                            ? 'bg-green-600'
                            : item.method === 'PATCH'
                            ? 'bg-amber-600'
                            : 'bg-rose-600'
                        }`}
                      >
                        {item.method}
                      </span>
                      <code className="text-xs font-bold text-white font-mono bg-white/10 px-2 py-1 rounded border border-white/10">
                        {item.endpoint}
                      </code>
                    </div>

                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                        isSupported
                          ? 'bg-green-500/20 text-green-300 border border-green-500/30'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      }`}
                    >
                      {isSupported ? 'DÉJÀ SUPPORTÉ PAR L’API' : 'FRONTEND DISPONIBLE — BACKEND À AJOUTER'}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300">{item.description}</p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                    <div>
                      <span className="font-semibold text-slate-400">Rôle requis :</span>{' '}
                      <span className="font-mono font-bold text-indigo-300">{item.requiredRole}</span>
                    </div>
                    <div>
                      <span className="font-semibold text-slate-400">Modèle Prisma :</span>{' '}
                      <span className="font-mono text-slate-200">{item.prismaModel}</span>
                    </div>
                  </div>

                  {item.payloadExample && (
                    <div className="mt-2">
                      <div className="flex items-center justify-between text-[11px] text-slate-400 font-semibold mb-1">
                        <span>Payload Request (JSON) :</span>
                        <button
                          onClick={() => copyToClipboard(item.payloadExample!, index * 2)}
                          className="flex items-center space-x-1 text-slate-400 hover:text-white text-[10px]"
                        >
                          {copiedIndex === index * 2 ? (
                            <Check className="w-3 h-3 text-green-400" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                          <span>Copier</span>
                        </button>
                      </div>
                      <pre className="p-2.5 rounded-lg bg-black/50 text-indigo-300 border border-white/10 font-mono text-[11px] overflow-x-auto">
                        {item.payloadExample}
                      </pre>
                    </div>
                  )}

                  {item.responseExample && (
                    <div className="mt-2">
                      <div className="flex items-center justify-between text-[11px] text-slate-400 font-semibold mb-1">
                        <span>Réponse attendue (JSON) :</span>
                        <button
                          onClick={() => copyToClipboard(item.responseExample!, index * 2 + 1)}
                          className="flex items-center space-x-1 text-slate-400 hover:text-white text-[10px]"
                        >
                          {copiedIndex === index * 2 + 1 ? (
                            <Check className="w-3 h-3 text-green-400" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                          <span>Copier</span>
                        </button>
                      </div>
                      <pre className="p-2.5 rounded-lg bg-black/50 text-slate-200 border border-white/10 font-mono text-[11px] overflow-x-auto">
                        {item.responseExample}
                      </pre>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-white/5 border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-colors"
          >
            Fermer la documentation
          </button>
        </div>
      </div>
    </div>
  );
};
