import React, { useState } from 'react';
import { Sidebar, NavSection } from './Sidebar';
import { Header } from './Header';
import { ToastContainer, ToastMessage } from '../ui/Toast';

interface AdminLayoutProps {
  currentSection: NavSection;
  onSelectSection: (section: NavSection) => void;
  pendingTutorsCount?: number;
  pendingBookingsCount?: number;
  onRefreshData?: () => void;
  isRefreshing?: boolean;
  onOpenApiDocs?: () => void;
  toasts: ToastMessage[];
  onDismissToast: (id: string) => void;
  children: React.ReactNode;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  currentSection,
  onSelectSection,
  pendingTutorsCount = 0,
  pendingBookingsCount = 0,
  onRefreshData,
  isRefreshing = false,
  onOpenApiDocs,
  toasts,
  onDismissToast,
  children,
}) => {
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#0F172A] text-slate-100 flex relative overflow-x-hidden">
      {/* Background Luminous Frosted Blobs */}
      <div className="fixed top-[-200px] right-[-100px] w-[500px] h-[500px] bg-indigo-500/10 rounded-full blur-[140px] pointer-events-none -z-0" />
      <div className="fixed bottom-[-100px] left-[200px] w-[450px] h-[450px] bg-purple-500/5 rounded-full blur-[120px] pointer-events-none -z-0" />
      <div className="fixed top-[40%] right-[30%] w-[350px] h-[350px] bg-blue-500/5 rounded-full blur-[120px] pointer-events-none -z-0" />

      {/* Sidebar */}
      <Sidebar
        currentSection={currentSection}
        onSelectSection={onSelectSection}
        pendingTutorsCount={pendingTutorsCount}
        pendingBookingsCount={pendingBookingsCount}
        isOpenMobile={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 lg:pl-64 relative z-10">
        <Header
          currentSection={currentSection}
          onOpenMobileMenu={() => setIsMobileSidebarOpen(true)}
          onRefreshData={onRefreshData}
          isRefreshing={isRefreshing}
          onOpenApiDocs={onOpenApiDocs}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {children}
        </main>
      </div>

      {/* Global Toast Notifications */}
      <ToastContainer toasts={toasts} onDismiss={onDismissToast} />
    </div>
  );
};
