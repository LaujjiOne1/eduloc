import React from 'react';
import { Menu, RefreshCw, ShieldCheck, Database } from 'lucide-react';
import { useAuth } from '../../lib/context/AuthContext';
import { NavSection } from './Sidebar';

interface HeaderProps {
  currentSection: NavSection;
  onOpenMobileMenu: () => void;
  onRefreshData?: () => void;
  isRefreshing?: boolean;
  onOpenApiDocs?: () => void;
}

const sectionTitles: Record<NavSection, { title: string; subtitle: string }> = {
  dashboard: {
    title: "Vue d'ensemble",
    subtitle: 'Bienvenue sur le portail de gestion EduLoc.',
  },
  'tutor-validation': {
    title: 'Validation des Tuteurs',
    subtitle: 'Dossiers d’inscription en attente de vérification et modération',
  },
  users: {
    title: 'Gestion des Utilisateurs',
    subtitle: 'Consultez, filtrez et gérez les comptes apprentis, tuteurs et administrateurs',
  },
  tutors: {
    title: 'Répertoire des Tuteurs',
    subtitle: 'Profils enseignants, matières dispensées, tarifs en Ariary et disponibilités',
  },
  apprentices: {
    title: 'Apprentis & Étudiants',
    subtitle: 'Suivi des profils étudiants, niveaux d’études et historique des réservations',
  },
  offers: {
    title: 'Cours & Offres (Modèle Offer)',
    subtitle: 'Offres publiées par les tuteurs, modalités d’enseignement et statuts',
  },
  bookings: {
    title: 'Rendez-vous & Réservations (Modèle Booking)',
    subtitle: 'Gestion des séances, détection des conflits horaires et suivi des statuts',
  },
  'api-docs': {
    title: 'Architecture & Contrat API NestJS',
    subtitle: 'Spécifications des endpoints requis, modèles Prisma et statuts d’intégration',
  },
};

export const Header: React.FC<HeaderProps> = ({
  currentSection,
  onOpenMobileMenu,
  onRefreshData,
  isRefreshing = false,
  onOpenApiDocs,
}) => {
  const { isDemoMode } = useAuth();
  const info = sectionTitles[currentSection] || {
    title: 'EduLoc Admin',
    subtitle: 'Portail d’administration',
  };

  return (
    <header
      id="admin-header"
      className="sticky top-0 z-30 bg-[#0F172A]/70 backdrop-blur-xl border-b border-white/10 px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between"
    >
      <div className="flex items-center space-x-4 min-w-0">
        <button
          onClick={onOpenMobileMenu}
          className="p-2 -ml-1 text-slate-400 hover:text-white rounded-xl hover:bg-white/10 lg:hidden transition-colors"
          title="Menu de navigation"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight leading-tight">
            {info.title}
          </h1>
          <p className="text-xs text-slate-400 hidden sm:block truncate max-w-xl mt-0.5">
            {info.subtitle}
          </p>
        </div>
      </div>

      <div className="flex items-center space-x-3 shrink-0">
        {/* Refresh button */}
        {onRefreshData && (
          <button
            onClick={onRefreshData}
            disabled={isRefreshing}
            className="flex items-center space-x-2 px-3.5 py-2 text-xs font-semibold text-slate-200 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl transition-all disabled:opacity-50"
            title="Rafraîchir les données"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-indigo-400' : ''}`} />
            <span className="hidden md:inline">Actualiser</span>
          </button>
        )}

        {/* API Docs quick trigger */}
        <button
          onClick={onOpenApiDocs}
          className="flex items-center space-x-2 px-3.5 py-2 text-xs font-semibold text-indigo-300 bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/30 rounded-xl transition-all"
        >
          <Database className="w-3.5 h-3.5 text-indigo-400" />
          <span className="hidden sm:inline">Schéma API</span>
        </button>

        {/* Server Status Pill */}
        <div className="hidden xl:flex items-center space-x-2 bg-white/5 border border-white/10 px-3.5 py-2 rounded-xl">
          <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
          <span className="text-xs font-mono uppercase tracking-wider text-slate-300">
            {isDemoMode ? 'Sandbox: OK' : 'Serveur: OK'}
          </span>
        </div>
      </div>
    </header>
  );
};
