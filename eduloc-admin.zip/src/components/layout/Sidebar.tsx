import React from 'react';
import {
  LayoutDashboard,
  UserCheck,
  Users,
  GraduationCap,
  BookOpen,
  Calendar,
  Code2,
  LogOut,
  ChevronRight,
} from 'lucide-react';
import { useAuth } from '../../lib/context/AuthContext';

export type NavSection =
  | 'dashboard'
  | 'tutor-validation'
  | 'users'
  | 'tutors'
  | 'apprentices'
  | 'offers'
  | 'bookings'
  | 'api-docs';

interface SidebarProps {
  currentSection: NavSection;
  onSelectSection: (section: NavSection) => void;
  pendingTutorsCount?: number;
  pendingBookingsCount?: number;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentSection,
  onSelectSection,
  pendingTutorsCount = 0,
  pendingBookingsCount = 0,
  isOpenMobile,
  onCloseMobile,
}) => {
  const { admin, logout, isDemoMode, toggleDemoMode } = useAuth();

  const navItems = [
    {
      id: 'dashboard' as NavSection,
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: null,
    },
    {
      id: 'tutor-validation' as NavSection,
      label: 'Validation',
      icon: UserCheck,
      badge: pendingTutorsCount > 0 ? pendingTutorsCount : null,
      highlight: true,
    },
    {
      id: 'users' as NavSection,
      label: 'Utilisateurs',
      icon: Users,
      badge: null,
    },
    {
      id: 'tutors' as NavSection,
      label: 'Tuteurs',
      icon: GraduationCap,
      badge: null,
    },
    {
      id: 'apprentices' as NavSection,
      label: 'Apprentis',
      icon: Users,
      badge: null,
    },
    {
      id: 'offers' as NavSection,
      label: 'Cours & Offres',
      icon: BookOpen,
      badge: null,
    },
    {
      id: 'bookings' as NavSection,
      label: 'Rendez-vous',
      icon: Calendar,
      badge: pendingBookingsCount > 0 ? `${pendingBookingsCount}` : null,
    },
  ];

  return (
    <>
      {/* Overlay Mobile */}
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs lg:hidden"
        />
      )}

      <aside
        id="admin-sidebar"
        className={`fixed top-0 bottom-0 left-0 z-40 w-64 bg-white/5 backdrop-blur-xl border-r border-white/10 text-slate-100 flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="h-16 px-6 flex items-center justify-between border-b border-white/10">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center font-bold text-xl text-white shadow-lg shadow-indigo-500/25">
              E
            </div>
            <div className="flex items-baseline space-x-1.5">
              <span className="text-xl font-bold tracking-tight text-white">EduLoc</span>
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-400">Admin</span>
            </div>
          </div>
        </div>

        {/* Navigation items */}
        <div className="flex-1 overflow-y-auto px-4 py-6 space-y-1">
          <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-widest text-slate-400">
            Navigation
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentSection === item.id;
            return (
              <button
                key={item.id}
                id={`nav-item-${item.id}`}
                onClick={() => {
                  onSelectSection(item.id);
                  onCloseMobile();
                }}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-white/10 text-white shadow-xs'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <div className="flex items-center space-x-3 min-w-0">
                  <Icon
                    className={`w-5 h-5 shrink-0 ${
                      isActive ? 'text-indigo-400' : 'text-slate-400 opacity-80'
                    }`}
                  />
                  <span className="truncate">{item.label}</span>
                </div>

                {item.badge && (
                  <span
                    className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${
                      item.highlight
                        ? 'bg-rose-500 text-white animate-pulse'
                        : 'bg-indigo-500/30 text-indigo-200 border border-indigo-500/30'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}

          <div className="pt-6 px-3 pb-2 text-[10px] font-bold uppercase tracking-widest text-slate-400">
            Développement & API
          </div>

          <button
            id="nav-item-api-docs"
            onClick={() => {
              onSelectSection('api-docs');
              onCloseMobile();
            }}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-sm font-medium transition-all ${
              currentSection === 'api-docs'
                ? 'bg-white/10 text-white font-semibold'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <div className="flex items-center space-x-3">
              <Code2 className="w-5 h-5 text-indigo-400 shrink-0 opacity-80" />
              <span>Contrat API NestJS</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>
        </div>

        {/* API Status Switcher & Admin Footer */}
        <div className="p-4 border-t border-white/10 space-y-3 bg-white/5 backdrop-blur-md">
          <div className="p-3 rounded-xl bg-white/5 border border-white/10">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-300 flex items-center space-x-2">
                <span
                  className={`w-2 h-2 rounded-full ${
                    isDemoMode ? 'bg-amber-400' : 'bg-emerald-400 animate-pulse'
                  }`}
                />
                <span className="text-[11px] truncate">
                  {isDemoMode ? 'Mode Démo (Sandbox)' : 'Connecté API NestJS'}
                </span>
              </span>
              <button
                type="button"
                onClick={() => toggleDemoMode(!isDemoMode)}
                className="text-[10px] uppercase font-bold text-indigo-400 hover:text-indigo-300 underline shrink-0"
              >
                Changer
              </button>
            </div>
          </div>

          {/* Admin User info & logout */}
          <div className="flex items-center justify-between px-2 pt-1">
            <div className="flex items-center space-x-3 min-w-0">
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center text-xs font-bold text-white shrink-0">
                {admin?.name ? admin.name[0].toUpperCase() : 'A'}
              </div>
              <div className="truncate">
                <p className="text-xs font-medium text-white truncate">{admin?.name || 'Admin EduLoc'}</p>
                <p className="text-[10px] text-slate-400 truncate">{admin?.email || 'admin@eduloc.mg'}</p>
              </div>
            </div>
            <button
              onClick={logout}
              className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-white/10 rounded-lg transition-colors shrink-0"
              title="Déconnexion"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
