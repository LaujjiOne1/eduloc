import React from 'react';
import { Offer } from '../../types';
import { X } from 'lucide-react';

interface OfferDetailModalProps {
  offer: Offer | null;
  onClose: () => void;
  onToggleStatus: (offerId: string, isActive: boolean) => void;
}

export const OfferDetailModal: React.FC<OfferDetailModalProps> = ({
  offer,
  onClose,
  onToggleStatus,
}) => {
  if (!offer) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900/90 backdrop-blur-2xl w-full max-w-2xl rounded-2xl shadow-2xl border border-white/15 overflow-hidden flex flex-col text-slate-100">
        {/* Header */}
        <div className="p-6 bg-white/5 border-b border-white/10 flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-500/20 text-purple-300 border border-purple-400/30">
                Offre Prisma
              </span>
              <span
                className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                  offer.isActive ? 'bg-green-500/20 text-green-300 border border-green-500/30' : 'bg-white/10 text-slate-400'
                }`}
              >
                {offer.isActive ? 'Active' : 'Désactivée'}
              </span>
            </div>
            <h3 className="text-lg font-bold text-white mt-1.5 leading-tight">{offer.title}</h3>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4 text-xs text-slate-300">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Matière</span>
              <span className="text-sm font-bold text-white mt-0.5 block">{offer.subject}</span>
            </div>

            <div className="p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Tarif horaire</span>
              <span className="text-sm font-bold text-green-400 mt-0.5 block">
                {offer.rate.toLocaleString('fr-FR')} Ar/h
              </span>
            </div>

            <div className="p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Niveau cible</span>
              <span className="text-sm font-bold text-white mt-0.5 block">{offer.level}</span>
            </div>
          </div>

          {/* Tutor Info */}
          <div className="p-4 bg-white/5 rounded-xl border border-white/10 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center font-bold text-xs text-purple-300 shrink-0">
                {(offer.tutor?.name || 'T')
                  .split(' ')
                  .map((n) => n[0])
                  .slice(0, 2)
                  .join('')}
              </div>
              <div>
                <p className="font-bold text-white">{offer.tutor?.name || 'Tuteur non assigné'}</p>
                <p className="text-[11px] text-slate-400">{offer.tutor?.email}</p>
              </div>
            </div>

            <div className="text-right">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Mode de cours</span>
              <span className="font-semibold text-slate-200">{offer.teachingMode === 'ONLINE' ? 'En ligne' : 'Présentiel'}</span>
            </div>
          </div>

          {/* Description */}
          <div>
            <h4 className="font-bold text-white uppercase tracking-wider text-[10px] mb-1.5">
              Description complète de l'offre
            </h4>
            <p className="p-3.5 bg-white/5 rounded-xl text-slate-300 text-xs leading-relaxed border border-white/10 whitespace-pre-line">
              {offer.description}
            </p>
          </div>

          {/* Metadata dates */}
          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-white/10">
            <span>Créée le : {new Date(offer.createdAt).toLocaleDateString('fr-FR')}</span>
            <span>Mise à jour : {new Date(offer.updatedAt).toLocaleDateString('fr-FR')}</span>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-white/5 border-t border-white/10 flex items-center justify-between">
          <button
            onClick={() => onToggleStatus(offer.id, !offer.isActive)}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all ${
              offer.isActive
                ? 'bg-rose-500/20 text-rose-300 hover:bg-rose-500 hover:text-white border border-rose-500/30'
                : 'bg-green-500/20 text-green-300 hover:bg-green-500 hover:text-white border border-green-500/30'
            }`}
          >
            {offer.isActive ? 'Désactiver l’offre' : 'Activer l’offre'}
          </button>

          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white rounded-xl transition-colors"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
