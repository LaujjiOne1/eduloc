import React, { useState } from 'react';
import { Offer } from '../../types';
import { SearchInput } from '../ui/SearchInput';
import { Pagination } from '../ui/Pagination';
import { ExternalLink, Video, MapPin } from 'lucide-react';

interface OffersViewProps {
  offers: Offer[];
  onSelectOffer: (offer: Offer) => void;
  onToggleStatus: (offerId: string, isActive: boolean) => void;
}

export const OffersView: React.FC<OffersViewProps> = ({
  offers,
  onSelectOffer,
  onToggleStatus,
}) => {
  const [search, setSearch] = useState('');
  const [subjectFilter, setSubjectFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'INACTIVE'>('ALL');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 8;

  // Extract unique subjects
  const subjects = Array.from(new Set(offers.map((o) => o.subject)));

  const filtered = offers.filter((o) => {
    if (statusFilter === 'ACTIVE' && !o.isActive) return false;
    if (statusFilter === 'INACTIVE' && o.isActive) return false;
    if (subjectFilter !== 'ALL' && o.subject !== subjectFilter) return false;
    if (!search) return true;
    const s = search.toLowerCase();
    return (
      o.title.toLowerCase().includes(s) ||
      o.subject.toLowerCase().includes(s) ||
      o.description.toLowerCase().includes(s) ||
      (o.tutor && o.tutor.name.toLowerCase().includes(s))
    );
  });

  const paginated = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Filters & Search */}
      <div className="bg-white/5 backdrop-blur-md p-4 rounded-2xl border border-white/10 shadow-xs flex flex-col lg:flex-row items-center justify-between gap-4">
        <div className="w-full lg:w-80">
          <SearchInput
            value={search}
            onChange={(val) => {
              setSearch(val);
              setCurrentPage(1);
            }}
            placeholder="Rechercher par titre, matière, tuteur..."
          />
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
          {/* Subject Filter */}
          <div className="flex items-center space-x-1.5 overflow-x-auto max-w-xs sm:max-w-none py-1">
            <span className="text-xs font-semibold text-slate-400 shrink-0">Matière :</span>
            <button
              onClick={() => {
                setSubjectFilter('ALL');
                setCurrentPage(1);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition-all ${
                subjectFilter === 'ALL'
                  ? 'bg-white/15 text-white border border-white/20'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              Toutes
            </button>
            {subjects.map((sub) => (
              <button
                key={sub}
                onClick={() => {
                  setSubjectFilter(sub);
                  setCurrentPage(1);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition-all ${
                  subjectFilter === sub
                    ? 'bg-white/15 text-white border border-white/20'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                {sub}
              </button>
            ))}
          </div>

          {/* Status Filter */}
          <div className="flex items-center space-x-1.5">
            <span className="text-xs font-semibold text-slate-400">Statut :</span>
            {(['ALL', 'ACTIVE', 'INACTIVE'] as const).map((st) => (
              <button
                key={st}
                onClick={() => {
                  setStatusFilter(st);
                  setCurrentPage(1);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  statusFilter === st
                    ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                {st === 'ALL' ? 'Toutes' : st === 'ACTIVE' ? 'Actives' : 'Inactives'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Offers Table */}
      <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-white/5 text-[11px] uppercase font-bold text-slate-400 border-b border-white/10">
              <tr>
                <th className="px-5 py-4">Titre de l'offre</th>
                <th className="px-4 py-4">Matière</th>
                <th className="px-4 py-4">Tuteur</th>
                <th className="px-4 py-4">Tarif</th>
                <th className="px-4 py-4">Niveau</th>
                <th className="px-4 py-4">Mode</th>
                <th className="px-4 py-4">Statut</th>
                <th className="px-5 py-4 text-right">Actions</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-white/5">
              {paginated.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-5 py-12 text-center text-slate-400">
                    Aucune offre de cours trouvée.
                  </td>
                </tr>
              ) : (
                paginated.map((offer) => (
                  <tr
                    key={offer.id}
                    className="hover:bg-white/5 transition-colors group cursor-pointer"
                    onClick={() => onSelectOffer(offer)}
                  >
                    <td className="px-5 py-4">
                      <div className="min-w-0 max-w-xs">
                        <h4 className="font-bold text-white group-hover:text-purple-300 transition-colors truncate">
                          {offer.title}
                        </h4>
                        <p className="text-[11px] text-slate-400 line-clamp-1">{offer.description}</p>
                      </div>
                    </td>

                    <td className="px-4 py-4">
                      <span className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                        {offer.subject}
                      </span>
                    </td>

                    <td className="px-4 py-4 font-semibold text-white">
                      {offer.tutor?.name || 'Tuteur'}
                    </td>

                    <td className="px-4 py-4 font-bold text-green-400">
                      {offer.rate.toLocaleString('fr-FR')} Ar/h
                    </td>

                    <td className="px-4 py-4 text-slate-300">
                      {offer.level}
                    </td>

                    <td className="px-4 py-4">
                      <div className="flex items-center space-x-1.5 text-slate-300">
                        {offer.teachingMode === 'ONLINE' ? (
                          <>
                            <Video className="w-3.5 h-3.5 text-blue-400" />
                            <span>En ligne</span>
                          </>
                        ) : offer.teachingMode === 'IN_PERSON' ? (
                          <>
                            <MapPin className="w-3.5 h-3.5 text-green-400" />
                            <span>Présentiel</span>
                          </>
                        ) : (
                          <span>Hybride</span>
                        )}
                      </div>
                    </td>

                    <td className="px-4 py-4">
                      {offer.isActive ? (
                        <span className="inline-flex items-center space-x-1.5 text-[11px] font-semibold text-green-300 bg-green-500/20 px-2.5 py-0.5 rounded-full border border-green-500/30">
                          <span className="w-1.5 h-1.5 rounded-full bg-green-400"></span>
                          <span>Actif</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center space-x-1.5 text-[11px] font-semibold text-slate-400 bg-white/10 px-2.5 py-0.5 rounded-full">
                          <span>Inactif</span>
                        </span>
                      )}
                    </td>

                    <td className="px-5 py-4 text-right">
                      <div
                        className="flex items-center justify-end space-x-2"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <button
                          onClick={() => onSelectOffer(offer)}
                          className="p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                          title="Détails"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onToggleStatus(offer.id, !offer.isActive)}
                          className={`px-2.5 py-1 text-[11px] font-semibold rounded-lg transition-all ${
                            offer.isActive
                              ? 'text-rose-300 bg-rose-500/20 hover:bg-rose-500 hover:text-white border border-rose-500/30'
                              : 'text-green-300 bg-green-500/20 hover:bg-green-500 hover:text-white border border-green-500/30'
                          }`}
                        >
                          {offer.isActive ? 'Désactiver' : 'Activer'}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <Pagination
          currentPage={currentPage}
          totalItems={filtered.length}
          pageSize={pageSize}
          onPageChange={setCurrentPage}
        />
      </div>
    </div>
  );
};
