import React from 'react';
import { TutorProfile, Offer, Booking } from '../../types';
import {
  X,
  Check,
  Mail,
  Phone,
  BookOpen,
  MapPin,
  Clock,
  Star,
} from 'lucide-react';
import { ValidationStatusBadge, UserStatusBadge } from '../ui/StatusBadge';

interface TutorDetailModalProps {
  tutor: TutorProfile | null;
  offers: Offer[];
  bookings: Booking[];
  onClose: () => void;
  onApprove: (tutor: TutorProfile) => void;
  onReject: (tutor: TutorProfile) => void;
  onResendVerificationEmail: (userId: string) => void;
}

export const TutorDetailModal: React.FC<TutorDetailModalProps> = ({
  tutor,
  offers,
  bookings,
  onClose,
  onApprove,
  onReject,
  onResendVerificationEmail,
}) => {
  if (!tutor) return null;

  const tutorOffers = offers.filter((o) => o.tutorId === tutor.userId);
  const tutorBookings = bookings.filter((b) => b.tutorId === tutor.userId);

  const availabilityText =
    typeof tutor.availability === 'object' && tutor.availability !== null
      ? `${tutor.availability.days?.join(', ') || ''} - ${tutor.availability.timeSlots || ''}`
      : String(tutor.availability || 'Sur demande');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900/90 backdrop-blur-2xl w-full max-w-3xl rounded-2xl shadow-2xl border border-white/15 overflow-hidden flex flex-col max-h-[90vh] text-slate-100">
        {/* Modal Header */}
        <div className="p-6 bg-white/5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center font-bold text-lg text-white shadow-lg shrink-0">
              {tutor.user.name
                .split(' ')
                .map((n) => n[0])
                .slice(0, 2)
                .join('')}
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-lg font-bold text-white leading-tight">{tutor.user.name}</h3>
                <ValidationStatusBadge status={tutor.validationStatus} />
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {tutor.diploma || tutor.user.studyLevel || 'Tuteur'} • Inscrit le{' '}
                {new Date(tutor.submittedAt).toLocaleDateString('fr-FR')}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-sm text-slate-300">
          {/* Key Quick Facts Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-semibold text-slate-400 block uppercase tracking-wider">Tarif horaire</span>
              <span className="text-base font-bold text-green-400 mt-0.5 block">
                {tutor.rate ? tutor.rate.toLocaleString('fr-FR') : '15 000'} Ar/h
              </span>
            </div>

            <div className="p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-semibold text-slate-400 block uppercase tracking-wider">Évaluation</span>
              <div className="flex items-center space-x-1 font-bold text-white mt-1">
                <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                <span>{tutor.rating > 0 ? tutor.rating : 'Nouveau'}</span>
                <span className="text-xs text-slate-400 font-normal">({tutor.reviewsCount} avis)</span>
              </div>
            </div>

            <div className="p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-semibold text-slate-400 block uppercase tracking-wider">Expérience</span>
              <span className="text-sm font-bold text-white mt-1 block">
                {tutor.experienceYears ? `${tutor.experienceYears} an(s)` : 'Débutant'}
              </span>
            </div>

            <div className="p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-semibold text-slate-400 block uppercase tracking-wider">Statut Compte</span>
              <div className="mt-1">
                <UserStatusBadge status={tutor.user.status} />
              </div>
            </div>
          </div>

          {/* Contact & Verification status */}
          <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-2">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">
              Coordonnées & Vérifications
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4 text-slate-400 shrink-0" />
                <span className="font-mono text-slate-200 truncate">{tutor.user.email}</span>
                {tutor.user.emailVerified ? (
                  <span className="text-green-400 font-semibold text-[10px] bg-green-500/20 px-1.5 py-0.5 rounded border border-green-500/30">
                    ✓ Vérifié
                  </span>
                ) : (
                  <button
                    onClick={() => onResendVerificationEmail(tutor.userId)}
                    className="text-[10px] text-indigo-300 bg-indigo-500/20 hover:bg-indigo-500/30 px-2 py-0.5 rounded font-semibold border border-indigo-500/30"
                  >
                    Renvoyer email
                  </button>
                )}
              </div>

              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4 text-slate-400 shrink-0" />
                <span className="text-slate-200">{tutor.user.phone || 'Non renseigné'}</span>
              </div>

              <div className="flex items-center space-x-2">
                <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
                <span className="text-slate-200">{tutor.locationLabel || 'Antananarivo, Madagascar'}</span>
              </div>

              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-slate-400 shrink-0" />
                <span className="text-slate-200">{availabilityText}</span>
              </div>
            </div>
          </div>

          {/* Matières & Compétences */}
          <div>
            <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-2 flex items-center space-x-1.5">
              <BookOpen className="w-4 h-4 text-indigo-400" />
              <span>Matières enseignées</span>
            </h4>
            <div className="flex flex-wrap gap-1.5">
              {tutor.subjects.map((sub, i) => (
                <span
                  key={i}
                  className="px-3 py-1 bg-white/10 text-white border border-white/10 rounded-lg font-semibold text-xs"
                >
                  {sub}
                </span>
              ))}
            </div>
          </div>

          {/* Bio complète */}
          <div>
            <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-1.5">
              Présentation / Biographie
            </h4>
            <p className="p-3.5 bg-white/5 rounded-xl text-slate-300 text-xs leading-relaxed border border-white/10 italic">
              {tutor.bio || 'Aucune biographie rédigée.'}
            </p>
          </div>

          {/* Offres de cours rattachées */}
          <div>
            <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-2">
              Offres publiées ({tutorOffers.length})
            </h4>
            {tutorOffers.length === 0 ? (
              <p className="text-xs text-slate-500 italic">Aucune offre publiée pour ce profil.</p>
            ) : (
              <div className="space-y-2">
                {tutorOffers.map((o) => (
                  <div
                    key={o.id}
                    className="p-3 bg-white/5 rounded-xl border border-white/10 flex items-center justify-between text-xs"
                  >
                    <div>
                      <h5 className="font-bold text-white">{o.title}</h5>
                      <span className="text-slate-400">
                        {o.subject} • {o.level} • {o.teachingMode === 'ONLINE' ? 'En ligne' : 'Présentiel'}
                      </span>
                    </div>
                    <span className="font-bold text-green-400">{o.rate.toLocaleString('fr-FR')} Ar/h</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Modal Actions Footer */}
        <div className="p-4 bg-white/5 border-t border-white/10 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white rounded-xl transition-colors"
          >
            Fermer
          </button>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => onReject(tutor)}
              className="px-4 py-2 text-xs font-bold text-rose-400 bg-rose-500/20 hover:bg-rose-500 hover:text-white border border-rose-500/30 rounded-xl transition-all"
            >
              ✕ Refuser / Suspendre
            </button>
            <button
              onClick={() => onApprove(tutor)}
              className="flex items-center space-x-1.5 px-5 py-2 text-xs font-bold text-green-400 bg-green-500/20 hover:bg-green-500 hover:text-white border border-green-500/30 rounded-xl shadow-xs transition-all"
            >
              <Check className="w-4 h-4" />
              <span>✓ Approuver</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
