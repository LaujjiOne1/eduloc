import React, { useState } from 'react';
import { TutorProfile, ValidationStatus } from '../../types';
import {
  UserCheck,
  Check,
  X,
  Mail,
  Phone,
  BookOpen,
  MapPin,
  Clock,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';
import { ValidationStatusBadge } from '../ui/StatusBadge';

interface TutorValidationSectionProps {
  tutors: TutorProfile[];
  onApprove: (tutor: TutorProfile) => void;
  onReject: (tutor: TutorProfile) => void;
  onSelectTutor: (tutor: TutorProfile) => void;
  onResendVerificationEmail: (userId: string) => void;
}

export const TutorValidationSection: React.FC<TutorValidationSectionProps> = ({
  tutors,
  onApprove,
  onReject,
  onSelectTutor,
  onResendVerificationEmail,
}) => {
  const [activeFilter, setActiveFilter] = useState<ValidationStatus | 'ALL'>('PENDING');

  const filteredTutors = tutors.filter((t) => {
    if (activeFilter === 'ALL') return true;
    return t.validationStatus === activeFilter;
  });

  const pendingCount = tutors.filter((t) => t.validationStatus === 'PENDING').length;
  const approvedCount = tutors.filter((t) => t.validationStatus === 'APPROVED').length;
  const rejectedCount = tutors.filter((t) => t.validationStatus === 'REJECTED').length;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Workflow Explanation Banner */}
      <div className="p-6 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 text-white shadow-sm">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-500 text-white shadow-xs">
                Workflow de Modération
              </span>
              <h2 className="text-lg font-bold text-white tracking-tight">
                Processus d’approbation des tuteurs
              </h2>
            </div>
            <p className="text-xs text-slate-300 mt-1.5 max-w-2xl leading-relaxed">
              Lorsqu’un utilisateur s’inscrit avec le rôle <strong className="text-indigo-300">TUTEUR</strong>, son profil n’est pas
              actif immédiatement. Vérifiez son adresse email, ses diplômes, ses matières et son tarif
              avant d’approuver ou de refuser son dossier.
            </p>
          </div>

          {/* Workflow Steps Indicator */}
          <div className="hidden lg:flex items-center space-x-2 text-xs bg-white/5 p-3 rounded-xl border border-white/10">
            <div className="flex items-center space-x-1.5 text-slate-400">
              <span className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center font-bold text-[10px] text-white">1</span>
              <span>Inscription</span>
            </div>
            <span className="text-slate-500">→</span>
            <div className="flex items-center space-x-1.5 text-indigo-300">
              <span className="w-5 h-5 rounded-full bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center font-bold text-[10px] text-indigo-200">2</span>
              <span>Email vérifié</span>
            </div>
            <span className="text-slate-500">→</span>
            <div className="flex items-center space-x-1.5 text-amber-300">
              <span className="w-5 h-5 rounded-full bg-amber-500/20 border border-amber-400/40 flex items-center justify-center font-bold text-[10px]">3</span>
              <span>Dossier Admin</span>
            </div>
            <span className="text-slate-500">→</span>
            <div className="flex items-center space-x-1.5 text-green-300 font-bold">
              <span className="w-5 h-5 rounded-full bg-green-500/30 border border-green-500/50 flex items-center justify-center font-bold text-[10px] text-white">4</span>
              <span>Validation</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center space-x-2 border-b border-white/10 pb-3">
        <button
          onClick={() => setActiveFilter('PENDING')}
          className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeFilter === 'PENDING'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <span>À valider</span>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] ${
              activeFilter === 'PENDING' ? 'bg-amber-500 text-slate-950 font-black' : 'bg-white/10 text-slate-300'
            }`}
          >
            {pendingCount}
          </span>
        </button>

        <button
          onClick={() => setActiveFilter('APPROVED')}
          className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeFilter === 'APPROVED'
              ? 'bg-green-500/20 text-green-300 border border-green-500/30'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <span>Approuvés</span>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] ${
              activeFilter === 'APPROVED' ? 'bg-green-500 text-slate-950 font-black' : 'bg-white/10 text-slate-300'
            }`}
          >
            {approvedCount}
          </span>
        </button>

        <button
          onClick={() => setActiveFilter('REJECTED')}
          className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeFilter === 'REJECTED'
              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <span>Refusés</span>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] ${
              activeFilter === 'REJECTED' ? 'bg-rose-500 text-white font-black' : 'bg-white/10 text-slate-300'
            }`}
          >
            {rejectedCount}
          </span>
        </button>

        <button
          onClick={() => setActiveFilter('ALL')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
            activeFilter === 'ALL'
              ? 'bg-white/10 text-white border border-white/15'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          Tous ({tutors.length})
        </button>
      </div>

      {/* Grid of Dossier Cards */}
      {filteredTutors.length === 0 ? (
        <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-12 text-center">
          <div className="w-16 h-16 mx-auto rounded-full bg-white/5 text-slate-400 flex items-center justify-center mb-3">
            <UserCheck className="w-8 h-8" />
          </div>
          <h3 className="text-base font-bold text-white">Aucun dossier dans cet état</h3>
          <p className="text-xs text-slate-400 mt-1">
            {activeFilter === 'PENDING'
              ? 'Félicitations, aucun tuteur n’est en attente de modération.'
              : 'Aucun dossier ne correspond à ce filtre.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredTutors.map((tutor) => {
            const isPending = tutor.validationStatus === 'PENDING';
            const isApproved = tutor.validationStatus === 'APPROVED';
            const isRejected = tutor.validationStatus === 'REJECTED';

            const availabilityText =
              typeof tutor.availability === 'object' && tutor.availability !== null
                ? `${tutor.availability.days?.join(', ') || ''} (${tutor.availability.timeSlots || ''})`
                : String(tutor.availability || 'Sur demande');

            return (
              <div
                key={tutor.id}
                id={`tutor-card-${tutor.id}`}
                className={`bg-white/5 backdrop-blur-md rounded-2xl border shadow-xs overflow-hidden flex flex-col justify-between transition-all hover:bg-white/10 ${
                  isPending
                    ? 'border-amber-500/30'
                    : isApproved
                    ? 'border-green-500/30'
                    : 'border-rose-500/30'
                }`}
              >
                {/* Header card with photo & main info */}
                <div className="p-6">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start space-x-4 min-w-0">
                      <div className="w-14 h-14 rounded-2xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-lg font-bold text-indigo-300 shrink-0">
                        {tutor.user.name
                          .split(' ')
                          .map((n) => n[0])
                          .slice(0, 2)
                          .join('')}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center space-x-2">
                          <h3 className="text-base font-bold text-white truncate">
                            {tutor.user.name}
                          </h3>
                        </div>
                        <p className="text-xs text-slate-400 font-medium truncate mt-0.5">
                          {tutor.diploma || tutor.user.studyLevel || 'Tuteur certifié'}
                        </p>

                        {/* Email status pill */}
                        <div className="flex items-center space-x-2 mt-1.5">
                          {tutor.user.emailVerified ? (
                            <span className="inline-flex items-center space-x-1 text-[10px] font-semibold text-green-300 bg-green-500/20 px-2 py-0.5 rounded-md border border-green-500/30">
                              <CheckCircle2 className="w-3 h-3 text-green-400" />
                              <span>Email vérifié</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center space-x-1 text-[10px] font-semibold text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded-md border border-amber-500/30">
                              <AlertCircle className="w-3 h-3 text-amber-400" />
                              <span>Email non vérifié</span>
                            </span>
                          )}
                          <span className="text-[10px] text-slate-500">
                            Inscrit le {new Date(tutor.submittedAt).toLocaleDateString('fr-FR')}
                          </span>
                        </div>
                      </div>
                    </div>

                    <ValidationStatusBadge status={tutor.validationStatus} />
                  </div>

                  {/* Divider */}
                  <div className="my-4 border-t border-white/10" />

                  {/* Fiche détaillée fields */}
                  <div className="space-y-2.5 text-xs">
                    <div className="flex items-center space-x-2 text-slate-300">
                      <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="font-semibold text-slate-400 w-24 shrink-0">Email :</span>
                      <span className="font-mono text-white truncate">{tutor.user.email}</span>
                      {!tutor.user.emailVerified && (
                        <button
                          onClick={() => onResendVerificationEmail(tutor.userId)}
                          className="ml-auto text-[11px] text-indigo-400 hover:text-indigo-300 font-semibold hover:underline shrink-0"
                          title="Renvoyer l'email de confirmation"
                        >
                          Renvoyer
                        </button>
                      )}
                    </div>

                    <div className="flex items-center space-x-2 text-slate-300">
                      <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="font-semibold text-slate-400 w-24 shrink-0">Téléphone :</span>
                      <span className="text-white">{tutor.user.phone || 'Non renseigné'}</span>
                    </div>

                    <div className="flex items-start space-x-2 text-slate-300">
                      <BookOpen className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                      <span className="font-semibold text-slate-400 w-24 shrink-0">Matières :</span>
                      <div className="flex flex-wrap gap-1 flex-1">
                        {tutor.subjects.map((sub, i) => (
                          <span
                            key={i}
                            className="px-2 py-0.5 bg-white/10 text-white font-semibold rounded-md text-[11px] border border-white/5"
                          >
                            {sub}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center space-x-2 text-slate-300">
                      <span className="font-bold text-indigo-400 text-xs w-3.5 text-center shrink-0">Ar</span>
                      <span className="font-semibold text-slate-400 w-24 shrink-0">Tarif horaire :</span>
                      <span className="text-sm font-extrabold text-green-400">
                        {tutor.rate ? tutor.rate.toLocaleString('fr-FR') : '15 000'} Ar/h
                      </span>
                    </div>

                    <div className="flex items-center space-x-2 text-slate-300">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="font-semibold text-slate-400 w-24 shrink-0">Localisation :</span>
                      <span className="text-white">{tutor.locationLabel || 'Antananarivo'}</span>
                    </div>

                    <div className="flex items-start space-x-2 text-slate-300">
                      <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                      <span className="font-semibold text-slate-400 w-24 shrink-0">Disponibilités :</span>
                      <span className="text-slate-300 flex-1">{availabilityText}</span>
                    </div>

                    {/* Bio Snippet */}
                    <div className="pt-2">
                      <span className="font-semibold text-slate-400 block mb-1">Bio / Présentation :</span>
                      <p className="text-slate-300 bg-white/5 p-3 rounded-xl text-xs leading-relaxed italic line-clamp-3 border border-white/5">
                        "{tutor.bio}"
                      </p>
                    </div>

                    {/* Rejection reason display if rejected */}
                    {isRejected && tutor.rejectionReason && (
                      <div className="mt-3 p-3 rounded-xl bg-rose-500/20 border border-rose-500/30 text-rose-200">
                        <span className="font-bold block text-xs">Motif du refus notifié :</span>
                        <p className="text-xs mt-0.5">{tutor.rejectionReason}</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Footer with Actions */}
                <div className="px-6 py-4 bg-white/5 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => onSelectTutor(tutor)}
                    className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center space-x-1.5 hover:underline"
                  >
                    <span>Voir le profil complet</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>

                  <div className="flex items-center space-x-2">
                    {isPending ? (
                      <>
                        <button
                          type="button"
                          onClick={() => onReject(tutor)}
                          className="px-3.5 py-2 text-xs font-bold text-rose-400 bg-rose-500/20 hover:bg-rose-500 hover:text-white border border-rose-500/30 rounded-xl transition-all"
                        >
                          ✕ REFUSER
                        </button>
                        <button
                          type="button"
                          onClick={() => onApprove(tutor)}
                          className="px-4 py-2 text-xs font-bold text-green-400 bg-green-500/20 hover:bg-green-500 hover:text-white border border-green-500/30 rounded-xl shadow-xs transition-all"
                        >
                          ✓ APPROUVER
                        </button>
                      </>
                    ) : isApproved ? (
                      <div className="flex items-center space-x-2">
                        <span className="text-xs text-green-400 font-semibold flex items-center space-x-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Actif</span>
                        </span>
                        <button
                          type="button"
                          onClick={() => onReject(tutor)}
                          className="px-2.5 py-1.5 text-xs text-rose-400 hover:bg-rose-500/20 rounded-lg transition-colors border border-rose-500/20"
                        >
                          Suspendre
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => onApprove(tutor)}
                        className="px-3 py-1.5 text-xs font-semibold text-green-400 bg-green-500/20 hover:bg-green-500/30 rounded-lg border border-green-500/30 transition-colors"
                      >
                        Réexaminer & Approuver
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
