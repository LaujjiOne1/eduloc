import React, { useState } from 'react';
import { TutorProfile, ValidationStatus } from '../../types';
import { SearchInput } from '../ui/SearchInput';
import { Pagination } from '../ui/Pagination';
import { ValidationStatusBadge } from '../ui/StatusBadge';
import {
  Star,
  MapPin,
  ExternalLink,
  Check,
  X,
} from 'lucide-react';

interface TutorsViewProps {
  tutors: TutorProfile[];
  onSelectTutor: (tutor: TutorProfile) => void;
  onApproveTutor: (tutor: TutorProfile) => void;
  onRejectTutor: (tutor: TutorProfile) => void;
}

export const TutorsView: React.FC<TutorsViewProps> = ({
  tutors,
  onSelectTutor,
  onApproveTutor,
  onRejectTutor,
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<ValidationStatus | 'ALL'>('ALL');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 8;

  const filtered = tutors.filter((t) => {
    if (statusFilter !== 'ALL' && t.validationStatus !== statusFilter) return false;
    if (!search) return true;
    const s = search.toLowerCase();
    return (
      t.user.name.toLowerCase().includes(s) ||
      t.user.email.toLowerCase().includes(s) ||
      t.subjects.some((sub) => sub.toLowerCase().includes(s)) ||
      (t.locationLabel && t.locationLabel.toLowerCase().includes(s))
    );
  });

  const paginated = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Search & Filters Toolbar */}
      <div className="bg-white/5 backdrop-blur-md p-4 rounded-2xl border border-white/10 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="w-full sm:w-80">
          <SearchInput
            value={search}
            onChange={(val) => {
              setSearch(val);
              setCurrentPage(1);
            }}
            placeholder="Rechercher par nom, matière, ville..."
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <span className="text-xs font-semibold text-slate-400">Statut :</span>
          {(['ALL', 'APPROVED', 'PENDING', 'REJECTED'] as const).map((st) => (
            <button
              key={st}
              onClick={() => {
                setStatusFilter(st);
                setCurrentPage(1);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                statusFilter === st
                  ? 'bg-white/15 text-white border border-white/20'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              {st === 'ALL'
                ? 'Tous'
                : st === 'APPROVED'
                ? 'Approuvés'
                : st === 'PENDING'
                ? 'À valider'
                : 'Refusés'}
            </button>
          ))}
        </div>
      </div>

      {/* Tutors Table */}
      <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-white/5 text-[11px] uppercase font-bold text-slate-400 border-b border-white/10">
              <tr>
                <th className="px-5 py-4">Tuteur</th>
                <th className="px-4 py-4">Matières</th>
                <th className="px-4 py-4">Tarif horaire</th>
                <th className="px-4 py-4">Avis & Note</th>
                <th className="px-4 py-4">Localisation</th>
                <th className="px-4 py-4">Statut</th>
                <th className="px-5 py-4 text-right">Actions</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-white/5">
              {paginated.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-5 py-12 text-center text-slate-400">
                    Aucun tuteur trouvé avec ces critères.
                  </td>
                </tr>
              ) : (
                paginated.map((tutor) => (
                  <tr
                    key={tutor.id}
                    className="hover:bg-white/5 transition-colors group cursor-pointer"
                    onClick={() => onSelectTutor(tutor)}
                  >
                    <td className="px-5 py-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center font-bold text-indigo-300 shrink-0">
                          {tutor.user.name
                            .split(' ')
                            .map((n) => n[0])
                            .slice(0, 2)
                            .join('')}
                        </div>
                        <div className="min-w-0">
                          <h4 className="font-bold text-white group-hover:text-indigo-300 transition-colors truncate">
                            {tutor.user.name}
                          </h4>
                          <p className="text-[11px] text-slate-400 truncate">{tutor.user.email}</p>
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-4">
                      <div className="flex flex-wrap gap-1 max-w-xs">
                        {tutor.subjects.slice(0, 2).map((sub, i) => (
                          <span
                            key={i}
                            className="px-2 py-0.5 rounded-lg bg-white/10 text-slate-200 font-medium text-[10px] border border-white/5"
                          >
                            {sub}
                          </span>
                        ))}
                        {tutor.subjects.length > 2 && (
                          <span className="text-[10px] text-slate-400 font-semibold">
                            +{tutor.subjects.length - 2}
                          </span>
                        )}
                      </div>
                    </td>

                    <td className="px-4 py-4">
                      <span className="font-bold text-green-400 text-xs">
                        {tutor.rate ? tutor.rate.toLocaleString('fr-FR') : '15 000'} Ar/h
                      </span>
                    </td>

                    <td className="px-4 py-4">
                      <div className="flex items-center space-x-1 font-semibold text-white">
                        <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                        <span>{tutor.rating > 0 ? tutor.rating : '-'}</span>
                        <span className="text-[10px] text-slate-400 font-normal">
                          ({tutor.reviewsCount})
                        </span>
                      </div>
                    </td>

                    <td className="px-4 py-4">
                      <div className="flex items-center space-x-1 text-slate-300 truncate max-w-[150px]">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{tutor.locationLabel || 'Antananarivo'}</span>
                      </div>
                    </td>

                    <td className="px-4 py-4">
                      <ValidationStatusBadge status={tutor.validationStatus} />
                    </td>

                    <td className="px-5 py-4 text-right">
                      <div
                        className="flex items-center justify-end space-x-1"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <button
                          onClick={() => onSelectTutor(tutor)}
                          className="p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                          title="Voir le profil"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </button>

                        {tutor.validationStatus === 'PENDING' && (
                          <>
                            <button
                              onClick={() => onApproveTutor(tutor)}
                              className="p-1.5 text-green-400 hover:bg-green-500/20 rounded-lg transition-colors"
                              title="Approuver"
                            >
                              <Check className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => onRejectTutor(tutor)}
                              className="p-1.5 text-rose-400 hover:bg-rose-500/20 rounded-lg transition-colors"
                              title="Refuser"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <Pagination
          currentPage={currentPage}
          totalItems={filtered.length}
          pageSize={pageSize}
          onPageChange={setCurrentPage}
        />
      </div>
    </div>
  );
};
