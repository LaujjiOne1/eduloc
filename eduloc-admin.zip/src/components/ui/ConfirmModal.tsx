import React from 'react';
import { AlertCircle, CheckCircle2, X } from 'lucide-react';

interface ConfirmModalProps {
  isOpen: boolean;
  title: string;
  description: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: 'danger' | 'primary' | 'success';
  inputReason?: boolean;
  inputReasonPlaceholder?: string;
  reasonValue?: string;
  onReasonChange?: (val: string) => void;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({
  isOpen,
  title,
  description,
  confirmLabel = 'Confirmer',
  cancelLabel = 'Annuler',
  variant = 'primary',
  inputReason = false,
  inputReasonPlaceholder = 'Indiquez le motif...',
  reasonValue = '',
  onReasonChange,
  onConfirm,
  onCancel,
}) => {
  if (!isOpen) return null;

  const isDanger = variant === 'danger';
  const isSuccess = variant === 'success';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
      <div
        id="confirm-modal-box"
        className="w-full max-w-lg bg-slate-900/90 backdrop-blur-2xl rounded-2xl shadow-2xl border border-white/15 overflow-hidden transform transition-all text-slate-100"
      >
        <div className="p-6">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div
                className={`p-2.5 rounded-xl ${
                  isDanger
                    ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                    : isSuccess
                    ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                    : 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30'
                }`}
              >
                {isDanger ? (
                  <AlertCircle className="w-6 h-6" />
                ) : isSuccess ? (
                  <CheckCircle2 className="w-6 h-6" />
                ) : (
                  <AlertCircle className="w-6 h-6" />
                )}
              </div>
              <h3 className="text-lg font-bold text-white">{title}</h3>
            </div>
            <button
              onClick={onCancel}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <p className="mt-3 text-sm text-slate-300 leading-relaxed">{description}</p>

          {inputReason && (
            <div className="mt-4">
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                Motif obligatoire
              </label>
              <textarea
                value={reasonValue}
                onChange={(e) => onReasonChange?.(e.target.value)}
                placeholder={inputReasonPlaceholder}
                rows={3}
                className="w-full text-sm rounded-xl border border-white/10 bg-slate-950/70 text-white placeholder-slate-500 p-3 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-transparent"
              />
            </div>
          )}

          <div className="mt-6 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2.5 text-sm font-medium text-slate-300 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
            >
              {cancelLabel}
            </button>
            <button
              type="button"
              onClick={onConfirm}
              disabled={inputReason && !reasonValue.trim()}
              className={`px-5 py-2.5 text-sm font-semibold rounded-xl transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed ${
                isDanger
                  ? 'bg-rose-500/80 hover:bg-rose-500 text-white border border-rose-500/40'
                  : isSuccess
                  ? 'bg-green-500/80 hover:bg-green-500 text-white border border-green-500/40'
                  : 'bg-indigo-500 hover:bg-indigo-600 text-white shadow-indigo-500/25'
              }`}
            >
              {confirmLabel}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
