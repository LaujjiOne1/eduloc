import React from 'react';
import { User, UserRole, UserStatus } from '../../types';
import { X, CheckCircle2, AlertCircle } from 'lucide-react';
import { UserRoleBadge, UserStatusBadge } from '../ui/StatusBadge';

interface UserDetailModalProps {
  user: User | null;
  onClose: () => void;
  onUpdateStatus: (userId: string, status: UserStatus) => void;
  onUpdateRole: (userId: string, role: UserRole) => void;
  onResendVerificationEmail: (userId: string) => void;
}

export const UserDetailModal: React.FC<UserDetailModalProps> = ({
  user,
  onClose,
  onUpdateStatus,
  onUpdateRole,
  onResendVerificationEmail,
}) => {
  if (!user) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900/90 backdrop-blur-2xl w-full max-w-2xl rounded-2xl shadow-2xl border border-white/15 overflow-hidden flex flex-col text-slate-100">
        {/* Modal Header */}
        <div className="p-6 bg-white/5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center font-bold text-lg text-white shadow-lg shrink-0">
              {user.name
                .split(' ')
                .map((n) => n[0])
                .slice(0, 2)
                .join('')}
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-lg font-bold text-white leading-tight">{user.name}</h3>
                <UserRoleBadge role={user.role} />
              </div>
              <p className="text-xs text-slate-400 mt-0.5 font-mono">{user.email}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 text-xs text-slate-300">
          {/* User Fields Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">ID Compte</span>
              <span className="font-mono text-white font-bold">{user.id}</span>
            </div>

            <div className="p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Statut du Compte</span>
              <div className="mt-1">
                <UserStatusBadge status={user.status} />
              </div>
            </div>

            <div className="p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Téléphone</span>
              <span className="font-semibold text-white">{user.phone || 'Non renseigné'}</span>
            </div>

            <div className="p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Niveau d’études</span>
              <span className="font-semibold text-white">{user.studyLevel || 'Non renseigné'}</span>
            </div>

            <div className="p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Localisation</span>
              <span className="font-semibold text-white">
                {user.locationLabel || 'Antananarivo, Madagascar'}
              </span>
            </div>

            <div className="p-3.5 bg-white/5 rounded-xl border border-white/10">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Date d'inscription</span>
              <span className="font-semibold text-white">
                {new Date(user.createdAt).toLocaleString('fr-FR')}
              </span>
            </div>
          </div>

          {/* Email Verification Section */}
          <div className="p-4 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {user.emailVerified ? (
                <CheckCircle2 className="w-5 h-5 text-green-400" />
              ) : (
                <AlertCircle className="w-5 h-5 text-amber-400" />
              )}
              <div>
                <p className="font-bold text-white">
                  {user.emailVerified ? 'Adresse email confirmée' : 'Email non confirmé'}
                </p>
                <p className="text-[11px] text-slate-400">
                  {user.emailVerified
                    ? 'L’utilisateur a validé son adresse email.'
                    : 'Le compte n’a pas encore validé son adresse email.'}
                </p>
              </div>
            </div>

            {!user.emailVerified && (
              <button
                onClick={() => onResendVerificationEmail(user.id)}
                className="px-3 py-1.5 text-xs font-semibold text-indigo-300 bg-indigo-500/20 hover:bg-indigo-500/30 rounded-xl border border-indigo-500/30 transition-all"
              >
                Renvoyer le lien
              </button>
            )}
          </div>

          {/* Admin Actions on this Account */}
          <div className="border-t border-white/10 pt-4 space-y-3">
            <h4 className="font-bold text-white uppercase tracking-wider text-[10px]">
              Contrôles d’accès & Statut Administrateur
            </h4>

            <div className="flex flex-wrap items-center gap-3">
              <span className="font-semibold text-slate-400">Modifier le rôle :</span>
              {(['APPRENTICE', 'TUTOR', 'ADMIN'] as const).map((r) => (
                <button
                  key={r}
                  disabled={user.role === r}
                  onClick={() => onUpdateRole(user.id, r)}
                  className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all ${
                    user.role === r
                      ? 'bg-indigo-500 text-white cursor-default shadow-xs'
                      : 'bg-white/10 text-slate-300 hover:bg-white/20'
                  }`}
                >
                  {r === 'ADMIN' ? 'Administrateur' : r === 'TUTOR' ? 'Tuteur' : 'Apprenti'}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <span className="font-semibold text-slate-400">Action sur le compte :</span>
              {user.status === 'ACTIVE' ? (
                <button
                  onClick={() => onUpdateStatus(user.id, 'SUSPENDED')}
                  className="px-3 py-1.5 text-xs font-semibold text-rose-300 bg-rose-500/20 hover:bg-rose-500 hover:text-white border border-rose-500/30 rounded-xl transition-all"
                >
                  Suspendre l’accès au compte
                </button>
              ) : (
                <button
                  onClick={() => onUpdateStatus(user.id, 'ACTIVE')}
                  className="px-3 py-1.5 text-xs font-semibold text-green-300 bg-green-500/20 hover:bg-green-500 hover:text-white border border-green-500/30 rounded-xl transition-all"
                >
                  Réactiver le compte
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-white/5 border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white rounded-xl transition-colors"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
