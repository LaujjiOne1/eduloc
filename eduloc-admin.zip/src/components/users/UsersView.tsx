import React, { useState } from 'react';
import { User, UserRole, UserStatus } from '../../types';
import { SearchInput } from '../ui/SearchInput';
import { Pagination } from '../ui/Pagination';
import { UserRoleBadge, UserStatusBadge } from '../ui/StatusBadge';
import { ExternalLink } from 'lucide-react';

interface UsersViewProps {
  users: User[];
  onSelectUser: (user: User) => void;
  onUpdateStatus: (userId: string, status: UserStatus) => void;
}

export const UsersView: React.FC<UsersViewProps> = ({ users, onSelectUser, onUpdateStatus }) => {
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<UserRole | 'ALL'>('ALL');
  const [statusFilter, setStatusFilter] = useState<UserStatus | 'ALL'>('ALL');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 8;

  const filtered = users.filter((u) => {
    if (roleFilter !== 'ALL' && u.role !== roleFilter) return false;
    if (statusFilter !== 'ALL' && u.status !== statusFilter) return false;
    if (!search) return true;
    const s = search.toLowerCase();
    return (
      u.name.toLowerCase().includes(s) ||
      u.email.toLowerCase().includes(s) ||
      (u.phone && u.phone.includes(s)) ||
      (u.studyLevel && u.studyLevel.toLowerCase().includes(s)) ||
      (u.locationLabel && u.locationLabel.toLowerCase().includes(s))
    );
  });

  const paginated = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Search & Filters */}
      <div className="bg-white/5 backdrop-blur-md p-4 rounded-2xl border border-white/10 shadow-xs flex flex-col lg:flex-row items-center justify-between gap-4">
        <div className="w-full lg:w-80">
          <SearchInput
            value={search}
            onChange={(val) => {
              setSearch(val);
              setCurrentPage(1);
            }}
            placeholder="Rechercher nom, email, téléphone..."
          />
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
          {/* Filter by Role */}
          <div className="flex items-center space-x-1.5">
            <span className="text-xs font-semibold text-slate-400">Rôle :</span>
            {(['ALL', 'APPRENTICE', 'TUTOR', 'ADMIN'] as const).map((r) => (
              <button
                key={r}
                onClick={() => {
                  setRoleFilter(r);
                  setCurrentPage(1);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  roleFilter === r
                    ? 'bg-white/15 text-white border border-white/20'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                {r === 'ALL' ? 'Tous' : r === 'APPRENTICE' ? 'Apprenti' : r === 'TUTOR' ? 'Tuteur' : 'Admin'}
              </button>
            ))}
          </div>

          {/* Filter by Status */}
          <div className="flex items-center space-x-1.5">
            <span className="text-xs font-semibold text-slate-400">Statut :</span>
            {(['ALL', 'ACTIVE', 'SUSPENDED', 'PENDING_VERIFICATION'] as const).map((st) => (
              <button
                key={st}
                onClick={() => {
                  setStatusFilter(st);
                  setCurrentPage(1);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  statusFilter === st
                    ? 'bg-white/15 text-white border border-white/20'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                {st === 'ALL' ? 'Tous' : st === 'ACTIVE' ? 'Actif' : st === 'SUSPENDED' ? 'Suspendu' : 'En attente'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-white/5 text-[11px] uppercase font-bold text-slate-400 border-b border-white/10">
              <tr>
                <th className="px-5 py-4">Utilisateur</th>
                <th className="px-4 py-4">Rôle</th>
                <th className="px-4 py-4">Statut</th>
                <th className="px-4 py-4">Téléphone</th>
                <th className="px-4 py-4">Email</th>
                <th className="px-4 py-4">Date Inscription</th>
                <th className="px-5 py-4 text-right">Actions</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-white/5">
              {paginated.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-5 py-12 text-center text-slate-400">
                    Aucun utilisateur trouvé.
                  </td>
                </tr>
              ) : (
                paginated.map((user) => (
                  <tr
                    key={user.id}
                    className="hover:bg-white/5 transition-colors group cursor-pointer"
                    onClick={() => onSelectUser(user)}
                  >
                    <td className="px-5 py-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-9 h-9 rounded-full bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center font-bold text-xs text-indigo-300 shrink-0">
                          {user.name
                            .split(' ')
                            .map((n) => n[0])
                            .slice(0, 2)
                            .join('')}
                        </div>
                        <div className="min-w-0">
                          <h4 className="font-bold text-white group-hover:text-indigo-300 transition-colors truncate">
                            {user.name}
                          </h4>
                          <p className="text-[11px] font-mono text-slate-400 truncate">{user.email}</p>
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-4">
                      <UserRoleBadge role={user.role} />
                    </td>

                    <td className="px-4 py-4">
                      <UserStatusBadge status={user.status} />
                    </td>

                    <td className="px-4 py-4 font-medium text-slate-300">
                      {user.phone || '-'}
                    </td>

                    <td className="px-4 py-4">
                      {user.emailVerified ? (
                        <span className="text-green-400 font-semibold text-xs">✓ Vérifié</span>
                      ) : (
                        <span className="text-amber-400 font-semibold text-xs">Non vérifié</span>
                      )}
                    </td>

                    <td className="px-4 py-4 text-slate-400">
                      {new Date(user.createdAt).toLocaleDateString('fr-FR')}
                    </td>

                    <td className="px-5 py-4 text-right">
                      <div
                        className="flex items-center justify-end space-x-2"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <button
                          onClick={() => onSelectUser(user)}
                          className="p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                          title="Fiche profil"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </button>
                        {user.status === 'ACTIVE' ? (
                          <button
                            onClick={() => onUpdateStatus(user.id, 'SUSPENDED')}
                            className="px-2.5 py-1 text-[11px] font-semibold text-rose-300 bg-rose-500/20 hover:bg-rose-500 hover:text-white rounded-lg border border-rose-500/30 transition-all"
                          >
                            Suspendre
                          </button>
                        ) : (
                          <button
                            onClick={() => onUpdateStatus(user.id, 'ACTIVE')}
                            className="px-2.5 py-1 text-[11px] font-semibold text-green-300 bg-green-500/20 hover:bg-green-500 hover:text-white rounded-lg border border-green-500/30 transition-all"
                          >
                            Activer
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <Pagination
          currentPage={currentPage}
          totalItems={filtered.length}
          pageSize={pageSize}
          onPageChange={setCurrentPage}
        />
      </div>
    </div>
  );
};
