/**
 * Apprentices API Module - EduLoc Admin
 * Statut API : DÉJÀ SUPPORTÉ PAR L'API (Users avec role APPRENTICE + Bookings)
 */
import { api } from './client';
import { User, Booking } from '../../types';

export const apprenticesApi = {
  /**
   * Liste des apprentis
   * Endpoint : GET /api/admin/apprentices (ou /api/admin/users?role=APPRENTICE)
   */
  getAll: (params?: { search?: string; studyLevel?: string }): Promise<User[]> =>
    api.getApprentices(params),

  /**
   * Historique des réservations d'un apprenti
   * Endpoint : GET /api/admin/apprentices/:id/bookings
   */
  getBookings: (apprenticeId: string): Promise<Booking[]> =>
    api.getApprenticeBookings(apprenticeId),

  /**
   * Fiche détaillée d'un apprenti
   */
  getById: (id: string): Promise<User | null> => api.getUserById(id),
};
