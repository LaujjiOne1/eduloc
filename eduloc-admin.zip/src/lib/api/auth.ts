/**
 * Auth API Module - EduLoc Admin
 * Statut API : DÉJÀ SUPPORTÉ PAR L'API (JWT Auth / Access + Refresh Token)
 */
import { api } from './client';
import { AdminAuthResponse, User } from '../../types';

export const authApi = {
  /**
   * Connexion administrateur
   * Endpoint : POST /api/auth/login
   * Rôle requis : ADMIN
   */
  login: (email: string, pass: string): Promise<AdminAuthResponse> => api.loginAdmin(email, pass),

  /**
   * Profil administrateur connecté
   * Endpoint : GET /api/auth/me
   */
  getMe: (): Promise<User> => api.getAdminProfile(),

  /**
   * Déconnexion locale
   */
  logout: (): void => {
    api.removeTokens();
  },

  /**
   * Vérifie si un token est présent
   */
  isAuthenticated: (): boolean => {
    return Boolean(api.getToken());
  },
};
