/**
 * Bookings API Module - EduLoc Admin
 * Statut API : DÉJÀ SUPPORTÉ PAR L'API (Booking Prisma Model)
 * Inclut la détection et visualisation des conflits d'horaires.
 */
import { api } from './client';
import { Booking, BookingStatus } from '../../types';

export const bookingsApi = {
  /**
   * Liste des réservations avec filtres (statut, date, tuteur, apprenti, conflit)
   * Endpoint : GET /api/admin/bookings
   */
  getAll: (params?: {
    status?: BookingStatus | 'ALL';
    tutorId?: string;
    apprenticeId?: string;
    date?: string;
    hasConflict?: boolean;
    search?: string;
  }): Promise<Booking[]> => api.getBookings(params),

  /**
   * Mettre à jour le statut d'un rendez-vous
   * Endpoint : PATCH /api/admin/bookings/:id/status
   * Body : { status: BookingStatus }
   */
  updateStatus: (id: string, status: BookingStatus): Promise<Booking> =>
    api.updateBookingStatus(id, status),
};
