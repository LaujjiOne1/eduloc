/**
 * Client HTTP API pour EduLoc Admin
 * Centralise les appels vers l'API NestJS + Prisma + Supabase
 * et gère les tokens JWT, refresh tokens et fallback de développement.
 */

import { initialUsers, initialTutorProfiles, initialOffers, initialBookings, initialStats } from './mockData';
import { User, TutorProfile, Offer, Booking, DashboardStats, AdminAuthResponse, ValidationStatus, UserStatus, BookingStatus, UserRole } from '../../types';

const TOKEN_KEY = 'eduloc_admin_token';
const REFRESH_TOKEN_KEY = 'eduloc_admin_refresh_token';
const API_BASE_URL = (import.meta as any).env?.VITE_API_URL || 'http://localhost:3000/api';

class ApiClient {
  private inMemoryUsers: User[] = [...initialUsers];
  private inMemoryTutors: TutorProfile[] = [...initialTutorProfiles];
  private inMemoryOffers: Offer[] = [...initialOffers];
  private inMemoryBookings: Booking[] = [...initialBookings];
  private isDemoMode: boolean = false; // Par défaut, tente l'API réelle, avec bascule facile

  constructor() {
    // Restaurer l'état depuis localStorage s'il existe pour la persistance locale en mode démo
    const savedDemo = localStorage.getItem('eduloc_demo_mode');
    if (savedDemo !== null) {
      this.isDemoMode = savedDemo === 'true';
    } else {
      // Si aucune API externe n'est spécifiée, activer le mode démonstration
      this.isDemoMode = true;
    }

    const savedUsers = localStorage.getItem('eduloc_store_users');
    if (savedUsers) {
      try { this.inMemoryUsers = JSON.parse(savedUsers); } catch (e) { console.error(e); }
    }

    const savedTutors = localStorage.getItem('eduloc_store_tutors');
    if (savedTutors) {
      try { this.inMemoryTutors = JSON.parse(savedTutors); } catch (e) { console.error(e); }
    }

    const savedOffers = localStorage.getItem('eduloc_store_offers');
    if (savedOffers) {
      try { this.inMemoryOffers = JSON.parse(savedOffers); } catch (e) { console.error(e); }
    }

    const savedBookings = localStorage.getItem('eduloc_store_bookings');
    if (savedBookings) {
      try { this.inMemoryBookings = JSON.parse(savedBookings); } catch (e) { console.error(e); }
    }
  }

  private saveState() {
    localStorage.setItem('eduloc_store_users', JSON.stringify(this.inMemoryUsers));
    localStorage.setItem('eduloc_store_tutors', JSON.stringify(this.inMemoryTutors));
    localStorage.setItem('eduloc_store_offers', JSON.stringify(this.inMemoryOffers));
    localStorage.setItem('eduloc_store_bookings', JSON.stringify(this.inMemoryBookings));
  }

  public resetDemoData() {
    this.inMemoryUsers = [...initialUsers];
    this.inMemoryTutors = [...initialTutorProfiles];
    this.inMemoryOffers = [...initialOffers];
    this.inMemoryBookings = [...initialBookings];
    this.saveState();
  }

  public getIsDemoMode(): boolean {
    return this.isDemoMode;
  }

  public setDemoMode(val: boolean) {
    this.isDemoMode = val;
    localStorage.setItem('eduloc_demo_mode', String(val));
  }

  public getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  public setToken(token: string, refreshToken?: string) {
    localStorage.setItem(TOKEN_KEY, token);
    if (refreshToken) {
      localStorage.setItem(REFRESH_TOKEN_KEY, refreshToken);
    }
  }

  public removeTokens() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(REFRESH_TOKEN_KEY);
  }

  private getAuthHeaders(): Record<string, string> {
    const token = this.getToken();
    return {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    };
  }

  // Requête HTTP générique avec gestion JWT
  public async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    if (this.isDemoMode) {
      throw new Error('DEMO_MODE_ACTIVE');
    }

    const url = `${API_BASE_URL}${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`;
    const headers = {
      ...this.getAuthHeaders(),
      ...(options.headers as Record<string, string> || {}),
    };

    try {
      const response = await fetch(url, {
        ...options,
        headers,
      });

      if (response.status === 401) {
        // Tentative de refresh token ou redirection
        this.removeTokens();
        throw new Error('Session expirée ou non autorisée. Veuillez vous reconnecter.');
      }

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `Erreur API: ${response.status} ${response.statusText}`);
      }

      return await response.json();
    } catch (err: any) {
      console.warn(`[EduLoc API] Appel direct impossible vers ${url} (${err.message}). Utilisation du fallback.`);
      throw err;
    }
  }

  /* -------------------------------------------------------------
   * MODULE AUTH
   * ------------------------------------------------------------- */
  public async loginAdmin(email: string, password: string): Promise<AdminAuthResponse> {
    if (!this.isDemoMode) {
      try {
        // POST /api/auth/login
        const res = await this.request<AdminAuthResponse>('/auth/login', {
          method: 'POST',
          body: JSON.stringify({ email, password }),
        });
        if (res.user.role !== 'ADMIN') {
          throw new Error('Accès refusé : ce compte ne possède pas les privilèges Administrateur.');
        }
        this.setToken(res.token, res.refreshToken);
        return res;
      } catch (err: any) {
        if (err.message === 'DEMO_MODE_ACTIVE') {
          // continue to fallback
        } else {
          throw err;
        }
      }
    }

    // Simulation Auth Démo
    await new Promise(r => setTimeout(r, 400));
    if (email === 'admin@eduloc.mg' && password === 'admin123') {
      const res: AdminAuthResponse = {
        token: 'jwt_mock_admin_token_' + Date.now(),
        refreshToken: 'jwt_mock_refresh_token_' + Date.now(),
        user: {
          id: 'usr_admin_1',
          name: 'Admin EduLoc',
          email: 'admin@eduloc.mg',
          role: 'ADMIN',
        },
      };
      this.setToken(res.token, res.refreshToken);
      return res;
    }

    // Permet aussi de se connecter avec n'importe quel email contenant 'admin'
    if (email.toLowerCase().includes('admin')) {
      const res: AdminAuthResponse = {
        token: 'jwt_mock_admin_token_' + Date.now(),
        refreshToken: 'jwt_mock_refresh_token_' + Date.now(),
        user: {
          id: 'usr_admin_custom',
          name: 'Administrateur Principal',
          email: email,
          role: 'ADMIN',
        },
      };
      this.setToken(res.token, res.refreshToken);
      return res;
    }

    throw new Error('Identifiants incorrects. Utilisez admin@eduloc.mg / admin123');
  }

  public async getAdminProfile(): Promise<User> {
    if (!this.isDemoMode) {
      try {
        return await this.request<User>('/auth/me');
      } catch (err: any) {
        if (err.message !== 'DEMO_MODE_ACTIVE') throw err;
      }
    }
    return this.inMemoryUsers[0];
  }

  /* -------------------------------------------------------------
   * MODULE STATISTIQUES DASHBOARD
   * ------------------------------------------------------------- */
  public async getDashboardStats(): Promise<DashboardStats> {
    if (!this.isDemoMode) {
      try {
        // GET /api/admin/dashboard/stats
        return await this.request<DashboardStats>('/admin/dashboard/stats');
      } catch (err: any) {
        if (err.message !== 'DEMO_MODE_ACTIVE') throw err;
      }
    }

    // Calcul dynamique sur les données locales
    const totalApprentices = this.inMemoryUsers.filter(u => u.role === 'APPRENTICE').length;
    const totalTutors = this.inMemoryTutors.length;
    const pendingTutorsCount = this.inMemoryTutors.filter(t => t.validationStatus === 'PENDING').length;
    const totalOffers = this.inMemoryOffers.length;
    const todayStr = new Date().toISOString().split('T')[0];
    const todayBookingsCount = this.inMemoryBookings.filter(b => b.date === todayStr || b.date === '2026-08-18').length;
    const upcomingBookingsCount = this.inMemoryBookings.filter(b => b.status === 'ACCEPTED' || b.status === 'PENDING').length;
    const pendingBookingsCount = this.inMemoryBookings.filter(b => b.status === 'PENDING').length;
    const totalRevenueEstimate = this.inMemoryBookings
      .filter(b => b.status === 'COMPLETED' || b.status === 'ACCEPTED')
      .reduce((sum, b) => sum + (b.price || 0), 0);
    const activeUsersCount = this.inMemoryUsers.filter(u => u.status === 'ACTIVE').length;

    return {
      totalApprentices,
      totalTutors,
      pendingTutorsCount,
      totalOffers,
      upcomingBookingsCount,
      pendingBookingsCount,
      todayBookingsCount,
      totalRevenueEstimate,
      activeUsersCount,
    };
  }

  /* -------------------------------------------------------------
   * MODULE UTILISATEURS
   * ------------------------------------------------------------- */
  public async getUsers(params?: { search?: string; role?: UserRole | 'ALL'; status?: UserStatus | 'ALL' }): Promise<User[]> {
    if (!this.isDemoMode) {
      try {
        const q = new URLSearchParams();
        if (params?.search) q.set('search', params.search);
        if (params?.role && params.role !== 'ALL') q.set('role', params.role);
        if (params?.status && params.status !== 'ALL') q.set('status', params.status);
        return await this.request<User[]>(`/admin/users?${q.toString()}`);
      } catch (err: any) {
        if (err.message !== 'DEMO_MODE_ACTIVE') throw err;
      }
    }

    let list = [...this.inMemoryUsers];
    if (params?.role && params.role !== 'ALL') {
      list = list.filter(u => u.role === params.role);
    }
    if (params?.status && params.status !== 'ALL') {
      list = list.filter(u => u.status === params.status);
    }
    if (params?.search) {
      const s = params.search.toLowerCase();
      list = list.filter(u =>
        u.name.toLowerCase().includes(s) ||
        u.email.toLowerCase().includes(s) ||
        (u.phone && u.phone.includes(s)) ||
        (u.locationLabel && u.locationLabel.toLowerCase().includes(s))
      );
    }
    return list;
  }

  public async getUserById(id: string): Promise<User | null> {
    if (!this.isDemoMode) {
      try {
        return await this.request<User>(`/admin/users/${id}`);
      } catch (err: any) {
        if (err.message !== 'DEMO_MODE_ACTIVE') throw err;
      }
    }
    return this.inMemoryUsers.find(u => u.id === id) || null;
  }

  public async updateUserStatus(id: string, status: UserStatus): Promise<User> {
    if (!this.isDemoMode) {
      try {
        // PATCH /api/admin/users/:id/status
        return await this.request<User>(`/admin/users/${id}/status`, {
          method: 'PATCH',
          body: JSON.stringify({ status }),
        });
      } catch (err: any) {
        if (err.message !== 'DEMO_MODE_ACTIVE') throw err;
      }
    }

    const index = this.inMemoryUsers.findIndex(u => u.id === id);
    if (index === -1) throw new Error('Utilisateur non trouvé');
    this.inMemoryUsers[index] = {
      ...this.inMemoryUsers[index],
      status,
      updatedAt: new Date().toISOString(),
    };
    this.saveState();
    return this.inMemoryUsers[index];
  }

  public async updateUserRole(id: string, role: UserRole): Promise<User> {
    if (!this.isDemoMode) {
      try {
        return await this.request<User>(`/admin/users/${id}/role`, {
          method: 'PATCH',
          body: JSON.stringify({ role }),
        });
      } catch (err: any) {
        if (err.message !== 'DEMO_MODE_ACTIVE') throw err;
      }
    }

    const index = this.inMemoryUsers.findIndex(u => u.id === id);
    if (index === -1) throw new Error('Utilisateur non trouvé');
    this.inMemoryUsers[index] = {
      ...this.inMemoryUsers[index],
      role,
      activeRole: role,
      updatedAt: new Date().toISOString(),
    };
    this.saveState();
    return this.inMemoryUsers[index];
  }

  public async resendVerificationEmail(userId: string): Promise<{ success: boolean; message: string }> {
    if (!this.isDemoMode) {
      try {
        // POST /api/admin/users/:id/resend-verification-email
        return await this.request<{ success: boolean; message: string }>(`/admin/users/${userId}/resend-verification-email`, {
          method: 'POST',
        });
      } catch (err: any) {
        if (err.message !== 'DEMO_MODE_ACTIVE') throw err;
      }
    }

    // Démo
    const u = this.inMemoryUsers.find(x => x.id === userId);
    if (!u) throw new Error('Utilisateur introuvable');
    return {
      success: true,
      message: `Email de vérification renvoyé avec succès à ${u.email}`,
    };
  }

  /* -------------------------------------------------------------
   * MODULE TUTEURS & VALIDATION DES DOSSIERS
   * ------------------------------------------------------------- */
  public async getTutors(params?: { search?: string; status?: ValidationStatus | 'ALL'; subject?: string }): Promise<TutorProfile[]> {
    if (!this.isDemoMode) {
      try {
        const q = new URLSearchParams();
        if (params?.search) q.set('search', params.search);
        if (params?.status && params.status !== 'ALL') q.set('status', params.status);
        if (params?.subject) q.set('subject', params.subject);
        return await this.request<TutorProfile[]>(`/admin/tutors?${q.toString()}`);
      } catch (err: any) {
        if (err.message !== 'DEMO_MODE_ACTIVE') throw err;
      }
    }

    // Associer toujours les users à jour
    let list = this.inMemoryTutors.map(t => {
      const u = this.inMemoryUsers.find(x => x.id === t.userId) || t.user;
      return { ...t, user: u };
    });

    if (params?.status && params.status !== 'ALL') {
      list = list.filter(t => t.validationStatus === params.status);
    }
    if (params?.subject) {
      list = list.filter(t => t.subjects.some(s => s.toLowerCase().includes(params.subject!.toLowerCase())));
    }
    if (params?.search) {
      const s = params.search.toLowerCase();
      list = list.filter(t =>
        t.user.name.toLowerCase().includes(s) ||
        t.user.email.toLowerCase().includes(s) ||
        t.subjects.some(sub => sub.toLowerCase().includes(s)) ||
        (t.locationLabel && t.locationLabel.toLowerCase().includes(s))
      );
    }
    return list;
  }

  public async getPendingTutors(): Promise<TutorProfile[]> {
    return this.getTutors({ status: 'PENDING' });
  }

  public async getTutorById(id: string): Promise<TutorProfile | null> {
    if (!this.isDemoMode) {
      try {
        return await this.request<TutorProfile>(`/admin/tutors/${id}`);
      } catch (err: any) {
        if (err.message !== 'DEMO_MODE_ACTIVE') throw err;
      }
    }
    const t = this.inMemoryTutors.find(x => x.id === id || x.userId === id);
    if (!t) return null;
    const u = this.inMemoryUsers.find(x => x.id === t.userId) || t.user;
    return { ...t, user: u };
  }

  public async approveTutor(tutorProfileId: string, note?: string): Promise<TutorProfile> {
    if (!this.isDemoMode) {
      try {
        // PATCH /api/admin/tutors/:id/approve
        return await this.request<TutorProfile>(`/admin/tutors/${tutorProfileId}/approve`, {
          method: 'PATCH',
          body: JSON.stringify({ note }),
        });
      } catch (err: any) {
        if (err.message !== 'DEMO_MODE_ACTIVE') throw err;
      }
    }

    const index = this.inMemoryTutors.findIndex(t => t.id === tutorProfileId || t.userId === tutorProfileId);
    if (index === -1) throw new Error('Profil tuteur introuvable');

    const updated = {
      ...this.inMemoryTutors[index],
      validationStatus: 'APPROVED' as ValidationStatus,
      reviewedAt: new Date().toISOString(),
      rejectionReason: undefined,
    };
    this.inMemoryTutors[index] = updated;

    // Activer l'utilisateur
    const uIndex = this.inMemoryUsers.findIndex(u => u.id === updated.userId);
    if (uIndex !== -1) {
      this.inMemoryUsers[uIndex] = {
        ...this.inMemoryUsers[uIndex],
        status: 'ACTIVE',
        emailVerified: true,
      };
    }

    this.saveState();
    return updated;
  }

  public async rejectTutor(tutorProfileId: string, reason: string): Promise<TutorProfile> {
    if (!this.isDemoMode) {
      try {
        // PATCH /api/admin/tutors/:id/reject
        return await this.request<TutorProfile>(`/admin/tutors/${tutorProfileId}/reject`, {
          method: 'PATCH',
          body: JSON.stringify({ reason }),
        });
      } catch (err: any) {
        if (err.message !== 'DEMO_MODE_ACTIVE') throw err;
      }
    }

    const index = this.inMemoryTutors.findIndex(t => t.id === tutorProfileId || t.userId === tutorProfileId);
    if (index === -1) throw new Error('Profil tuteur introuvable');

    const updated = {
      ...this.inMemoryTutors[index],
      validationStatus: 'REJECTED' as ValidationStatus,
      reviewedAt: new Date().toISOString(),
      rejectionReason: reason,
    };
    this.inMemoryTutors[index] = updated;

    // Suspendre ou marquer le statut
    const uIndex = this.inMemoryUsers.findIndex(u => u.id === updated.userId);
    if (uIndex !== -1) {
      this.inMemoryUsers[uIndex] = {
        ...this.inMemoryUsers[uIndex],
        status: 'SUSPENDED',
      };
    }

    this.saveState();
    return updated;
  }

  /* -------------------------------------------------------------
   * MODULE APPRENTIS
   * ------------------------------------------------------------- */
  public async getApprentices(params?: { search?: string; studyLevel?: string }): Promise<User[]> {
    return this.getUsers({ role: 'APPRENTICE', search: params?.search });
  }

  public async getApprenticeBookings(apprenticeId: string): Promise<Booking[]> {
    return this.getBookings({ apprenticeId });
  }

  /* -------------------------------------------------------------
   * MODULE OFFRES (Offer Prisma)
   * ------------------------------------------------------------- */
  public async getOffers(params?: { search?: string; subject?: string; isActive?: boolean }): Promise<Offer[]> {
    if (!this.isDemoMode) {
      try {
        const q = new URLSearchParams();
        if (params?.search) q.set('search', params.search);
        if (params?.subject) q.set('subject', params.subject);
        if (params?.isActive !== undefined) q.set('isActive', String(params.isActive));
        return await this.request<Offer[]>(`/admin/offers?${q.toString()}`);
      } catch (err: any) {
        if (err.message !== 'DEMO_MODE_ACTIVE') throw err;
      }
    }

    let list = this.inMemoryOffers.map(off => {
      const tutor = this.inMemoryUsers.find(u => u.id === off.tutorId);
      const tutorProfile = this.inMemoryTutors.find(t => t.userId === off.tutorId);
      return { ...off, tutor, tutorProfile };
    });

    if (params?.isActive !== undefined) {
      list = list.filter(o => o.isActive === params.isActive);
    }
    if (params?.subject) {
      list = list.filter(o => o.subject.toLowerCase() === params.subject!.toLowerCase());
    }
    if (params?.search) {
      const s = params.search.toLowerCase();
      list = list.filter(o =>
        o.title.toLowerCase().includes(s) ||
        o.subject.toLowerCase().includes(s) ||
        o.description.toLowerCase().includes(s) ||
        (o.tutor && o.tutor.name.toLowerCase().includes(s))
      );
    }

    return list;
  }

  public async toggleOfferStatus(id: string, isActive: boolean): Promise<Offer> {
    if (!this.isDemoMode) {
      try {
        // PATCH /api/admin/offers/:id/status
        return await this.request<Offer>(`/admin/offers/${id}/status`, {
          method: 'PATCH',
          body: JSON.stringify({ isActive }),
        });
      } catch (err: any) {
        if (err.message !== 'DEMO_MODE_ACTIVE') throw err;
      }
    }

    const index = this.inMemoryOffers.findIndex(o => o.id === id);
    if (index === -1) throw new Error('Offre introuvable');
    this.inMemoryOffers[index] = {
      ...this.inMemoryOffers[index],
      isActive,
      updatedAt: new Date().toISOString(),
    };
    this.saveState();
    return this.inMemoryOffers[index];
  }

  /* -------------------------------------------------------------
   * MODULE RENDEZ-VOUS / BOOKINGS
   * ------------------------------------------------------------- */
  public async getBookings(params?: {
    status?: BookingStatus | 'ALL';
    tutorId?: string;
    apprenticeId?: string;
    date?: string;
    hasConflict?: boolean;
    search?: string;
  }): Promise<Booking[]> {
    if (!this.isDemoMode) {
      try {
        const q = new URLSearchParams();
        if (params?.status && params.status !== 'ALL') q.set('status', params.status);
        if (params?.tutorId) q.set('tutorId', params.tutorId);
        if (params?.apprenticeId) q.set('apprenticeId', params.apprenticeId);
        if (params?.date) q.set('date', params.date);
        return await this.request<Booking[]>(`/admin/bookings?${q.toString()}`);
      } catch (err: any) {
        if (err.message !== 'DEMO_MODE_ACTIVE') throw err;
      }
    }

    // Hydrater avec relations
    let list = this.inMemoryBookings.map(b => {
      const apprentice = this.inMemoryUsers.find(u => u.id === b.apprenticeId);
      const tutor = this.inMemoryUsers.find(u => u.id === b.tutorId);
      const tutorProfile = this.inMemoryTutors.find(t => t.userId === b.tutorId);
      const offer = this.inMemoryOffers.find(o => o.id === b.offerId);
      return { ...b, apprentice, tutor, tutorProfile, offer };
    });

    if (params?.status && params.status !== 'ALL') {
      list = list.filter(b => b.status === params.status);
    }
    if (params?.tutorId) {
      list = list.filter(b => b.tutorId === params.tutorId);
    }
    if (params?.apprenticeId) {
      list = list.filter(b => b.apprenticeId === params.apprenticeId);
    }
    if (params?.date) {
      list = list.filter(b => b.date === params.date);
    }
    if (params?.hasConflict !== undefined) {
      list = list.filter(b => b.hasConflict === params.hasConflict);
    }
    if (params?.search) {
      const s = params.search.toLowerCase();
      list = list.filter(b =>
        b.subject.toLowerCase().includes(s) ||
        (b.apprentice && b.apprentice.name.toLowerCase().includes(s)) ||
        (b.tutor && b.tutor.name.toLowerCase().includes(s)) ||
        (b.locationLabel && b.locationLabel.toLowerCase().includes(s))
      );
    }

    return list;
  }

  public async updateBookingStatus(id: string, status: BookingStatus): Promise<Booking> {
    if (!this.isDemoMode) {
      try {
        // PATCH /api/admin/bookings/:id/status
        return await this.request<Booking>(`/admin/bookings/${id}/status`, {
          method: 'PATCH',
          body: JSON.stringify({ status }),
        });
      } catch (err: any) {
        if (err.message !== 'DEMO_MODE_ACTIVE') throw err;
      }
    }

    const index = this.inMemoryBookings.findIndex(b => b.id === id);
    if (index === -1) throw new Error('Réservation introuvable');
    this.inMemoryBookings[index] = {
      ...this.inMemoryBookings[index],
      status,
      updatedAt: new Date().toISOString(),
    };
    this.saveState();
    return this.inMemoryBookings[index];
  }
}

export const api = new ApiClient();
