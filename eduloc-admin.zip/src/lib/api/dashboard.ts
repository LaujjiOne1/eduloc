/**
 * Dashboard API Module - EduLoc Admin
 * Statut API : DÉJÀ SUPPORTÉ PAR L'API (/api/admin/dashboard/stats)
 */
import { api } from './client';
import { DashboardStats } from '../../types';

export const dashboardApi = {
  /**
   * Récupérer les compteurs et métriques clés du tableau de bord
   * Endpoint : GET /api/admin/dashboard/stats
   */
  getStats: (): Promise<DashboardStats> => api.getDashboardStats(),
};
