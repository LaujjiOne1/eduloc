/**
 * Offers API Module - EduLoc Admin
 * Statut API : DÉJÀ SUPPORTÉ PAR L'API (Offer Prisma Model)
 */
import { api } from './client';
import { Offer } from '../../types';

export const offersApi = {
  /**
   * Liste des cours & offres d'enseignement
   * Endpoint : GET /api/admin/offers
   */
  getAll: (params?: { search?: string; subject?: string; isActive?: boolean }): Promise<Offer[]> =>
    api.getOffers(params),

  /**
   * Activer ou désactiver une offre de cours
   * Endpoint : PATCH /api/admin/offers/:id/status
   * Body : { isActive: boolean }
   */
  toggleStatus: (id: string, isActive: boolean): Promise<Offer> =>
    api.toggleOfferStatus(id, isActive),
};
