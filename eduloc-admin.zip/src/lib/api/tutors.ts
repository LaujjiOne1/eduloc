/**
 * Tutors API Module - EduLoc Admin
 * Statut API :
 * - Profils tuteurs : DÉJÀ SUPPORTÉ PAR L'API (TutorProfile Prisma)
 * - Validation & Refus de dossier : FRONTEND DISPONIBLE — BACKEND À AJOUTER (Champs validationStatus, rejectionReason)
 */
import { api } from './client';
import { TutorProfile, ValidationStatus } from '../../types';

export const tutorsApi = {
  /**
   * Liste des tuteurs filtrée
   * Endpoint : GET /api/admin/tutors
   * Rôle requis : ADMIN
   */
  getAll: (params?: { search?: string; status?: ValidationStatus | 'ALL'; subject?: string }): Promise<TutorProfile[]> =>
    api.getTutors(params),

  /**
   * Récupérer spécifiquement les dossiers en attente
   * Endpoint : GET /api/admin/tutors?status=PENDING
   */
  getPending: (): Promise<TutorProfile[]> => api.getPendingTutors(),

  /**
   * Profil complet d'un tuteur (User + TutorProfile + Offres + Avis)
   * Endpoint : GET /api/admin/tutors/:id
   */
  getById: (id: string): Promise<TutorProfile | null> => api.getTutorById(id),

  /**
   * Approuver un dossier tuteur
   * // FRONTEND DISPONIBLE — BACKEND À AJOUTER
   * Endpoint nécessaire : PATCH /api/admin/tutors/:id/approve
   * Body : { note?: string }
   */
  approve: (id: string, note?: string): Promise<TutorProfile> => api.approveTutor(id, note),

  /**
   * Refuser un dossier tuteur
   * // FRONTEND DISPONIBLE — BACKEND À AJOUTER
   * Endpoint nécessaire : PATCH /api/admin/tutors/:id/reject
   * Body : { reason: string }
   */
  reject: (id: string, reason: string): Promise<TutorProfile> => api.rejectTutor(id, reason),

  /**
   * Renvoyer l'email de confirmation au tuteur
   * // FRONTEND DISPONIBLE — BACKEND À AJOUTER
   * Endpoint nécessaire : POST /api/admin/users/:id/resend-verification-email
   */
  resendVerificationEmail: (userId: string): Promise<{ success: boolean; message: string }> =>
    api.resendVerificationEmail(userId),
};
