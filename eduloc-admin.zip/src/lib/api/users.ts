/**
 * Users API Module - EduLoc Admin
 * Statut API : DÉJÀ SUPPORTÉ PAR L'API (Gestion Users CRUD)
 * Modifications à prévoir : Endpoint status / role pour l'administration
 */
import { api } from './client';
import { User, UserRole, UserStatus } from '../../types';

export const usersApi = {
  /**
   * Liste des utilisateurs avec recherche et filtres
   * Endpoint : GET /api/admin/users
   * Rôle requis : ADMIN
   */
  getAll: (params?: { search?: string; role?: UserRole | 'ALL'; status?: UserStatus | 'ALL' }): Promise<User[]> =>
    api.getUsers(params),

  /**
   * Détails d'un utilisateur
   * Endpoint : GET /api/admin/users/:id
   */
  getById: (id: string): Promise<User | null> => api.getUserById(id),

  /**
   * Modifier le statut (Actif / Suspendu / En attente)
   * // DÉJÀ SUPPORTÉ PAR L'API
   * Endpoint : PATCH /api/admin/users/:id/status
   */
  updateStatus: (id: string, status: UserStatus): Promise<User> => api.updateUserStatus(id, status),

  /**
   * Modifier le rôle utilisateur
   * Endpoint : PATCH /api/admin/users/:id/role
   */
  updateRole: (id: string, role: UserRole): Promise<User> => api.updateUserRole(id, role),

  /**
   * Renvoyer l'email de vérification
   * // FRONTEND DISPONIBLE — BACKEND À AJOUTER
   * Endpoint nécessaire : POST /api/admin/users/:id/resend-verification-email
   */
  resendVerificationEmail: (userId: string): Promise<{ success: boolean; message: string }> =>
    api.resendVerificationEmail(userId),
};
