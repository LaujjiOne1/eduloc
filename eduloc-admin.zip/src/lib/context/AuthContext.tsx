import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, AdminAuthResponse } from '../../types';
import { api } from '../api/client';
import { authApi } from '../api/auth';

interface AuthContextType {
  admin: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isDemoMode: boolean;
  login: (email: string, pass: string) => Promise<AdminAuthResponse>;
  logout: () => void;
  toggleDemoMode: (enabled: boolean) => void;
  resetDemoData: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [admin, setAdmin] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isDemoMode, setIsDemoMode] = useState<boolean>(api.getIsDemoMode());

  useEffect(() => {
    const initAuth = async () => {
      const token = api.getToken();
      if (token) {
        try {
          const profile = await authApi.getMe();
          setAdmin(profile);
          setIsAuthenticated(true);
        } catch (err) {
          console.warn('Session expirée ou invalide', err);
          authApi.logout();
          setIsAuthenticated(false);
          setAdmin(null);
        }
      } else {
        setIsAuthenticated(false);
        setAdmin(null);
      }
      setIsLoading(false);
    };

    initAuth();
  }, []);

  const login = async (email: string, pass: string) => {
    const res = await authApi.login(email, pass);
    const profile = await authApi.getMe();
    setAdmin(profile);
    setIsAuthenticated(true);
    return res;
  };

  const logout = () => {
    authApi.logout();
    setAdmin(null);
    setIsAuthenticated(false);
  };

  const toggleDemoMode = (enabled: boolean) => {
    api.setDemoMode(enabled);
    setIsDemoMode(enabled);
  };

  const resetDemoData = () => {
    api.resetDemoData();
    window.location.reload();
  };

  return (
    <AuthContext.Provider
      value={{
        admin,
        isAuthenticated,
        isLoading,
        isDemoMode,
        login,
        logout,
        toggleDemoMode,
        resetDemoData,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
