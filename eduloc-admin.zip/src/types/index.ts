/**
 * Schéma de types EduLoc Admin - Conforme à schema.prisma et api.ts
 */

export type UserRole = 'APPRENTICE' | 'TUTOR' | 'ADMIN' | 'APPRENTI' | 'TUTEUR';
export type ActiveRole = 'NONE' | 'APPRENTI' | 'TUTEUR' | 'APPRENTICE' | 'TUTOR' | 'ADMIN';
export type UserStatus = 'ACTIVE' | 'SUSPENDED' | 'PENDING_VERIFICATION';
export type ValidationStatus = 'PENDING' | 'APPROVED' | 'REJECTED';
export type TutorStatus = ValidationStatus;
export type BookingType = 'SPOT' | 'PACK';

export type TeachingMode = 
  | 'ONLINE' 
  | 'IN_PERSON' 
  | 'HYBRID'
  | 'AT_HOME_APPRENTICE' 
  | 'AT_HOME_TUTOR' 
  | 'PUBLIC_PLACE';

export type BookingStatus = 
  | 'PENDING' 
  | 'ACCEPTED' 
  | 'DECLINED' 
  | 'REJECTED' 
  | 'CANCELLED' 
  | 'IN_PROGRESS' 
  | 'COMPLETED';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  activeRole?: ActiveRole;
  language: string;
  avatar?: string;
  phone?: string;
  studyLevel?: string;
  defaultSearchRadius?: number;
  latitude?: number;
  longitude?: number;
  locationLabel?: string;
  isAdmin?: boolean;
  status: UserStatus;
  emailVerified: boolean;
  emailVerificationToken?: string | null;
  emailVerificationExpiresAt?: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface TutorAvailability {
  days: string[]; // e.g. ['Lundi', 'Mercredi', 'Samedi']
  timeSlots: string; // e.g. '14:00 - 18:00'
  note?: string;
}

export interface TutorProfile {
  id: string;
  userId: string;
  user: User;
  subjects: string[];
  rate: number; // en Ariary (Ar/h)
  bio: string;
  rating: number;
  reviewsCount: number;
  latitude?: number;
  longitude?: number;
  locationLabel?: string;
  availability: TutorAvailability | string | string[];
  isOnline: boolean;
  validationStatus: ValidationStatus;
  status?: ValidationStatus; // Alias direct Prisma TutorProfile.status
  submittedAt: string;
  reviewedAt?: string;
  rejectionReason?: string;
  diploma?: string;
  experienceYears?: number;
}

export interface Offer {
  id: string;
  tutorId: string;
  tutorProfileId?: string;
  tutor?: User;
  tutorProfile?: TutorProfile;
  title: string;
  subject: string;
  description: string;
  rate: number; // en Ar/h
  level?: string; // e.g. 'Collège', 'Lycée', 'Université', 'Tous niveaux'
  teachingMode?: TeachingMode;
  locationLabel?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Booking {
  id: string;
  apprenticeId: string;
  apprentice?: User;
  tutorId: string;
  tutor?: User;
  tutorProfile?: TutorProfile;
  offerId?: string;
  offer?: Offer;
  subject: string;
  date: string; // YYYY-MM-DD ou ISO
  startTime?: string; // HH:mm
  endTime?: string; // HH:mm
  duration?: number; // minutes
  durationMinutes?: number;
  price: number; // Total en Ar
  type?: BookingType;
  status: BookingStatus;
  teachingMode?: TeachingMode;
  locationLabel?: string;
  locationAddress?: string | null;
  meetingUrl?: string | null;
  startOtp?: string | null;
  startedAt?: string | null;
  cancellationPolicy?: string | null;
  latitude?: number;
  longitude?: number;
  meetingNotes?: string;
  notes?: string;
  hasConflict?: boolean;
  conflictReason?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DashboardStats {
  totalApprentices: number;
  totalTutors: number;
  pendingTutorsCount: number;
  totalOffers: number;
  upcomingBookingsCount: number;
  pendingBookingsCount: number;
  todayBookingsCount: number;
  totalRevenueEstimate: number; // en Ar
  activeUsersCount: number;
}

export interface AdminAuthResponse {
  token: string;
  refreshToken: string;
  user: {
    id: string;
    name: string;
    email: string;
    role: UserRole;
  };
}

export interface ApiBackendRequirement {
  name: string;
  endpoint: string;
  method: 'GET' | 'POST' | 'PATCH' | 'PUT' | 'DELETE';
  requiredRole: string;
  status: 'SUPPORTED_BY_API' | 'BACKEND_TO_ADD';
  description: string;
  prismaModel: string;
  payloadExample?: string;
  responseExample?: string;
}
